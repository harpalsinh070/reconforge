import asyncio
import os
import sys
import shutil
import json
from pathlib import Path
from typing import Optional, List
import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from .banner import print_compact_header
from .config import config
from .db import (
    init_db, get_all_targets, get_target_by_domain,
    get_target_subdomains, get_target_ports,
    get_target_http_assets, get_target_findings, delete_target
)
from .pipeline.runner import PipelineRunner
from .pipeline.phases.phase1_target import TargetNormalizationScanner

def get_console(no_color: bool = False, to_stderr: bool = False) -> Console:
    return Console(file=sys.stderr if to_stderr else sys.stdout, no_color=no_color or bool(os.environ.get("NO_COLOR")))

@click.group(invoke_without_command=True)
@click.option("-d", "--domain", help="Target domain or host for immediate scan (e.g., example.com)")
@click.option("-u", "--url", "target_url", help="Target URL for immediate scan (e.g., https://example.com)")
@click.option("--profile", type=click.Choice(["quick", "standard", "full", "passive"]), default="standard", help="Scan depth profile")
@click.option("--quick", is_flag=True, help="High-speed triage (subdomains, DNS)")
@click.option("--passive", is_flag=True, help="Passive data sources only (zero direct target packets)")
@click.option("--full", "full_flag", is_flag=True, help="Full assessment with all advanced modules enabled")
@click.option("--all", "all_flag", is_flag=True, help="Run all implemented, compatible reconnaissance modules")
@click.option("-p", "--ports", help="Custom comma-separated TCP port list (e.g. 80,443,8080)")
@click.option("--full-ports", is_flag=True, help="Scan extended/full TCP ports list")
@click.option("--headers", is_flag=True, help="Check HTTP security headers (HSTS, CSP, X-Frame-Options, etc.)")
@click.option("--tls", is_flag=True, help="Inspect TLS certificate validity, expiration, and parameters")
@click.option("--vuln-scan", is_flag=True, help="Opt-in: Run Nuclei vulnerability scanner templates")
@click.option("--directories", is_flag=True, help="Opt-in: Run directory and file discovery")
@click.option("--deep-dns", is_flag=True, help="Opt-in: Run deep DNS records and takeover checks")
@click.option("--ip-intel", is_flag=True, help="Opt-in: Run reverse PTR, ASN and IP intelligence")
@click.option("--nmap", is_flag=True, help="Opt-in: Enable native Nmap engine if installed in PATH")
@click.option("-o", "--output", help="Save deliverable JSON report to file or directory path")
@click.option("--json", "json_output", is_flag=True, help="Output machine-readable JSON to stdout only")
@click.option("-v", "--verbose", is_flag=True, help="Enable verbose diagnostics")
@click.option("-q", "--quiet", is_flag=True, help="Quiet mode: suppress non-essential output")
@click.option("--no-color", is_flag=True, help="Plain-text output without ANSI color formatting")
@click.option("--exclude", help="Comma-separated hosts or wildcards to exclude from scope")
@click.option("--scope", help="Comma-separated scope boundaries")
@click.option("--version", is_flag=True, help="Display ReconForge version")
@click.option("--check", is_flag=True, help="Check external tools and runtime dependencies readiness")
@click.pass_context
def cli(
    ctx, domain, target_url, profile, quick, passive, full_flag, all_flag, ports, full_ports,
    headers, tls, vuln_scan, directories, deep_dns, ip_intel, nmap,
    output, json_output, verbose, quiet, no_color, exclude, scope, version, check
):
    """ReconForge: Fast, Modular Linux Reconnaissance & Attack Surface Management Tool."""
    console = get_console(no_color, to_stderr=json_output)

    if version:
        if json_output:
            print(json.dumps({"version": config.version, "app": config.app_name}))
        else:
            console.print(f"ReconForge version {config.version} (Linux Native)")
        sys.exit(0)

    if check:
        run_tool_check(no_color=no_color, json_output=json_output)
        sys.exit(0)

    # Validate target mutual exclusivity
    if domain and target_url:
        err_msg = "Error: Cannot specify both -u/--url and -d/--domain simultaneously. Specify either a target URL or a domain/host.\n"
        sys.stderr.write(err_msg)
        sys.exit(1)

    # Resolve profile flags
    if quick:
        profile = "quick"
    elif passive:
        profile = "passive"
    elif full_flag:
        profile = "full"

    custom_ports = [int(p.strip()) for p in ports.split(",") if p.strip().isdigit()] if ports else None

    # Immediate scan when domain or url is supplied at root level
    if domain or target_url:
        success = execute_scan(
            domain=domain,
            url=target_url,
            profile=profile,
            custom_ports=custom_ports,
            enable_full_ports=full_ports,
            enable_headers=headers,
            enable_tls=tls,
            enable_all=all_flag,
            enable_vuln_scan=vuln_scan,
            enable_directories=directories,
            enable_deep_dns=deep_dns,
            enable_ip_intel=ip_intel,
            enable_nmap=nmap,
            output=output,
            json_output=json_output,
            verbose=verbose,
            quiet=quiet,
            no_color=no_color,
            exclude=exclude,
            scope=scope
        )
        sys.exit(0 if success else 1)

    # Launch interactive shell if no subcommand and no target given
    if ctx.invoked_subcommand is None:
        from .console import ReconForgeConsole
        console_app = ReconForgeConsole()
        console_app.start()

def run_tool_check(no_color: bool = False, json_output: bool = False):
    """Check readiness of external binaries accurately without pretending they ran."""
    tools = [
        {"name": "Python 3", "bin": "python3", "desc": "Core Runtime", "role": "Required Engine"},
        {"name": "Nmap", "bin": config.nmap_path, "desc": "Port & Banner Scanner", "role": "Optional Active Scanner (--nmap)"},
        {"name": "Subfinder", "bin": config.subfinder_path, "desc": "Passive Subdomain OSINT", "role": "Optional OSINT Tool"},
        {"name": "Nuclei", "bin": config.nuclei_path, "desc": "Vulnerability Template Audit", "role": "Optional Vuln Scanner (--vuln-scan)"}
    ]

    status_data = []
    for t in tools:
        path = shutil.which(t["bin"])
        status_data.append({
            "name": t["name"],
            "installed": bool(path),
            "path": path or "Not in PATH",
            "role": t["role"]
        })

    if json_output:
        print(json.dumps({"tool_readiness": status_data}, indent=2))
        return

    console = get_console(no_color)
    print_compact_header(console=console)

    table = Table(title="Security Tool Readiness & Dependency Status")
    table.add_column("Tool / Binary", style="cyan", no_wrap=True)
    table.add_column("System Status", style="magenta")
    table.add_column("Location", style="white")
    table.add_column("ReconForge Integration", style="dim")

    for s in status_data:
        stat_label = "[green][OK] Installed[/green]" if s["installed"] else "[dim yellow]Not in PATH[/dim yellow]"
        table.add_row(s["name"], stat_label, s["path"], s["role"])

    console.print(table)
    console.print("\n[dim]Note: ReconForge functions autonomously with built-in asynchronous engines if external binaries are absent.[/dim]\n")

def execute_scan(
    domain: Optional[str] = None,
    url: Optional[str] = None,
    profile: str = "standard",
    custom_ports: Optional[List[int]] = None,
    enable_full_ports: bool = False,
    enable_headers: bool = False,
    enable_tls: bool = False,
    enable_all: bool = False,
    enable_vuln_scan: bool = False,
    enable_directories: bool = False,
    enable_deep_dns: bool = False,
    enable_ip_intel: bool = False,
    enable_nmap: bool = False,
    output: Optional[str] = None,
    json_output: bool = False,
    verbose: bool = False,
    quiet: bool = False,
    no_color: bool = False,
    exclude: Optional[str] = None,
    scope: Optional[str] = None
) -> bool:
    console = get_console(no_color, to_stderr=json_output)

    # Validate target inputs
    if domain and url:
        if json_output:
            sys.stderr.write("Error: Cannot specify both -u/--url and -d/--domain simultaneously. Specify either a target URL or a domain/host.\n")
        else:
            console.print("[bold red][!] Error:[/bold red] Cannot specify both -u/--url and -d/--domain simultaneously.")
        return False

    if not domain and not url:
        if json_output:
            sys.stderr.write("Error: Must specify a target via -u/--url or -d/--domain.\n")
        else:
            console.print("[bold red][!] Error:[/bold red] Must specify a target via -u/--url or -d/--domain.")
        return False

    # 1. Target Normalization and Validation
    if url:
        try:
            parsed_u = TargetNormalizationScanner.parse_url_target(url)
            domain_to_scan = parsed_u["host"]
        except ValueError as e:
            if json_output:
                sys.stderr.write(f"Error: Invalid target URL '{url}': {e}\n")
            else:
                console.print(f"[bold red][!] Error:[/bold red] Invalid target URL '{url}': {e}")
            return False
    else:
        domain_to_scan = TargetNormalizationScanner.normalize_input(domain)
        if not TargetNormalizationScanner.is_valid_target(domain_to_scan):
            if json_output:
                sys.stderr.write(f"Error: Invalid target format '{domain}'. Must be a valid domain or IP address.\n")
            else:
                console.print(f"[bold red][!] Error:[/bold red] Invalid target format: '{domain}'. Must be a valid domain or IP address.")
            return False

    exclude_list = [e.strip() for e in exclude.split(",") if e.strip()] if exclude else []
    scope_list = [s.strip() for s in scope.split(",") if s.strip()] if scope else []

    runner = PipelineRunner(
        target_domain=domain_to_scan,
        target_url=url,
        profile=profile,
        custom_ports=custom_ports,
        exclude_hosts=exclude_list,
        scope=scope_list,
        enable_headers=enable_headers,
        enable_tls=enable_tls,
        enable_all=enable_all,
        enable_vuln_scan=enable_vuln_scan,
        enable_full_ports=enable_full_ports,
        enable_directories=enable_directories,
        enable_deep_dns=enable_deep_dns,
        enable_ip_intel=enable_ip_intel,
        enable_nmap=enable_nmap,
        quiet=quiet,
        verbose=verbose,
        no_color=no_color,
        json_mode=json_output
    )

    ctx = asyncio.run(runner.run())

    # Build consistent JSON deliverable
    duration = 0.0
    if ctx.end_time and ctx.start_time:
        duration = round((ctx.end_time - ctx.start_time).total_seconds(), 2)

    live_subs = [s for s, d in ctx.subdomains.items() if d.get("is_live")]
    sev_counts = {}
    for f in ctx.findings:
        s = f.get("severity", "Low")
        sev_counts[s] = sev_counts.get(s, 0) + 1

    report_data = {
        "target": ctx.target_url if ctx.target_url else ctx.normalized_domain,
        "domain": ctx.normalized_domain,
        "target_url": ctx.target_url,
        "profile": ctx.profile,
        "scan_date": ctx.start_time.isoformat(),
        "duration_seconds": duration,
        "risk_score": ctx.risk_score,
        "invoked_tools": ctx.invoked_tools,
        "statistics": {
            "subdomains_total": len(ctx.subdomains),
            "live_subdomains": len(live_subs),
            "open_ports": len(ctx.open_ports),
            "http_services": len(ctx.http_assets),
            "findings_total": len(ctx.findings),
            "findings_by_severity": sev_counts
        },
        "subdomains": ctx.subdomains,
        "open_ports": ctx.open_ports,
        "http_assets": ctx.http_assets,
        "findings": ctx.findings
    }

    # In JSON mode, write valid JSON strictly to stdout
    if json_output:
        sys.stdout.write(json.dumps(report_data, indent=2) + "\n")
        sys.stdout.flush()
        return True

    # Save to user-selected file or directory if requested
    if output:
        out_p = Path(output)
        if out_p.is_dir() or (not out_p.suffix and not out_p.exists()):
            out_p.mkdir(parents=True, exist_ok=True)
            out_file = out_p / f"recon_{ctx.normalized_domain}.json"
        else:
            out_p.parent.mkdir(parents=True, exist_ok=True)
            out_file = out_p

        with open(out_file, "w", encoding="utf-8") as f:
            json.dump(report_data, f, indent=2)
        console.print(f"[bold green][+] Report exported to:[/bold green] [white]{out_file.resolve()}[/white]")

    return True

# ----------------- Subcommands ----------------- #

@cli.command("scan")
@click.option("-d", "--domain", help="Target domain or host (e.g. example.com)")
@click.option("-u", "--url", "target_url", help="Target URL (e.g. https://example.com)")
@click.option("--profile", type=click.Choice(["quick", "standard", "full", "passive"]), default="standard", help="Scan depth profile")
@click.option("--quick", is_flag=True, help="High-speed triage (subdomains, DNS)")
@click.option("--passive", is_flag=True, help="Passive data sources only (zero direct target packets)")
@click.option("--full", "full_flag", is_flag=True, help="Full assessment with all advanced modules enabled")
@click.option("--all", "all_flag", is_flag=True, help="Run all implemented, compatible reconnaissance modules")
@click.option("-p", "--ports", help="Custom comma-separated port list (e.g. 80,443,8080)")
@click.option("--full-ports", is_flag=True, help="Scan extended/full TCP ports list")
@click.option("--headers", is_flag=True, help="Check HTTP security headers (HSTS, CSP, etc.)")
@click.option("--tls", is_flag=True, help="Inspect TLS certificate validity and configuration")
@click.option("--vuln-scan", is_flag=True, help="Opt-in: Run Nuclei vulnerability scanner templates")
@click.option("--directories", is_flag=True, help="Opt-in: Run directory and file discovery")
@click.option("--deep-dns", is_flag=True, help="Opt-in: Run deep DNS records and takeover checks")
@click.option("--ip-intel", is_flag=True, help="Opt-in: Run reverse PTR, ASN and IP intelligence")
@click.option("--nmap", is_flag=True, help="Opt-in: Enable native Nmap engine if installed in PATH")
@click.option("-o", "--output", help="Save deliverable JSON report to file or directory path")
@click.option("--json", "json_output", is_flag=True, help="Output machine-readable JSON to stdout only")
@click.option("-v", "--verbose", is_flag=True, help="Enable verbose diagnostics")
@click.option("-q", "--quiet", is_flag=True, help="Quiet mode: suppress non-essential output")
@click.option("--no-color", is_flag=True, help="Disable color formatting")
@click.option("--exclude", help="Comma-separated hosts or wildcards to exclude from scope")
@click.option("--scope", help="Comma-separated scope boundaries")
def cmd_scan(
    domain, target_url, profile, quick, passive, full_flag, all_flag, ports, full_ports,
    headers, tls, vuln_scan, directories, deep_dns, ip_intel, nmap,
    output, json_output, verbose, quiet, no_color, exclude, scope
):
    """Execute a modular reconnaissance assessment against a target."""
    if domain and target_url:
        err_msg = "Error: Cannot specify both -u/--url and -d/--domain simultaneously. Specify either a target URL or a domain/host.\n"
        if json_output:
            sys.stderr.write(err_msg)
        else:
            get_console(no_color).print(f"[bold red][!] {err_msg.strip()}[/bold red]")
        sys.exit(1)

    if not domain and not target_url:
        err_msg = "Error: Must specify either -u/--url or -d/--domain.\n"
        if json_output:
            sys.stderr.write(err_msg)
        else:
            get_console(no_color).print(f"[bold red][!] {err_msg.strip()}[/bold red]")
        sys.exit(1)

    if quick:
        profile = "quick"
    elif passive:
        profile = "passive"
    elif full_flag:
        profile = "full"

    custom_ports = [int(p.strip()) for p in ports.split(",") if p.strip().isdigit()] if ports else None

    success = execute_scan(
        domain=domain,
        url=target_url,
        profile=profile,
        custom_ports=custom_ports,
        enable_full_ports=full_ports,
        enable_headers=headers,
        enable_tls=tls,
        enable_all=all_flag,
        enable_vuln_scan=vuln_scan,
        enable_directories=directories,
        enable_deep_dns=deep_dns,
        enable_ip_intel=ip_intel,
        enable_nmap=nmap,
        output=output,
        json_output=json_output,
        verbose=verbose,
        quiet=quiet,
        no_color=no_color,
        exclude=exclude,
        scope=scope
    )
    sys.exit(0 if success else 1)

@cli.command("subdomains")
@click.option("-d", "--domain", required=True, help="Target domain (e.g. example.com)")
@click.option("--refresh", is_flag=True, help="Force refresh and re-run subdomain discovery")
@click.option("-o", "--output", help="Save discovered subdomains to text file")
@click.option("--no-color", is_flag=True, help="Plain-text output")
def cmd_subdomains(domain, refresh, output, no_color):
    """List or discover subdomains for a target."""
    console = get_console(no_color)
    normalized = TargetNormalizationScanner.normalize_input(domain)
    if not TargetNormalizationScanner.is_valid_target(normalized):
        console.print(f"[bold red][!] Error:[/bold red] Invalid domain format: '{domain}'.")
        sys.exit(1)

    async def _handle():
        await init_db()
        subs = await get_target_subdomains(normalized)
        if not subs or refresh:
            console.print(f"[*] Enumerating subdomains for [bold cyan]{normalized}[/bold cyan]...")
            runner = PipelineRunner(
                target_domain=normalized,
                profile="passive",
                quiet=False,
                no_color=no_color
            )
            await runner.run()
            subs = await get_target_subdomains(normalized)

        if not subs:
            console.print(f"[yellow]No subdomains discovered for {normalized}.[/yellow]")
            return

        table = Table(title=f"Discovered Subdomains: {normalized}")
        table.add_column("Subdomain", style="bold cyan")
        table.add_column("Status", style="green")
        table.add_column("CNAME / Target", style="magenta")

        seen = set()
        sub_names = []
        for s in subs:
            if s.name in seen:
                continue
            seen.add(s.name)
            sub_names.append(s.name)
            status = "[green]Live[/green]" if s.is_live else "[dim]Dead[/dim]"
            cname = s.cname_target or "-"
            if s.takeover_vulnerable:
                cname = f"[bold red]TAKEOVER: {s.takeover_service}[/bold red]"
            table.add_row(s.name, status, cname)

        console.print(table)
        console.print(f"[dim]Total: {len(seen)} unique subdomains.[/dim]")

        if output:
            with open(output, "w", encoding="utf-8") as f:
                for name in sorted(sub_names):
                    f.write(f"{name}\n")
            console.print(f"[green][+] Exported to {output}[/green]")

    asyncio.run(_handle())

@cli.command("console")
def cmd_console():
    """Launch the interactive Metasploit-style assessment console."""
    from .console import ReconForgeConsole
    console_app = ReconForgeConsole()
    console_app.start()

@cli.command("hosts")
def cmd_hosts():
    """Display discovered targets and host inventories."""
    async def _show():
        await init_db()
        targets = await get_all_targets()
        if not targets:
            get_console().print("[yellow]No targets found in database. Run a scan first with 'reconforge scan -d <domain>'.[/yellow]")
            return

        table = Table(title="Target Inventory (~/.reconforge/reconforge.db)")
        table.add_column("Domain", style="bold cyan")
        table.add_column("Risk Score", style="magenta")
        table.add_column("Last Scanned", style="white")

        for t in targets:
            score_color = "green" if t.risk_score < 30 else ("yellow" if t.risk_score < 70 else "red")
            table.add_row(t.domain, f"[{score_color}]{t.risk_score}/100[/{score_color}]", str(t.last_scanned)[:19])

        get_console().print(table)
    asyncio.run(_show())

@cli.command("services")
@click.option("-d", "--domain", required=True, help="Target domain to inspect")
def cmd_services(domain):
    """Display open ports and services for a target."""
    console = get_console()
    normalized = TargetNormalizationScanner.normalize_input(domain)
    async def _show():
        await init_db()
        ports = await get_target_ports(normalized)
        if not ports:
            console.print(f"[yellow]No open ports recorded for {normalized}.[/yellow]")
            return

        table = Table(title=f"Discovered Services: {normalized}")
        table.add_column("IP Address", style="cyan")
        table.add_column("Port", style="bold green")
        table.add_column("Protocol", style="magenta")
        table.add_column("Service", style="white")
        table.add_column("Banner", style="dim")

        for p in ports:
            table.add_row(p["ip"], str(p["port"]), p["protocol"], p["service"], (p["banner"] or "")[:40])

        console.print(table)
    asyncio.run(_show())

@cli.command("vulns")
@click.option("-d", "--domain", help="Filter by target domain")
def cmd_vulns(domain):
    """Display security findings and exposure vectors."""
    console = get_console()
    normalized = TargetNormalizationScanner.normalize_input(domain) if domain else None
    async def _show():
        await init_db()
        findings = await get_target_findings(normalized)
        if not findings:
            console.print("[green]No vulnerabilities or exposure vectors recorded.[/green]")
            return

        table = Table(title=f"Discovered Findings {f'({normalized})' if normalized else ''}")
        table.add_column("Severity", style="bold")
        table.add_column("Confidence", style="magenta")
        table.add_column("Title", style="white")
        table.add_column("Affected Endpoint", style="cyan")
        table.add_column("Category", style="dim")

        for f in findings:
            sev = f.severity
            s_style = "bold red" if sev in ["Critical", "High"] else ("yellow" if sev == "Medium" else "blue")
            conf = getattr(f, "confidence", "confirmed") or "confirmed"
            table.add_row(f"[{s_style}]{sev}[/{s_style}]", conf, f.title, (f.affected_url or "")[:50], f.category)

        console.print(table)
    asyncio.run(_show())

@cli.command("check")
@click.option("--json", "json_output", is_flag=True, help="Output readiness as JSON")
@click.option("--no-color", is_flag=True, help="Disable color formatting")
def cmd_check(json_output, no_color):
    """Check readiness of external binaries and engines."""
    run_tool_check(no_color=no_color, json_output=json_output)

if __name__ == "__main__":
    cli()
