import asyncio
import os
import sys
import shutil
import json
from pathlib import Path
from typing import Optional, List
import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from .banner import print_banner, BANNER_ART
from .config import config
from .db import (
    init_db, get_all_targets, get_target_by_domain,
    get_target_subdomains, get_target_ports,
    get_target_http_assets, get_target_findings, delete_target
)
from .pipeline.runner import PipelineRunner
from .pipeline.phases.phase1_target import TargetNormalizationScanner

def get_console(no_color: bool = False) -> Console:
    return Console(no_color=no_color or bool(os.environ.get("NO_COLOR")))

@click.group(invoke_without_command=True)
@click.option("-d", "--domain", help="Target domain or host for immediate scan (e.g., example.com)")
@click.option("--profile", type=click.Choice(["quick", "standard", "full", "passive"]), default="standard", help="Scan depth profile")
@click.option("-o", "--output", help="Save deliverable JSON report to file or directory")
@click.option("--json", "json_output", is_flag=True, help="Output machine-readable JSON directly to stdout")
@click.option("-v", "--verbose", is_flag=True, help="Enable verbose scanner execution output")
@click.option("-q", "--quiet", is_flag=True, help="Quiet mode: suppress banners and progress indicators")
@click.option("--no-color", is_flag=True, help="Disable colored output (plain-text fallback)")
@click.option("--exclude", help="Comma-separated hosts or wildcards to exclude from scope")
@click.option("--nmap", is_flag=True, help="Enable native Nmap engine if installed in system PATH")
@click.option("--version", is_flag=True, help="Display ReconForge version information")
@click.option("--check", is_flag=True, help="Check host dependencies and external tools readiness")
@click.pass_context
def cli(ctx, domain, profile, output, json_output, verbose, quiet, no_color, exclude, nmap, version, check):
    """ReconForge: Linux Terminal Reconnaissance & Attack Surface Management Platform."""
    console = get_console(no_color)

    if version:
        console.print(f"ReconForge version {config.version} (Linux Native)")
        sys.exit(0)

    if check:
        run_tool_check(no_color=no_color)
        sys.exit(0)

    # Direct scan when -d is supplied at root level (e.g. reconforge -d example.com)
    if domain:
        success = run_scan_action(
            domain=domain,
            profile=profile,
            output=output,
            json_output=json_output,
            verbose=verbose,
            quiet=quiet,
            no_color=no_color,
            exclude=exclude,
            enable_nmap=nmap
        )
        sys.exit(0 if success else 1)

    # Launch interactive console if no subcommand and no target provided
    if ctx.invoked_subcommand is None:
        from .console import ReconForgeConsole
        console_app = ReconForgeConsole()
        console_app.start()

def run_tool_check(no_color: bool = False):
    console = get_console(no_color)
    print_banner(show_tip=False)
    console.print(Panel("[bold yellow]ReconForge Linux Security Engine & Tooling Status[/bold yellow]", expand=False))
    tools = [
        {"name": "Python 3", "bin": "python3", "desc": "Core Execution Runtime", "fallback": "Required"},
        {"name": "Nmap", "bin": config.nmap_path, "desc": "Port & Banner Discovery", "fallback": "ReconForge Async TCP Socket Engine"},
        {"name": "Subfinder", "bin": config.subfinder_path, "desc": "Passive Subdomain OSINT", "fallback": "Built-in crt.sh & AlienVault OTX"},
        {"name": "Nuclei", "bin": config.nuclei_path, "desc": "Vulnerability Template Audit", "fallback": "Built-in Safe Exposure Scanner"}
    ]

    table = Table(title="Security Tool Readiness")
    table.add_column("Engine / Binary", style="cyan", no_wrap=True)
    table.add_column("System Status", style="magenta")
    table.add_column("Active Mode", style="green")
    table.add_column("Fallback Mechanism", style="white")

    for t in tools:
        path = shutil.which(t["bin"])
        status = "[green][OK] Installed[/green]" if path else "[dim yellow]Not in PATH[/dim yellow]"
        mode = "[bold green]Native Hardware[/bold green]" if path else "[cyan]Native Python Engine[/cyan]"
        table.add_row(t["name"], status, mode, t["fallback"])

    console.print(table)
    console.print("\n[bold green][+] Platform is fully operational for authorized assessments.[/bold green]\n")

def run_scan_action(
    domain: str,
    profile: str = "standard",
    output: Optional[str] = None,
    custom_ports: Optional[List[int]] = None,
    json_output: bool = False,
    verbose: bool = False,
    quiet: bool = False,
    no_color: bool = False,
    exclude: Optional[str] = None,
    scope: Optional[str] = None,
    enable_nmap: bool = False
) -> bool:
    console = get_console(no_color)
    
    # Pre-validate target syntax before launching runner
    normalized = TargetNormalizationScanner.normalize_input(domain)
    if not TargetNormalizationScanner.is_valid_target(normalized):
        console.print(f"[bold red][!] Error:[/bold red] Invalid target format: '{domain}'. Must be a valid domain name or IP address.")
        return False

    exclude_list = [e.strip() for e in exclude.split(",") if e.strip()] if exclude else []
    scope_list = [s.strip() for s in scope.split(",") if s.strip()] if scope else []

    if not quiet and not json_output:
        print_banner(show_tip=False)
        console.print("[dim][!] Authorized security assessment mode. Ensure proper scope permissions.[/dim]")

    runner = PipelineRunner(
        target_domain=domain,
        profile=profile,
        custom_ports=custom_ports,
        exclude_hosts=exclude_list,
        scope=scope_list,
        enable_nmap=enable_nmap,
        quiet=quiet,
        verbose=verbose,
        no_color=no_color,
        json_mode=json_output
    )

    ctx = asyncio.run(runner.run())

    # Build report data
    duration = 0.0
    if ctx.end_time and ctx.start_time:
        duration = round((ctx.end_time - ctx.start_time).total_seconds(), 2)

    live_subs = [s for s, d in ctx.subdomains.items() if d.get("is_live")]
    report_data = {
        "target": ctx.normalized_domain,
        "profile": ctx.profile,
        "duration_seconds": duration,
        "risk_score": ctx.risk_score,
        "statistics": {
            "subdomains_total": len(ctx.subdomains),
            "live_subdomains": len(live_subs),
            "open_ports": len(ctx.open_ports),
            "http_services": len(ctx.http_assets),
            "findings": len(ctx.findings)
        },
        "subdomains": ctx.subdomains,
        "ip_infrastructure": ctx.ip_records,
        "open_ports": ctx.open_ports,
        "http_assets": ctx.http_assets,
        "findings": ctx.findings
    }

    # JSON stdout output
    if json_output:
        print(json.dumps(report_data, indent=2))
        return True

    # Save to user-selected output file or directory
    if output:
        out_p = Path(output)
        if out_p.is_dir() or (not out_p.suffix and not out_p.exists()):
            out_p.mkdir(parents=True, exist_ok=True)
            out_file = out_p / f"recon_{ctx.normalized_domain}.json"
        else:
            out_p.parent.mkdir(parents=True, exist_ok=True)
            out_file = out_p

        with open(out_file, "w", encoding="utf-8") as f:
            json.dump(report_data, f, indent=2)
        console.print(f"[bold green][+] Results exported to:[/bold green] [white]{out_file.resolve()}[/white]")

    return True

# ----------------- CLI Subcommands ----------------- #

@cli.command("scan")
@click.option("-d", "--domain", required=True, help="Target domain or host (e.g. example.com)")
@click.option("--profile", type=click.Choice(["quick", "standard", "full", "passive"]), default="standard", help="Scan depth profile")
@click.option("--quick", is_flag=True, help="High-speed scan (top 20 ports)")
@click.option("--passive", is_flag=True, help="Passive OSINT only (no port scan or active probes)")
@click.option("-p", "--ports", help="Custom port list comma-separated (e.g. 80,443,8080)")
@click.option("-o", "--output", help="Save deliverable JSON report to file or directory path")
@click.option("--json", "json_output", is_flag=True, help="Output machine-readable JSON to stdout")
@click.option("-v", "--verbose", is_flag=True, help="Enable verbose output")
@click.option("-q", "--quiet", is_flag=True, help="Quiet mode: suppress non-essential output")
@click.option("--no-color", is_flag=True, help="Disable color formatting")
@click.option("--exclude", help="Comma-separated hosts or wildcards to exclude from scan")
@click.option("--scope", help="Comma-separated scope boundaries")
@click.option("--nmap", is_flag=True, help="Enable Nmap port engine if available")
def cmd_scan(domain, profile, quick, passive, ports, output, json_output, verbose, quiet, no_color, exclude, scope, nmap):
    """Execute a complete reconnaissance assessment against a target."""
    if quick:
        profile = "quick"
    elif passive:
        profile = "passive"

    custom_ports = [int(p.strip()) for p in ports.split(",") if p.strip().isdigit()] if ports else None

    success = run_scan_action(
        domain=domain,
        profile=profile,
        output=output,
        custom_ports=custom_ports,
        json_output=json_output,
        verbose=verbose,
        quiet=quiet,
        no_color=no_color,
        exclude=exclude,
        scope=scope,
        enable_nmap=nmap
    )
    sys.exit(0 if success else 1)

@cli.command("subdomains")
@click.option("-d", "--domain", required=True, help="Target domain (e.g. example.com)")
@click.option("--passive", is_flag=True, help="Perform live passive enumeration if not in database")
@click.option("--refresh", is_flag=True, help="Force refresh and re-run subdomain discovery")
@click.option("-o", "--output", help="Save discovered subdomains to text file")
@click.option("--no-color", is_flag=True, help="Plain-text output")
def cmd_subdomains(domain, passive, refresh, output, no_color):
    """List or discover subdomains for a target."""
    console = get_console(no_color)
    normalized = TargetNormalizationScanner.normalize_input(domain)
    if not TargetNormalizationScanner.is_valid_target(normalized):
        console.print(f"[bold red][!] Error:[/bold red] Invalid domain format: '{domain}'.")
        sys.exit(1)

    async def _handle():
        await init_db()
        subs = await get_target_subdomains(normalized)
        if not subs or refresh:
            console.print(f"[*] Enumerating subdomains for [bold cyan]{normalized}[/bold cyan]...")
            runner = PipelineRunner(
                target_domain=normalized,
                profile="passive",
                quiet=False,
                no_color=no_color
            )
            await runner.run()
            subs = await get_target_subdomains(normalized)

        if not subs:
            console.print(f"[yellow]No subdomains discovered for {normalized}.[/yellow]")
            return

        table = Table(title=f"Discovered Subdomains: {normalized}")
        table.add_column("Subdomain", style="bold cyan")
        table.add_column("Status", style="green")
        table.add_column("CNAME / Target", style="magenta")

        seen = set()
        sub_names = []
        for s in subs:
            if s.name in seen:
                continue
            seen.add(s.name)
            sub_names.append(s.name)
            status = "[green]Live[/green]" if s.is_live else "[dim]Dead[/dim]"
            cname = s.cname_target or "-"
            if s.takeover_vulnerable:
                cname = f"[bold red]TAKEOVER: {s.takeover_service}[/bold red]"
            table.add_row(s.name, status, cname)

        console.print(table)
        console.print(f"[dim]Total: {len(seen)} unique subdomains.[/dim]")

        if output:
            with open(output, "w", encoding="utf-8") as f:
                for name in sorted(sub_names):
                    f.write(f"{name}\n")
            console.print(f"[green][+] Subdomain list exported to {output}[/green]")

    asyncio.run(_handle())

@cli.command("console")
def cmd_console():
    """Launch the interactive Metasploit-style assessment console."""
    from .console import ReconForgeConsole
    console_app = ReconForgeConsole()
    console_app.start()

@cli.command("hosts")
def cmd_hosts():
    """Display discovered targets and host inventories."""
    async def _show():
        await init_db()
        targets = await get_all_targets()
        if not targets:
            console = get_console()
            console.print("[yellow]No targets found in database. Run a scan first with 'reconforge scan -d <domain>'.[/yellow]")
            return

        table = Table(title="Target Inventory (~/.reconforge/reconforge.db)")
        table.add_column("Domain", style="bold cyan")
        table.add_column("Risk Score", style="magenta")
        table.add_column("Last Scanned", style="white")

        for t in targets:
            score_color = "green" if t.risk_score < 30 else ("yellow" if t.risk_score < 70 else "red")
            table.add_row(t.domain, f"[{score_color}]{t.risk_score}/100[/{score_color}]", str(t.last_scanned)[:19])

        get_console().print(table)
    asyncio.run(_show())

@cli.command("services")
@click.option("-d", "--domain", required=True, help="Target domain to inspect")
def cmd_services(domain):
    """Display open ports and services for a target."""
    console = get_console()
    normalized = TargetNormalizationScanner.normalize_input(domain)
    async def _show():
        await init_db()
        ports = await get_target_ports(normalized)
        if not ports:
            console.print(f"[yellow]No open ports recorded for {normalized}.[/yellow]")
            return

        table = Table(title=f"Discovered Services: {normalized}")
        table.add_column("IP Address", style="cyan")
        table.add_column("Port", style="bold green")
        table.add_column("Protocol", style="magenta")
        table.add_column("Service", style="white")
        table.add_column("Banner", style="dim")

        for p in ports:
            table.add_row(p["ip"], str(p["port"]), p["protocol"], p["service"], (p["banner"] or "")[:40])

        console.print(table)
    asyncio.run(_show())

@cli.command("vulns")
@click.option("-d", "--domain", help="Filter by target domain")
def cmd_vulns(domain):
    """Display security findings and exposure vectors."""
    console = get_console()
    normalized = TargetNormalizationScanner.normalize_input(domain) if domain else None
    async def _show():
        await init_db()
        findings = await get_target_findings(normalized)
        if not findings:
            console.print("[green]No vulnerabilities or exposure vectors recorded.[/green]")
            return

        table = Table(title=f"Discovered Findings & Exposures {f'({normalized})' if normalized else ''}")
        table.add_column("Severity", style="bold")
        table.add_column("Title", style="white")
        table.add_column("Affected Endpoint", style="cyan")
        table.add_column("Category", style="dim")

        for f in findings:
            sev = f.severity
            s_style = "bold red" if sev in ["Critical", "High"] else ("yellow" if sev == "Medium" else "blue")
            table.add_row(f"[{s_style}]{sev}[/{s_style}]", f.title, (f.affected_url or "")[:50], f.category)

        console.print(table)
    asyncio.run(_show())

@cli.command("check")
def cmd_check():
    """Check readiness of external binaries and engines."""
    run_tool_check()

if __name__ == "__main__":
    cli()
