import asyncio
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any
from sqlalchemy import select, delete, text
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import selectinload

from .config import config
from .models import Base, Target, Subdomain, IPAddress, Port, HTTPAsset, Finding, ScanRecord

engine = create_async_engine(config.database_url, echo=False)
AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

CURRENT_SCHEMA_VERSION = 3

def apply_migrations(connection):
    """Safely migrate existing SQLite schema to include missing columns without data loss.

    Supports both raw sqlite3.Connection and SQLAlchemy sync Connection.
    """
    is_raw_sqlite = hasattr(connection, "cursor") and not hasattr(connection, "execute_driver_sql")

    def _exec(sql_str):
        if is_raw_sqlite:
            cur = connection.cursor()
            cur.execute(sql_str)
            return cur
        else:
            return connection.execute(text(sql_str))

    def _fetchall(sql_str):
        if is_raw_sqlite:
            cur = connection.cursor()
            cur.execute(sql_str)
            return cur.fetchall()
        else:
            res = connection.execute(text(sql_str))
            return res.fetchall()

    # 0. Versioned migration tracking table
    _exec("""
        CREATE TABLE IF NOT EXISTS schema_version (
            version INTEGER PRIMARY KEY,
            applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            description TEXT
        )
    """)

    res = _fetchall("SELECT version FROM schema_version")
    applied_versions = {row[0] for row in res}

    # Version 1: Findings table columns (confidence, rationale)
    findings_rows = _fetchall("PRAGMA table_info(findings)")
    findings_cols = [row[1] for row in findings_rows]
    if findings_cols:
        if "confidence" not in findings_cols:
            _exec("ALTER TABLE findings ADD COLUMN confidence VARCHAR(50) DEFAULT 'unspecified'")
        if "rationale" not in findings_cols:
            _exec("ALTER TABLE findings ADD COLUMN rationale TEXT DEFAULT ''")
        if 1 not in applied_versions:
            _exec("INSERT OR IGNORE INTO schema_version (version, description) VALUES (1, 'Add confidence and rationale to findings')")

    # Version 2: Subdomains table columns (source)
    sub_rows = _fetchall("PRAGMA table_info(subdomains)")
    sub_cols = [row[1] for row in sub_rows]
    if sub_cols:
        if "source" not in sub_cols:
            _exec("ALTER TABLE subdomains ADD COLUMN source VARCHAR(100) DEFAULT 'legacy_migration'")
        if 2 not in applied_versions:
            _exec("INSERT OR IGNORE INTO schema_version (version, description) VALUES (2, 'Add source to subdomains')")

    # Version 3: Targets table columns (risk_score)
    target_rows = _fetchall("PRAGMA table_info(targets)")
    target_cols = [row[1] for row in target_rows]
    if target_cols:
        if "risk_score" not in target_cols:
            _exec("ALTER TABLE targets ADD COLUMN risk_score FLOAT DEFAULT 0.0")
        if 3 not in applied_versions:
            _exec("INSERT OR IGNORE INTO schema_version (version, description) VALUES (3, 'Add risk_score to targets')")

    if is_raw_sqlite:
        connection.commit()

def _migrate_db_schema_sync(connection):
    apply_migrations(connection)

async def init_db(target_engine=None):
    eng = target_engine or engine
    async with eng.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        await conn.run_sync(_migrate_db_schema_sync)

async def get_or_create_target(domain: str, description: str = "") -> Target:
    async with AsyncSessionLocal() as session:
        stmt = select(Target).where(Target.domain == domain)
        res = await session.execute(stmt)
        target = res.scalars().first()
        if not target:
            target = Target(domain=domain, description=description)
            session.add(target)
            await session.commit()
            await session.refresh(target)
        else:
            target.last_scanned = datetime.now(timezone.utc)
            await session.commit()
            await session.refresh(target)
        return target

async def get_all_targets() -> List[Target]:
    async with AsyncSessionLocal() as session:
        stmt = select(Target).order_by(Target.last_scanned.desc())
        res = await session.execute(stmt)
        return list(res.scalars().all())

async def get_target_by_domain(domain: str) -> Optional[Target]:
    async with AsyncSessionLocal() as session:
        stmt = select(Target).where(Target.domain == domain).options(
            selectinload(Target.subdomains),
            selectinload(Target.ip_addresses).selectinload(IPAddress.ports),
            selectinload(Target.http_assets),
            selectinload(Target.findings)
        )
        res = await session.execute(stmt)
        return res.scalars().first()

async def get_target_subdomains(domain: str) -> List[Subdomain]:
    async with AsyncSessionLocal() as session:
        stmt = select(Subdomain).join(Target).where(Target.domain == domain).order_by(Subdomain.name)
        res = await session.execute(stmt)
        return list(res.scalars().all())

async def get_target_ports(domain: str) -> List[Dict[str, Any]]:
    async with AsyncSessionLocal() as session:
        stmt = (
            select(Port, IPAddress.ip, Target.domain)
            .join(IPAddress, Port.ip_id == IPAddress.id)
            .join(Target, IPAddress.target_id == Target.id)
            .where(Target.domain == domain)
            .order_by(Port.port_number)
        )
        res = await session.execute(stmt)
        results = []
        for port, ip, dom in res.all():
            results.append({
                "ip": ip,
                "port": port.port_number,
                "protocol": port.protocol,
                "state": port.state,
                "service": port.service_name or "unknown",
                "banner": port.service_banner or ""
            })
        return results

async def get_target_http_assets(domain: str) -> List[HTTPAsset]:
    async with AsyncSessionLocal() as session:
        stmt = select(HTTPAsset).join(Target).where(Target.domain == domain).order_by(HTTPAsset.url)
        res = await session.execute(stmt)
        return list(res.scalars().all())

async def get_target_findings(domain: Optional[str] = None) -> List[Finding]:
    async with AsyncSessionLocal() as session:
        stmt = select(Finding).join(Target)
        if domain:
            stmt = stmt.where(Target.domain == domain)
        stmt = stmt.order_by(Finding.created_at.desc())
        res = await session.execute(stmt)
        return list(res.scalars().all())

async def delete_target(domain: str) -> bool:
    async with AsyncSessionLocal() as session:
        stmt = select(Target).where(Target.domain == domain)
        target = (await session.execute(stmt)).scalars().first()
        if target:
            await session.delete(target)
            await session.commit()
            return True
        return False
