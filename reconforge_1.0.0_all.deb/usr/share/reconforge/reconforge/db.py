import asyncio
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any
from sqlalchemy import select, delete, text
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import selectinload

from .config import config
from .models import Base, Target, Subdomain, IPAddress, Port, HTTPAsset, Finding, ScanRecord

engine = create_async_engine(config.database_url, echo=False)
AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

def _migrate_db_schema_sync(connection):
    """Safely migrate existing SQLite schema to include missing columns without data loss."""
    # 1. Findings table migrations (confidence, rationale)
    res = connection.execute(text("PRAGMA table_info(findings)"))
    findings_cols = [row[1] for row in res.fetchall()]
    if findings_cols:
        if "confidence" not in findings_cols:
            connection.execute(text("ALTER TABLE findings ADD COLUMN confidence VARCHAR(50) DEFAULT 'confirmed'"))
        if "rationale" not in findings_cols:
            connection.execute(text("ALTER TABLE findings ADD COLUMN rationale TEXT DEFAULT ''"))

    # 2. Subdomains table migrations (source)
    res = connection.execute(text("PRAGMA table_info(subdomains)"))
    sub_cols = [row[1] for row in res.fetchall()]
    if sub_cols:
        if "source" not in sub_cols:
            connection.execute(text("ALTER TABLE subdomains ADD COLUMN source VARCHAR(100) DEFAULT 'Passive OSINT'"))

    # 3. Targets table migrations (risk_score)
    res = connection.execute(text("PRAGMA table_info(targets)"))
    target_cols = [row[1] for row in res.fetchall()]
    if target_cols:
        if "risk_score" not in target_cols:
            connection.execute(text("ALTER TABLE targets ADD COLUMN risk_score FLOAT DEFAULT 0.0"))

async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        await conn.run_sync(_migrate_db_schema_sync)

async def get_or_create_target(domain: str, description: str = "") -> Target:
    async with AsyncSessionLocal() as session:
        stmt = select(Target).where(Target.domain == domain)
        res = await session.execute(stmt)
        target = res.scalars().first()
        if not target:
            target = Target(domain=domain, description=description)
            session.add(target)
            await session.commit()
            await session.refresh(target)
        else:
            target.last_scanned = datetime.now(timezone.utc)
            await session.commit()
            await session.refresh(target)
        return target

async def get_all_targets() -> List[Target]:
    async with AsyncSessionLocal() as session:
        stmt = select(Target).order_by(Target.last_scanned.desc())
        res = await session.execute(stmt)
        return list(res.scalars().all())

async def get_target_by_domain(domain: str) -> Optional[Target]:
    async with AsyncSessionLocal() as session:
        stmt = select(Target).where(Target.domain == domain).options(
            selectinload(Target.subdomains),
            selectinload(Target.ip_addresses).selectinload(IPAddress.ports),
            selectinload(Target.http_assets),
            selectinload(Target.findings)
        )
        res = await session.execute(stmt)
        return res.scalars().first()

async def get_target_subdomains(domain: str) -> List[Subdomain]:
    async with AsyncSessionLocal() as session:
        stmt = select(Subdomain).join(Target).where(Target.domain == domain).order_by(Subdomain.name)
        res = await session.execute(stmt)
        return list(res.scalars().all())

async def get_target_ports(domain: str) -> List[Dict[str, Any]]:
    async with AsyncSessionLocal() as session:
        stmt = (
            select(Port, IPAddress.ip, Target.domain)
            .join(IPAddress, Port.ip_id == IPAddress.id)
            .join(Target, IPAddress.target_id == Target.id)
            .where(Target.domain == domain)
            .order_by(Port.port_number)
        )
        res = await session.execute(stmt)
        results = []
        for port, ip, dom in res.all():
            results.append({
                "ip": ip,
                "port": port.port_number,
                "protocol": port.protocol,
                "state": port.state,
                "service": port.service_name or "unknown",
                "banner": port.service_banner or ""
            })
        return results

async def get_target_http_assets(domain: str) -> List[HTTPAsset]:
    async with AsyncSessionLocal() as session:
        stmt = select(HTTPAsset).join(Target).where(Target.domain == domain).order_by(HTTPAsset.url)
        res = await session.execute(stmt)
        return list(res.scalars().all())

async def get_target_findings(domain: Optional[str] = None) -> List[Finding]:
    async with AsyncSessionLocal() as session:
        stmt = select(Finding).join(Target)
        if domain:
            stmt = stmt.where(Target.domain == domain)
        stmt = stmt.order_by(Finding.created_at.desc())
        res = await session.execute(stmt)
        return list(res.scalars().all())

async def delete_target(domain: str) -> bool:
    async with AsyncSessionLocal() as session:
        stmt = select(Target).where(Target.domain == domain)
        target = (await session.execute(stmt)).scalars().first()
        if target:
            await session.delete(target)
            await session.commit()
            return True
        return False
