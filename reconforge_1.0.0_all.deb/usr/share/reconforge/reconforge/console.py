import cmd
import shlex
import asyncio
import os
import sys
from typing import Optional, List
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from .banner import print_banner, BANNER_ART
from .config import config
from .db import (
    init_db, get_all_targets, get_target_by_domain,
    get_target_subdomains, get_target_ports,
    get_target_http_assets, get_target_findings
)
from .pipeline.runner import PipelineRunner

console = Console()

class ReconForgeConsole(cmd.Cmd):
    intro = ""
    prompt = "reconforge > "

    def __init__(self):
        super().__init__()
        self.target: Optional[str] = None
        self.profile: str = "standard"
        self.ports: Optional[str] = None

    def start(self):
        print_banner(show_tip=True)
        console.print("[dim]Type 'help' or '?' for commands. Type 'set target <domain>' to begin.[/dim]\n")
        try:
            self.cmdloop()
        except KeyboardInterrupt:
            console.print("\n[yellow][*] Caught interrupt. Exiting ReconForge console...[/yellow]")
            sys.exit(0)

    def update_prompt(self):
        if self.target:
            self.prompt = f"reconforge ([bold cyan]{self.target}[/bold cyan]) > "
        else:
            self.prompt = "reconforge > "

    # ----------------- Console Commands ----------------- #

    def do_set(self, arg):
        """Set a configuration option. Usage: set <target|profile|ports> <value>"""
        parts = shlex.split(arg)
        if len(parts) < 2:
            console.print("[red]Usage:[/red] set <target|profile|ports> <value>")
            return

        key = parts[0].lower()
        val = parts[1]

        if key in ["target", "domain", "rhost", "rhosts"]:
            self.target = val.strip().lower()
            self.update_prompt()
            console.print(f"[bold green]target =>[/bold green] [cyan]{self.target}[/cyan]")
        elif key == "profile":
            if val.lower() in ["quick", "standard", "full", "passive"]:
                self.profile = val.lower()
                console.print(f"[bold green]profile =>[/bold green] [cyan]{self.profile}[/cyan]")
            else:
                console.print("[red]Invalid profile.[/red] Choose from: quick, standard, full, passive")
        elif key in ["ports", "port"]:
            self.ports = val
            console.print(f"[bold green]ports =>[/bold green] [cyan]{self.ports}[/cyan]")
        else:
            console.print(f"[yellow]Unknown option:[/yellow] {key}")

    def do_show(self, arg):
        """Show options, targets, hosts, services, or vulns. Usage: show <options|targets|hosts|services|vulns>"""
        cmd_type = arg.strip().lower()
        if cmd_type in ["options", ""]:
            self.do_options("")
        elif cmd_type in ["targets", "hosts"]:
            self.do_hosts("")
        elif cmd_type in ["services", "ports"]:
            self.do_services("")
        elif cmd_type in ["vulns", "findings"]:
            self.do_vulns("")
        else:
            console.print("[yellow]Unknown show argument.[/yellow] Options: options, targets, hosts, services, vulns")

    def do_options(self, arg):
        """Display currently set module options."""
        table = Table(title="Module Options", title_style="bold cyan")
        table.add_column("Option", style="cyan", no_wrap=True)
        table.add_column("Current Setting", style="bold white")
        table.add_column("Required", style="magenta")
        table.add_column("Description", style="white")

        table.add_row("TARGET", self.target or "[dim]Not Set[/dim]", "yes", "Target domain or hostname (e.g. example.com)")
        table.add_row("PROFILE", self.profile, "yes", "Scan depth: quick, standard, full, passive")
        table.add_row("PORTS", self.ports or "default", "no", "Custom port list (e.g. 80,443,8080)")
        table.add_row("DATABASE", str(config.db_path), "no", "Local SQLite persistence store")

        console.print(table)

    def do_run(self, arg):
        """Run the reconnaissance assessment against the selected target."""
        if not self.target:
            console.print("[red]Error:[/red] No target set. Run 'set target <domain>' first.")
            return

        custom_p = [int(p.strip()) for p in self.ports.split(",") if p.strip().isdigit()] if self.ports else None
        runner = PipelineRunner(self.target, profile=self.profile, custom_ports=custom_p)
        asyncio.run(runner.run())

    def do_scan(self, arg):
        """Alias for 'run'."""
        self.do_run(arg)

    def do_exploit(self, arg):
        """Alias for 'run' (Metasploit convention)."""
        self.do_run(arg)

    def do_hosts(self, arg):
        """List all targets or discovered subdomains for the active target."""
        async def _run():
            await init_db()
            if self.target:
                subs = await get_target_subdomains(self.target)
                if not subs:
                    console.print(f"[yellow]No subdomains discovered yet for {self.target}. Run 'run' first.[/yellow]")
                    return

                table = Table(title=f"Discovered Hosts: {self.target}")
                table.add_column("Host / Subdomain", style="bold cyan")
                table.add_column("Status", style="green")
                table.add_column("Takeover Risk", style="magenta")

                for s in subs:
                    stat = "[green]Live[/green]" if s.is_live else "[dim]Dead[/dim]"
                    to_info = f"[bold red]{s.takeover_service}[/bold red]" if s.takeover_vulnerable else "[dim]None[/dim]"
                    table.add_row(s.name, stat, to_info)
                console.print(table)
            else:
                targets = await get_all_targets()
                if not targets:
                    console.print("[yellow]Database contains no targets. Use 'set target <domain>' and 'run'.[/yellow]")
                    return

                table = Table(title="Database Targets")
                table.add_column("Domain", style="bold cyan")
                table.add_column("Risk Exposure", style="magenta")
                table.add_column("Last Assessed", style="white")

                for t in targets:
                    sc = "green" if t.risk_score < 30 else ("yellow" if t.risk_score < 70 else "red")
                    table.add_row(t.domain, f"[{sc}]{t.risk_score}/100[/{sc}]", str(t.last_scanned)[:19])
                console.print(table)

        asyncio.run(_run())

    def do_services(self, arg):
        """List open ports and services for the target."""
        if not self.target:
            console.print("[red]Error:[/red] No target selected. Use 'set target <domain>' first.")
            return

        async def _run():
            await init_db()
            ports = await get_target_ports(self.target)
            if not ports:
                console.print(f"[yellow]No open services recorded for {self.target}.[/yellow]")
                return

            table = Table(title=f"Services & Open Ports: {self.target}")
            table.add_column("IP Address", style="cyan")
            table.add_column("Port", style="bold green")
            table.add_column("Protocol", style="magenta")
            table.add_column("Service Name", style="white")
            table.add_column("Banner / Details", style="dim")

            for p in ports:
                table.add_row(p["ip"], str(p["port"]), p["protocol"], p["service"], p["banner"][:40])
            console.print(table)

        asyncio.run(_run())

    def do_vulns(self, arg):
        """List findings and exposure vectors."""
        async def _run():
            await init_db()
            findings = await get_target_findings(self.target)
            if not findings:
                console.print("[green]No vulnerabilities or sensitive exposures recorded.[/green]")
                return

            table = Table(title=f"Vulnerabilities & Exposures {f'({self.target})' if self.target else ''}")
            table.add_column("Severity", style="bold")
            table.add_column("Title", style="white")
            table.add_column("Affected URL", style="cyan")
            table.add_column("Category", style="dim")

            for f in findings:
                sev = f.severity
                s_style = "bold red" if sev in ["Critical", "High"] else ("yellow" if sev == "Medium" else "blue")
                table.add_row(f"[{s_style}]{sev}[/{s_style}]", f.title, (f.affected_url or "")[:50], f.category)
            console.print(table)

        asyncio.run(_run())

    def do_check(self, arg):
        """Check system readiness and external tool availability."""
        from .cli import run_tool_check
        run_tool_check()

    def do_banner(self, arg):
        """Display the ReconForge banner."""
        print_banner(show_tip=True)

    def do_clear(self, arg):
        """Clear the terminal screen."""
        os.system("clear" if os.name == "posix" else "cls")

    def do_exit(self, arg):
        """Exit the ReconForge console."""
        console.print("[dim]Goodbye![/dim]")
        return True

    def do_quit(self, arg):
        """Exit the ReconForge console."""
        return self.do_exit(arg)

    # Autocompletions for Metasploit-like experience
    def complete_set(self, text, line, begidx, endidx):
        options = ["target", "profile", "ports"]
        return [o for o in options if o.startswith(text)]

    def complete_show(self, text, line, begidx, endidx):
        options = ["options", "targets", "hosts", "services", "vulns"]
        return [o for o in options if o.startswith(text)]
