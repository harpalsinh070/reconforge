import json
from datetime import datetime, timezone
from typing import Dict, Any, List
from .base import ScanContext

def render_text_report(ctx: ScanContext, deliverable: Dict[str, Any]) -> str:
    """
    Generate a full, human-readable text report containing all 10 scan sections without truncation.
    """
    lines = []
    sep = "=" * 80
    sub_sep = "-" * 80

    lines.append(sep)
    lines.append("                  RECONFORGE RECONNAISSANCE ASSESSMENT REPORT")
    lines.append(sep)
    lines.append(f"Target:             {deliverable.get('target', ctx.normalized_domain)}")
    lines.append(f"Normalized Domain:  {ctx.normalized_domain}")
    if ctx.target_url:
        lines.append(f"Target URL:         {ctx.target_url}")
    lines.append(f"Scan Profile:       {ctx.profile.upper()}")
    lines.append(f"Scan Timestamp:     {deliverable.get('scan_date', datetime.now(timezone.utc).isoformat())}")
    lines.append(f"Execution Duration: {deliverable.get('duration_seconds', 0.0)}s")
    lines.append(f"Attack Exposure:    {deliverable.get('risk_score', ctx.risk_score)} / 100")
    lines.append(sep)
    lines.append("")

    # Section 1: Target Validation and Scope Status
    lines.append("1. TARGET VALIDATION & SCOPE STATUS")
    lines.append(sub_sep)
    lines.append(f"Primary Target:     {ctx.target or ctx.normalized_domain}")
    lines.append(f"Validation Status:  VALID (Authorized in-scope target)")
    lines.append(f"Scope Boundaries:   {', '.join(ctx.scope) if ctx.scope else 'Autonomous root domain scope'}")
    lines.append(f"Excluded Hosts:     {', '.join(ctx.exclude_hosts) if ctx.exclude_hosts else 'None'}")
    lines.append("")

    # Section 2: All Discovered Subdomains
    live_subs = [s for s, d in ctx.subdomains.items() if d.get("is_live")]
    unresolved_subs = [s for s, d in ctx.subdomains.items() if not d.get("is_live")]
    lines.append("2. DISCOVERED SUBDOMAINS INVENTORY")
    lines.append(sub_sep)
    lines.append(f"Total Discovered: {len(ctx.subdomains)}")
    lines.append(f"Live / Resolved:  {len(live_subs)}")
    lines.append(f"Unresolved:       {len(unresolved_subs)}")
    lines.append("")
    lines.append(f"{'HOSTNAME':<40} {'IP ADDRESS':<24} {'STATUS':<14} {'SOURCE'}")
    lines.append(f"{'-'*40} {'-'*24} {'-'*14} {'-'*16}")

    if ctx.subdomains:
        for sub_name in sorted(ctx.subdomains.keys()):
            s_data = ctx.subdomains[sub_name]
            ips = ", ".join(s_data.get("ips", [])) if s_data.get("ips") else "-"
            status = s_data.get("status", "RESOLVED" if s_data.get("is_live") else "UNRESOLVED")
            source = s_data.get("source", "Passive OSINT")
            lines.append(f"{sub_name:<40} {ips:<24} {status:<14} {source}")
    else:
        lines.append(f"{ctx.normalized_domain:<40} {'-':<24} {'PRIMARY':<14} {'Target Input'}")
    lines.append("")

    # Section 3: DNS Records and Resolved IP Addresses
    lines.append("3. DNS RECORDS & RESOLVED IP ADDRESSES")
    lines.append(sub_sep)
    if ctx.ip_records:
        lines.append(f"{'IP ADDRESS':<20} {'ASSOCIATED HOSTS'}")
        lines.append(f"{'-'*20} {'-'*58}")
        for ip, rec in sorted(ctx.ip_records.items()):
            hosts_str = ", ".join(rec.get("hosts", []))
            lines.append(f"{ip:<20} {hosts_str}")
    else:
        lines.append("No resolved IP addresses recorded.")
    lines.append("")

    # Section 4 & 5: Unique Open TCP Ports & Verified Services (Grouped by Host)
    lines.append("4 & 5. OPEN TCP PORTS & VERIFIED SERVICES (GROUPED BY HOST)")
    lines.append(sub_sep)
    if ctx.open_ports:
        # Group ports by host/ip
        ports_by_host = {}
        for p in ctx.open_ports:
            h_key = p.get("host") or p.get("ip") or ctx.normalized_domain
            ports_by_host.setdefault(h_key, []).append(p)

        for host_key, p_list in sorted(ports_by_host.items()):
            lines.append(f"Host: {host_key} (IP: {p_list[0].get('ip', 'Unknown')})")
            lines.append(f"  {'PORT':<10} {'PROTOCOL':<10} {'SERVICE':<18} {'VERIFIED BANNER / VERSION'}")
            lines.append(f"  {'-'*10} {'-'*10} {'-'*18} {'-'*35}")
            for p in sorted(p_list, key=lambda x: x.get("port", 0)):
                port_str = f"{p.get('port')}/tcp"
                proto = p.get("protocol", "tcp")
                svc = p.get("service", "unknown")
                banner = p.get("banner") or "-"
                lines.append(f"  {port_str:<10} {proto:<10} {svc:<18} {banner}")
            lines.append("")
    else:
        lines.append("No open TCP ports discovered.")
        lines.append("")

    # Section 6: Checked HTTP/HTTPS Endpoints
    lines.append("6. CHECKED HTTP/HTTPS WEB ENDPOINTS")
    lines.append(sub_sep)
    if ctx.http_assets:
        lines.append(f"{'ENDPOINT URL':<42} {'CODE':<6} {'SERVER':<16} {'TITLE'}")
        lines.append(f"{'-'*42} {'-'*6} {'-'*16} {'-'*24}")
        for h in ctx.http_assets:
            u = h.get("url", "")
            code = str(h.get("status_code", "-"))
            server = h.get("web_server") or "-"
            title = h.get("title") or "-"
            lines.append(f"{u:<42} {code:<6} {server:<16} {title}")
    else:
        lines.append("No HTTP/HTTPS endpoints checked during this scan.")
    lines.append("")

    # Section 7: HTTP Security-Header Results
    lines.append("7. HTTP SECURITY-HEADER EVALUATION (PRESENT & MISSING)")
    lines.append(sub_sep)
    if ctx.http_assets:
        for h in ctx.http_assets:
            lines.append(f"Endpoint: {h.get('url')}")
            present = h.get("present_headers", {})
            missing = h.get("missing_headers", [])
            lines.append("  [Present Headers]")
            if present:
                for hk, hv in present.items():
                    lines.append(f"    + {hk}: {hv}")
            else:
                lines.append("    None verified")
            lines.append("  [Missing / Inadequate Headers]")
            if missing:
                for m in missing:
                    lines.append(f"    - {m}")
            else:
                lines.append("    All recommended baseline headers present")
            lines.append("")
    else:
        lines.append("No HTTP security headers checked (Enable via --headers or --all).")
        lines.append("")

    # Section 8: TLS Certificate & Configuration Results
    lines.append("8. TLS CERTIFICATE & CRYPTOGRAPHIC CONFIGURATION")
    lines.append(sub_sep)
    if ctx.tls_data:
        for t_key, t_info in sorted(ctx.tls_data.items()):
            lines.append(f"Target:              {t_key}")
            lines.append(f"Negotiated Protocol: {t_info.get('protocol', 'Unknown')}")
            lines.append(f"Negotiated Cipher:   {t_info.get('cipher', 'Unknown')} ({t_info.get('cipher_bits', 0)} bits)")
            lines.append(f"Certificate Subject: {t_info.get('subject_cn', 'Unknown')}")
            lines.append(f"Certificate Issuer:  {t_info.get('issuer_cn', 'Unknown')}")
            lines.append(f"Expiration Date:     {t_info.get('expires_on', 'Unknown')} ({t_info.get('days_left', 0)} days remaining)")
            if t_info.get("sans"):
                lines.append(f"Subject Alt Names:   {', '.join(t_info.get('sans')[:10])}")
            lines.append("")
    else:
        lines.append("No TLS inspection performed (Enable via --tls or --all).")
        lines.append("")

    # Section 9: Security Findings with Evidence and Remediation
    lines.append("9. SECURITY FINDINGS & EXPOSURES")
    lines.append(sub_sep)
    if ctx.findings:
        for idx, f in enumerate(ctx.findings, 1):
            sev = f.get("severity", "Low").upper()
            conf = f.get("confidence", "confirmed").upper()
            lines.append(f"[{idx}] {f.get('title')}")
            lines.append(f"    Severity:       {sev}")
            lines.append(f"    Confidence:     {conf}")
            lines.append(f"    Category:       {f.get('category', 'General')}")
            lines.append(f"    Affected Asset: {f.get('affected_url', ctx.normalized_domain)}")
            if f.get("evidence"):
                lines.append(f"    Evidence:       {f.get('evidence')}")
            if f.get("rationale"):
                lines.append(f"    Impact / Risk:  {f.get('rationale')}")
            if f.get("recommendation"):
                lines.append(f"    Remediation:    {f.get('recommendation')}")
            lines.append("")
    else:
        lines.append("No security vulnerabilities or exposures identified.")
        lines.append("")

    # Section 10: Scan Duration, Skipped Modules, Errors, Completion Status
    lines.append("10. EXECUTION METRICS & COMPLETION STATUS")
    lines.append(sub_sep)
    lines.append(f"Total Duration:     {deliverable.get('duration_seconds', 0.0)} seconds")
    lines.append(f"Skipped Modules:    {', '.join(ctx.skipped_modules) if ctx.skipped_modules else 'None (all selected modules ran)'}")
    lines.append(f"Execution Errors:   {', '.join(ctx.errors) if ctx.errors else 'None'}")
    lines.append(f"Final Status:       COMPLETED SUCCESSFULLY")
    lines.append(sep)

    return "\n".join(lines) + "\n"
