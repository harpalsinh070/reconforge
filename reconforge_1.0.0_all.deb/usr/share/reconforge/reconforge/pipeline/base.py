import fnmatch
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Callable, Awaitable
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession

@dataclass
class ScanContext:
    target_id: str
    target: str
    normalized_domain: str
    profile: str = "standard"  # quick, standard, full, passive
    custom_ports: Optional[List[int]] = None
    exclude_hosts: List[str] = field(default_factory=list)
    scope: List[str] = field(default_factory=list)
    enable_nmap: bool = False
    start_time: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    end_time: Optional[datetime] = None
    session: Optional[AsyncSession] = None
    log_callback: Optional[Callable[[str, str, str], Awaitable[None]]] = None

    # Pipeline state storage
    subdomains: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    ip_records: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    open_ports: List[Dict[str, Any]] = field(default_factory=list)
    http_assets: List[Dict[str, Any]] = field(default_factory=list)
    findings: List[Dict[str, Any]] = field(default_factory=list)
    risk_score: float = 0.0

    def is_excluded(self, host: str) -> bool:
        """Check if a host or IP is explicitly excluded from scan scope."""
        if not self.exclude_hosts:
            return False
        host_clean = host.strip().lower().rstrip(".")
        for ex in self.exclude_hosts:
            ex_clean = ex.strip().lower().rstrip(".")
            if not ex_clean:
                continue
            if host_clean == ex_clean or fnmatch.fnmatch(host_clean, ex_clean):
                return True
        return False

    def is_in_scope(self, host: str) -> bool:
        """Verify if a host falls within the assessment scope."""
        if self.is_excluded(host):
            return False
        if not self.scope:
            # By default, apex target domain is the primary scope
            target_clean = self.normalized_domain.strip().lower().rstrip(".")
            host_clean = host.strip().lower().rstrip(".")
            return host_clean == target_clean or host_clean.endswith(f".{target_clean}")
        
        host_clean = host.strip().lower().rstrip(".")
        for s in self.scope:
            s_clean = s.strip().lower().rstrip(".")
            if host_clean == s_clean or fnmatch.fnmatch(host_clean, s_clean) or host_clean.endswith(f".{s_clean}"):
                return True
        return False

    async def emit_log(self, message: str, level: str = "INFO", phase: str = "Core"):
        if self.log_callback:
            await self.log_callback(level, message, phase)

@dataclass
class ScanResult:
    phase_number: int
    phase_name: str
    success: bool
    data: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None

class BaseScanner:
    phase_number: int = 0
    name: str = "Base Scanner"
    description: str = "Abstract Phase Scanner"

    async def run(self, ctx: ScanContext) -> ScanResult:
        raise NotImplementedError
