import fnmatch
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Callable, Awaitable
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession

@dataclass
class ScanContext:
    target_id: str
    target: str
    normalized_domain: str
    profile: str = "standard"  # quick, standard, full, passive
    custom_ports: Optional[List[int]] = None
    exclude_hosts: List[str] = field(default_factory=list)
    scope: List[str] = field(default_factory=list)

    # Optional module flags
    enable_vuln_scan: bool = False   # --vuln-scan
    enable_full_ports: bool = False  # --full-ports
    enable_directories: bool = False # --directories
    enable_nmap: bool = False        # --nmap
    enable_headers: bool = False     # --headers
    enable_tls: bool = False         # --tls
    enable_all: bool = False         # --all
    output_path: Optional[str] = None

    # URL-specific target fields
    target_url: Optional[str] = None
    target_scheme: Optional[str] = None
    target_port: Optional[int] = None
    target_path: Optional[str] = None

    start_time: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    end_time: Optional[datetime] = None
    session: Optional[AsyncSession] = None
    log_callback: Optional[Callable[[str, str, str], Awaitable[None]]] = None

    # Pipeline state storage
    subdomains: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    ip_records: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    open_ports: List[Dict[str, Any]] = field(default_factory=list)
    http_assets: List[Dict[str, Any]] = field(default_factory=list)
    http_cache: Dict[str, Any] = field(default_factory=dict)  # Deduplicate HTTP requests across modules
    findings: List[Dict[str, Any]] = field(default_factory=list)
    tls_data: Dict[str, Any] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)
    skipped_modules: List[str] = field(default_factory=list)
    risk_score: float = 0.0
    invoked_tools: Dict[str, Any] = field(default_factory=dict)

    def is_excluded(self, host: str) -> bool:
        """Check if a host or IP is explicitly excluded from scan scope."""
        if not self.exclude_hosts:
            return False
        host_clean = host.strip().lower().rstrip(".")
        for ex in self.exclude_hosts:
            ex_clean = ex.strip().lower().rstrip(".")
            if not ex_clean:
                continue
            if host_clean == ex_clean or fnmatch.fnmatch(host_clean, ex_clean):
                return True
        return False

    def is_in_scope(self, host: str) -> bool:
        """Verify if a host falls within the assessment scope."""
        if self.is_excluded(host):
            return False
        host_clean = host.strip().lower().rstrip(".")
        if not self.scope:
            target_clean = self.normalized_domain.strip().lower().rstrip(".")
            if self.target_url:
                # When a specific URL is targeted, restrict scope strictly to the target host
                return host_clean == target_clean
            return host_clean == target_clean or host_clean.endswith(f".{target_clean}")
        
        for s in self.scope:
            s_clean = s.strip().lower().rstrip(".")
            if host_clean == s_clean or fnmatch.fnmatch(host_clean, s_clean) or host_clean.endswith(f".{s_clean}"):
                return True
        return False

    def record_tool(self, name: str, status: str, count: int = 0, message: str = ""):
        """Record verified external tool execution status for accurate audit reporting."""
        self.invoked_tools[name] = {
            "status": status,
            "count": count,
            "message": message
        }

    def add_finding(
        self,
        title: str,
        severity: str,
        category: str,
        affected_url: str,
        evidence: str,
        recommendation: str,
        description: str = "",
        confidence: str = "confirmed",
        rationale: str = ""
    ):
        """Add a validated security finding with evidence and confidence rating."""
        # Avoid duplicate findings for the same endpoint and title
        for f in self.findings:
            if f.get("title") == title and f.get("affected_url") == affected_url:
                return f

        finding = {
            "title": title,
            "severity": severity,
            "category": category,
            "confidence": confidence,
            "affected_url": affected_url,
            "description": description or f"Identified {title} on {affected_url}.",
            "evidence": evidence,
            "rationale": rationale or f"Classified as {severity} based on observed configuration impact.",
            "recommendation": recommendation
        }
        self.findings.append(finding)
        return finding

    async def emit_log(self, message: str, level: str = "INFO", phase: str = "Core"):
        if self.log_callback:
            await self.log_callback(level, message, phase)

@dataclass
class ScanResult:
    phase_number: int
    phase_name: str
    success: bool
    data: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None

class BaseScanner:
    phase_number: int = 0
    name: str = "Base Scanner"
    description: str = "Abstract Phase Scanner"

    async def run(self, ctx: ScanContext) -> ScanResult:
        raise NotImplementedError
