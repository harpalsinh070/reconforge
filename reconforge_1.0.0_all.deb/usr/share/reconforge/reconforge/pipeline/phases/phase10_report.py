import json
from datetime import datetime, timezone
from pathlib import Path
from rich.table import Table
from rich.panel import Panel
from rich.console import Console
from sqlalchemy import select, delete

from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config
from ...models import Target, Subdomain, IPAddress, Port, HTTPAsset, Finding, ScanRecord

console = Console()

class RiskReportScanner(BaseScanner):
    phase_number = 10
    name = "Attack Surface Correlation & Report Generation"
    description = "Correlates discovered assets, computes exposure risk score, saves to local DB, and exports reports."

    async def run(self, ctx: ScanContext) -> ScanResult:
        # 1. Compute Exposure Risk Score (0-100)
        score = 10.0  # Base visibility score
        live_subs = [s for s, d in ctx.subdomains.items() if d.get("is_live")]
        score += min(len(live_subs) * 2.0, 20.0)
        score += min(len(ctx.open_ports) * 3.0, 25.0)

        for f in ctx.findings:
            sev = f.get("severity", "Low")
            if sev == "Critical":
                score += 25.0
            elif sev == "High":
                score += 15.0
            elif sev == "Medium":
                score += 8.0
            elif sev == "Low":
                score += 3.0

        ctx.risk_score = round(min(score, 100.0), 1)

        # 2. Persist to Database cleanly without accumulating duplicate records
        if ctx.session:
            # Update target
            stmt = select(Target).where(Target.id == ctx.target_id)
            target = (await ctx.session.execute(stmt)).scalars().first()
            if target:
                target.risk_score = ctx.risk_score
                target.last_scanned = datetime.now(timezone.utc)

            # Clean previous assets for this target to ensure clean deduplicated inventory
            await ctx.session.execute(delete(Subdomain).where(Subdomain.target_id == ctx.target_id))
            await ctx.session.execute(delete(HTTPAsset).where(HTTPAsset.target_id == ctx.target_id))
            await ctx.session.execute(delete(Finding).where(Finding.target_id == ctx.target_id))
            
            # Sub-delete ports via IP Addresses cascade
            await ctx.session.execute(delete(IPAddress).where(IPAddress.target_id == ctx.target_id))
            await ctx.session.flush()

            # Save Subdomains
            for s_name, s_data in ctx.subdomains.items():
                sub = Subdomain(
                    target_id=ctx.target_id,
                    name=s_name,
                    is_live=s_data.get("is_live", False),
                    is_wildcard=s_data.get("is_wildcard", False),
                    dns_records=s_data.get("dns_records"),
                    cname_target=s_data.get("cname_target"),
                    takeover_vulnerable=s_data.get("takeover_vulnerable", False),
                    takeover_service=s_data.get("takeover_service")
                )
                ctx.session.add(sub)

            # Save IPs & Ports
            for ip_val, ip_data in ctx.ip_records.items():
                ip_obj = IPAddress(
                    target_id=ctx.target_id,
                    ip=ip_val,
                    asn=ip_data.get("asn"),
                    asn_org=ip_data.get("asn_org"),
                    cloud_provider=ip_data.get("cloud_provider"),
                    reverse_ptr=ip_data.get("reverse_ptr")
                )
                ctx.session.add(ip_obj)
                await ctx.session.flush()

                for p in ctx.open_ports:
                    if p.get("ip") == ip_val:
                        p_obj = Port(
                            ip_id=ip_obj.id,
                            port_number=p.get("port"),
                            protocol=p.get("protocol", "tcp"),
                            state=p.get("state", "open"),
                            service_name=p.get("service"),
                            service_banner=p.get("banner")
                        )
                        ctx.session.add(p_obj)

            # Save HTTP Assets
            for h in ctx.http_assets:
                h_obj = HTTPAsset(
                    target_id=ctx.target_id,
                    url=h.get("url"),
                    status_code=h.get("status_code"),
                    title=h.get("title"),
                    web_server=h.get("web_server"),
                    tech_stack=h.get("tech_stack"),
                    waf=h.get("waf"),
                    content_length=h.get("content_length"),
                    missing_headers=h.get("missing_headers")
                )
                ctx.session.add(h_obj)

            # Save Findings
            for f in ctx.findings:
                f_obj = Finding(
                    target_id=ctx.target_id,
                    title=f.get("title"),
                    severity=f.get("severity", "Low"),
                    category=f.get("category", "General"),
                    affected_url=f.get("affected_url"),
                    description=f.get("description", ""),
                    evidence=f.get("evidence", ""),
                    recommendation=f.get("recommendation", "")
                )
                ctx.session.add(f_obj)

            # Record Scan History
            rec = ScanRecord(
                target_id=ctx.target_id,
                profile=ctx.profile,
                status="completed",
                subdomains_count=len(ctx.subdomains),
                ports_count=len(ctx.open_ports),
                findings_count=len(ctx.findings),
                risk_score=ctx.risk_score
            )
            ctx.session.add(rec)
            await ctx.session.commit()

        # 3. Export JSON Deliverable
        timestamp_str = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        report_filename = f"recon_{ctx.normalized_domain}_{timestamp_str}.json"
        report_path = config.reports_dir / report_filename

        duration_sec = 0.0
        if ctx.end_time and ctx.start_time:
            duration_sec = round((ctx.end_time - ctx.start_time).total_seconds(), 2)

        deliverable = {
            "target": ctx.normalized_domain,
            "scan_date": datetime.now(timezone.utc).isoformat(),
            "duration_seconds": duration_sec,
            "profile": ctx.profile,
            "risk_score": ctx.risk_score,
            "statistics": {
                "subdomains_total": len(ctx.subdomains),
                "live_subdomains": len(live_subs),
                "ip_addresses": len(ctx.ip_records),
                "open_ports": len(ctx.open_ports),
                "http_services": len(ctx.http_assets),
                "findings": len(ctx.findings)
            },
            "subdomains": ctx.subdomains,
            "ip_infrastructure": ctx.ip_records,
            "open_ports": ctx.open_ports,
            "http_assets": ctx.http_assets,
            "findings": ctx.findings
        }

        try:
            with open(report_path, "w", encoding="utf-8") as f:
                json.dump(deliverable, f, indent=2)
            await ctx.emit_log(f"Report deliverable saved to: [bold white]{report_path}[/bold white]", level="SUCCESS", phase=self.name)
        except Exception as e:
            await ctx.emit_log(f"Notice: Could not write default report to {report_path}: {e}", level="DEBUG", phase=self.name)

        return ScanResult(
            phase_number=self.phase_number,
            phase_name=self.name,
            success=True,
            data={"risk_score": ctx.risk_score, "report_path": str(report_path)}
        )
