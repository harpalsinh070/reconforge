import json
from datetime import datetime, timezone
from pathlib import Path
from sqlalchemy import select, delete

from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config
from ...models import Target, Subdomain, IPAddress, Port, HTTPAsset, Finding, ScanRecord

class RiskReportScanner(BaseScanner):
    phase_number = 7
    name = "Consolidated Reporting & Deliverables"
    description = "Correlates discovered assets, computes risk score, persists to DB, and exports report."

    async def run(self, ctx: ScanContext) -> ScanResult:
        # 1. Compute Exposure Risk Score (0-100)
        score = 5.0
        live_subs = [s for s, d in ctx.subdomains.items() if d.get("is_live")]
        score += min(len(live_subs) * 2.0, 20.0)
        score += min(len(ctx.open_ports) * 3.0, 25.0)

        for f in ctx.findings:
            sev = f.get("severity", "Low")
            if sev == "Critical":
                score += 25.0
            elif sev == "High":
                score += 15.0
            elif sev == "Medium":
                score += 8.0
            elif sev == "Low":
                score += 3.0
            elif sev == "Info":
                score += 1.0

        ctx.risk_score = round(min(score, 100.0), 1)

        # 2. Persist to Database cleanly
        if ctx.session:
            try:
                stmt = select(Target).where(Target.id == ctx.target_id)
                target = (await ctx.session.execute(stmt)).scalars().first()
                if target:
                    target.risk_score = ctx.risk_score
                    target.last_scanned = datetime.now(timezone.utc)

                # Clean previous assets for target
                await ctx.session.execute(delete(Subdomain).where(Subdomain.target_id == ctx.target_id))
                await ctx.session.execute(delete(HTTPAsset).where(HTTPAsset.target_id == ctx.target_id))
                await ctx.session.execute(delete(Finding).where(Finding.target_id == ctx.target_id))
                await ctx.session.execute(delete(IPAddress).where(IPAddress.target_id == ctx.target_id))
                await ctx.session.flush()

                # Save Subdomains
                for s_name, s_data in ctx.subdomains.items():
                    sub = Subdomain(
                        target_id=ctx.target_id,
                        name=s_name,
                        is_live=s_data.get("is_live", False),
                        is_wildcard=s_data.get("is_wildcard", False),
                        dns_records=s_data.get("dns_records"),
                        cname_target=s_data.get("cname_target"),
                        takeover_vulnerable=s_data.get("takeover_vulnerable", False),
                        takeover_service=s_data.get("takeover_service"),
                        source=s_data.get("source", "Passive OSINT")
                    )
                    ctx.session.add(sub)

                # Save IPs & Ports
                for ip_val, ip_data in ctx.ip_records.items():
                    ip_obj = IPAddress(
                        target_id=ctx.target_id,
                        ip=ip_val,
                        asn=ip_data.get("asn"),
                        asn_org=ip_data.get("asn_org"),
                        cloud_provider=ip_data.get("cloud_provider"),
                        reverse_ptr=ip_data.get("reverse_ptr")
                    )
                    ctx.session.add(ip_obj)
                    await ctx.session.flush()

                    for p in ctx.open_ports:
                        if p.get("ip") == ip_val:
                            p_obj = Port(
                                ip_id=ip_obj.id,
                                port_number=p.get("port"),
                                protocol=p.get("protocol", "tcp"),
                                state=p.get("state", "open"),
                                service_name=p.get("service"),
                                service_banner=p.get("banner")
                            )
                            ctx.session.add(p_obj)

                # Save HTTP Assets
                for h in ctx.http_assets:
                    h_obj = HTTPAsset(
                        target_id=ctx.target_id,
                        url=h.get("url"),
                        status_code=h.get("status_code"),
                        title=h.get("title"),
                        web_server=h.get("web_server"),
                        tech_stack=h.get("tech_stack"),
                        waf=h.get("waf"),
                        content_length=h.get("content_length"),
                        missing_headers=h.get("missing_headers")
                    )
                    ctx.session.add(h_obj)

                # Save Findings
                for f in ctx.findings:
                    f_obj = Finding(
                        target_id=ctx.target_id,
                        title=f.get("title"),
                        severity=f.get("severity", "Low"),
                        category=f.get("category", "General"),
                        affected_url=f.get("affected_url"),
                        description=f.get("description", ""),
                        evidence=f.get("evidence", ""),
                        confidence=f.get("confidence", "confirmed"),
                        rationale=f.get("rationale", ""),
                        recommendation=f.get("recommendation", "")
                    )
                    ctx.session.add(f_obj)

                # Record Scan History
                rec = ScanRecord(
                    target_id=ctx.target_id,
                    profile=ctx.profile,
                    status="completed",
                    subdomains_count=len(ctx.subdomains),
                    ports_count=len(ctx.open_ports),
                    findings_count=len(ctx.findings),
                    risk_score=ctx.risk_score
                )
                ctx.session.add(rec)
                await ctx.session.commit()
                ctx.db_status = "saved"
            except Exception as e:
                await ctx.session.rollback()
                ctx.db_status = "failed"
                ctx.db_error = str(e)
                err_msg = f"Database write failed: {e}"
                await ctx.emit_log(err_msg, level="ERROR", phase=self.name)
        else:
            ctx.db_status = "skipped"

        # 3. Deliverable Data Correlation
        duration_sec = 0.0
        if ctx.end_time and ctx.start_time:
            duration_sec = round((ctx.end_time - ctx.start_time).total_seconds(), 2)

        sev_counts = {}
        for f in ctx.findings:
            s = f.get("severity", "Low")
            sev_counts[s] = sev_counts.get(s, 0) + 1

        deliverable = {
            "target": ctx.target_url if ctx.target_url else ctx.normalized_domain,
            "domain": ctx.normalized_domain,
            "target_url": ctx.target_url,
            "scan_date": datetime.now(timezone.utc).isoformat(),
            "duration_seconds": duration_sec,
            "profile": ctx.profile,
            "risk_score": ctx.risk_score,
            "invoked_tools": ctx.invoked_tools,
            "statistics": {
                "subdomains_total": len(ctx.subdomains),
                "live_subdomains": len(live_subs),
                "open_ports": len(ctx.open_ports),
                "http_services": len(ctx.http_assets),
                "findings_total": len(ctx.findings),
                "findings_by_severity": sev_counts
            },
            "subdomains": ctx.subdomains,
            "open_ports": ctx.open_ports,
            "http_assets": ctx.http_assets,
            "findings": ctx.findings,
            "status": {
                "scan_execution": ctx.scan_status,
                "database_persistence": ctx.db_status,
                "file_export": ctx.export_status
            }
        }

        # 4. Optional file export only when explicitly requested via ctx.output_path
        if ctx.output_path:
            out_p = Path(ctx.output_path)
            if out_p.exists():
                err_msg = f"Output file '{ctx.output_path}' already exists. Refusing to overwrite."
                ctx.export_status = "failed"
                ctx.export_error = err_msg
                deliverable["status"]["file_export"] = "failed"
                await ctx.emit_log(err_msg, level="ERROR", phase=self.name)
            else:
                try:
                    out_p.parent.mkdir(parents=True, exist_ok=True)
                    ctx.export_status = "saved"
                    ctx.export_path = str(out_p.resolve())
                    deliverable["status"]["file_export"] = "saved"
                    if ctx.output_path.endswith(".json"):
                        with open(out_p, "w", encoding="utf-8") as f:
                            json.dump(deliverable, f, indent=2)
                    elif ctx.output_path.endswith(".txt"):
                        from ..report_formatter import render_text_report
                        txt = render_text_report(ctx, deliverable)
                        with open(out_p, "w", encoding="utf-8") as f:
                            f.write(txt)
                    else:
                        with open(out_p, "w", encoding="utf-8") as f:
                            json.dump(deliverable, f, indent=2)
                except Exception as e:
                    err_msg = f"Failed to export report to '{ctx.output_path}': {e}"
                    ctx.export_status = "failed"
                    ctx.export_error = str(e)
                    deliverable["status"]["file_export"] = "failed"
                    await ctx.emit_log(err_msg, level="ERROR", phase=self.name)
        else:
            ctx.export_status = "not_requested"

        has_error = (ctx.db_status == "failed") or (ctx.export_status == "failed")
        first_error = ctx.db_error or ctx.export_error
        return ScanResult(
            phase_number=self.phase_number,
            phase_name=self.name,
            success=not has_error,
            error=first_error if has_error else None,
            data={"risk_score": ctx.risk_score, "deliverable": deliverable}
        )
