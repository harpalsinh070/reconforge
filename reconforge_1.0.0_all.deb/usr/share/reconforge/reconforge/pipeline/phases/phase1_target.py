import re
import ipaddress
from urllib.parse import urlparse
from ..base import BaseScanner, ScanContext, ScanResult

class TargetNormalizationScanner(BaseScanner):
    phase_number = 1
    name = "Target Normalization & Validation"
    description = "Normalizes input target hostname, strips schemes, credentials, and paths, and verifies syntax."

    @staticmethod
    def normalize_input(raw: str) -> str:
        """Clean and normalize a raw target string or URL."""
        if not raw:
            return ""
        target = raw.strip()

        # Handle schemes like http://, https://, ftp://
        if "://" in target:
            parsed = urlparse(target)
            target = parsed.netloc or parsed.path
        else:
            # Handle path if passed as domain/path
            target = target.split("/")[0]

        # Strip userinfo (user:pass@host)
        if "@" in target:
            target = target.split("@")[-1]

        # Strip port (handle IPv6 brackets if present)
        if target.startswith("[") and "]" in target:
            # IPv6 literal
            target = target[1:target.index("]")]
        elif ":" in target:
            target = target.split(":")[0]

        # Strip trailing dots and lowercase
        return target.strip().rstrip(".").lower()

    @staticmethod
    def is_valid_target(host: str) -> bool:
        """Validate if target is a syntactically valid domain or IP address."""
        if not host or len(host) > 253:
            return False

        # 1. Try IP address parsing
        try:
            ipaddress.ip_address(host)
            return True
        except ValueError:
            pass

        # 2. Domain regex conforming to RFC 1035 / RFC 1123
        domain_regex = (
            r"^(?=[a-zA-Z0-9-]{1,63}\.)"
            r"(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+"
            r"[a-zA-Z]{2,63}$"
        )
        return bool(re.match(domain_regex, host))

    @staticmethod
    def parse_url_target(raw_url: str) -> dict:
        """Safely parse a full URL target and extract scheme, host, port, and path."""
        if not raw_url or not isinstance(raw_url, str):
            raise ValueError("URL target cannot be empty.")
        raw_url = raw_url.strip()
        parsed = urlparse(raw_url)
        scheme = parsed.scheme.lower()
        if scheme not in ["http", "https"]:
            raise ValueError(f"Unsupported URL scheme: '{parsed.scheme}'. Only HTTP and HTTPS are supported.")

        host = parsed.hostname
        if not host:
            raise ValueError(f"Missing host in URL: '{raw_url}'.")
        host = host.lower().rstrip(".")

        port = parsed.port or (443 if scheme == "https" else 80)
        path = parsed.path if parsed.path else ""
        if parsed.query:
            path += f"?{parsed.query}"

        return {
            "url": raw_url,
            "scheme": scheme,
            "host": host,
            "port": port,
            "path": path or "/"
        }

    async def run(self, ctx: ScanContext) -> ScanResult:
        domain = ""
        # 1. URL target processing
        if ctx.target_url:
            try:
                url_info = self.parse_url_target(ctx.target_url)
                domain = url_info["host"]
                ctx.target_scheme = url_info["scheme"]
                ctx.target_port = url_info["port"]
                ctx.target_path = url_info["path"]
                ctx.target_url = url_info["url"]
            except ValueError as e:
                err_msg = f"Invalid target URL: {e}"
                await ctx.emit_log(err_msg, level="ERROR", phase=self.name)
                return ScanResult(
                    phase_number=self.phase_number,
                    phase_name=self.name,
                    success=False,
                    error=err_msg
                )
        else:
            domain = self.normalize_input(ctx.target)

        if not self.is_valid_target(domain):
            err_msg = f"Invalid target format: '{ctx.target or ctx.target_url}'. Must be a valid domain name (e.g. example.com), URL, or IP address."
            await ctx.emit_log(err_msg, level="ERROR", phase=self.name)
            return ScanResult(
                phase_number=self.phase_number,
                phase_name=self.name,
                success=False,
                error=err_msg
            )

        # Check if the target itself is excluded
        if ctx.is_excluded(domain):
            err_msg = f"Target '{domain}' is explicitly in the exclusion list. Aborting scan."
            await ctx.emit_log(err_msg, level="WARN", phase=self.name)
            return ScanResult(
                phase_number=self.phase_number,
                phase_name=self.name,
                success=False,
                error=err_msg
            )

        ctx.normalized_domain = domain
        ctx.subdomains[domain] = {
            "name": domain,
            "is_live": True,
            "is_apex": True,
            "dns_records": {}
        }

        target_display = ctx.target_url if ctx.target_url else domain
        await ctx.emit_log(f"Target validated successfully: [bold cyan]{target_display}[/bold cyan]", level="SUCCESS", phase=self.name)
        return ScanResult(
            phase_number=self.phase_number,
            phase_name=self.name,
            success=True,
            data={"domain": domain, "target_url": ctx.target_url}
        )
