import re
import ipaddress
from urllib.parse import urlparse
from ..base import BaseScanner, ScanContext, ScanResult

class TargetNormalizationScanner(BaseScanner):
    phase_number = 1
    name = "Target Normalization & Validation"
    description = "Normalizes input target hostname, strips schemes, credentials, and paths, and verifies syntax."

    @staticmethod
    def normalize_input(raw: str) -> str:
        """Clean and normalize a raw target string or URL."""
        if not raw:
            return ""
        target = raw.strip()

        # Handle schemes like http://, https://, ftp://
        if "://" in target:
            parsed = urlparse(target)
            target = parsed.netloc or parsed.path
        else:
            # Handle path if passed as domain/path
            target = target.split("/")[0]

        # Strip userinfo (user:pass@host)
        if "@" in target:
            target = target.split("@")[-1]

        # Strip port (handle IPv6 brackets if present)
        if target.startswith("[") and "]" in target:
            # IPv6 literal
            target = target[1:target.index("]")]
        elif ":" in target:
            target = target.split(":")[0]

        # Strip trailing dots and lowercase
        return target.strip().rstrip(".").lower()

    @staticmethod
    def is_valid_target(host: str) -> bool:
        """Validate if target is a syntactically valid domain or IP address."""
        if not host or len(host) > 253:
            return False

        # 1. Try IP address parsing
        try:
            ipaddress.ip_address(host)
            return True
        except ValueError:
            pass

        # 2. Domain regex conforming to RFC 1035 / RFC 1123
        domain_regex = (
            r"^(?=[a-zA-Z0-9-]{1,63}\.)"
            r"(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+"
            r"[a-zA-Z]{2,63}$"
        )
        return bool(re.match(domain_regex, host))

    async def run(self, ctx: ScanContext) -> ScanResult:
        domain = self.normalize_input(ctx.target)

        if not self.is_valid_target(domain):
            err_msg = f"Invalid target format: '{ctx.target}'. Must be a valid domain name (e.g. example.com) or IP address."
            await ctx.emit_log(err_msg, level="ERROR", phase=self.name)
            return ScanResult(
                phase_number=self.phase_number,
                phase_name=self.name,
                success=False,
                error=err_msg
            )

        # Check if the target itself is excluded
        if ctx.is_excluded(domain):
            err_msg = f"Target '{domain}' is explicitly in the exclusion list. Aborting scan."
            await ctx.emit_log(err_msg, level="WARN", phase=self.name)
            return ScanResult(
                phase_number=self.phase_number,
                phase_name=self.name,
                success=False,
                error=err_msg
            )

        ctx.normalized_domain = domain
        ctx.subdomains[domain] = {
            "name": domain,
            "is_live": True,
            "is_apex": True,
            "dns_records": {}
        }

        await ctx.emit_log(f"Target validated successfully: [bold cyan]{domain}[/bold cyan]", level="SUCCESS", phase=self.name)
        return ScanResult(
            phase_number=self.phase_number,
            phase_name=self.name,
            success=True,
            data={"domain": domain}
        )
