import asyncio
import socket
import dns.asyncresolver
import dns.reversename
from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config

CLOUD_PROVIDERS = {
    "cloudflare": "Cloudflare",
    "amazon": "Amazon Web Services (AWS)",
    "aws": "Amazon Web Services (AWS)",
    "google": "Google Cloud Platform (GCP)",
    "microsoft": "Microsoft Azure",
    "azure": "Microsoft Azure",
    "digitalocean": "DigitalOcean",
    "akamai": "Akamai CDN",
    "fastly": "Fastly CDN",
    "hetzner": "Hetzner Online",
    "ovh": "OVH SAS",
    "linode": "Linode / Akamai"
}

class IPNetworkScanner(BaseScanner):
    phase_number = 5
    name = "IP Resolution, Reverse PTR & ASN Intelligence"
    description = "Resolves reverse PTR hostnames, queries BGP ASN ownership, and classifies Cloud/CDN providers."

    async def run(self, ctx: ScanContext) -> ScanResult:
        ips = list(ctx.ip_records.keys())
        if not ips:
            await ctx.emit_log("No IP addresses available for network intelligence. Skipping.", level="INFO", phase=self.name)
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        await ctx.emit_log(f"Resolving PTR & ASN intelligence across {len(ips)} distinct IP addresses...", level="INFO", phase=self.name)

        resolver = dns.asyncresolver.Resolver()
        resolver.timeout = config.dns_timeout

        for ip in ips:
            # 1. Reverse PTR
            try:
                rev_name = dns.reversename.from_address(ip)
                ptr_ans = await resolver.resolve(rev_name, "PTR")
                ptrs = [r.to_text().rstrip(".") for r in ptr_ans]
                ctx.ip_records[ip]["reverse_ptr"] = ptrs[0] if ptrs else None
            except Exception:
                ctx.ip_records[ip]["reverse_ptr"] = None

            # 2. Team Cymru BGP/ASN lookup via DNS
            try:
                octets = ip.split(".")
                if len(octets) == 4:
                    reversed_ip = ".".join(reversed(octets))
                    query_name = f"{reversed_ip}.origin.asn.cymru.com"
                    ans = await resolver.resolve(query_name, "TXT")
                    for r in ans:
                        txt = r.to_text().strip('"')
                        # Format: "15169 | 8.8.8.0/24 | US | arin | 1992-12-01"
                        parts = [p.strip() for p in txt.split("|")]
                        if len(parts) >= 3:
                            asn_num = f"AS{parts[0]}"
                            ctx.ip_records[ip]["asn"] = asn_num
                            
                            # Query ASN Org
                            try:
                                org_query = f"AS{parts[0]}.asn.cymru.com"
                                org_ans = await resolver.resolve(org_query, "TXT")
                                for o in org_ans:
                                    org_txt = o.to_text().strip('"')
                                    org_parts = [p.strip() for p in org_txt.split("|")]
                                    if len(org_parts) >= 5:
                                        ctx.ip_records[ip]["asn_org"] = org_parts[4]
                            except Exception:
                                pass
            except Exception:
                pass

            # 3. Detect Cloud / CDN provider
            asn_org = (ctx.ip_records[ip].get("asn_org") or "").lower()
            reverse_ptr = (ctx.ip_records[ip].get("reverse_ptr") or "").lower()
            combined = f"{asn_org} {reverse_ptr}"

            detected_cloud = None
            for key, name in CLOUD_PROVIDERS.items():
                if key in combined:
                    detected_cloud = name
                    break
            ctx.ip_records[ip]["cloud_provider"] = detected_cloud

        await ctx.emit_log(f"Network intelligence mapped for {len(ips)} IP addresses.", level="SUCCESS", phase=self.name)
        return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True, data={"ips": len(ips)})
