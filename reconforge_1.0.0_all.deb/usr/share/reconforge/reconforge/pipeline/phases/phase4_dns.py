import asyncio
import dns.asyncresolver
import dns.resolver
from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config

TAKEOVER_SIGNATURES = {
    "github.io": "GitHub Pages",
    "s3.amazonaws.com": "AWS S3 Bucket",
    "s3-website": "AWS S3 Website",
    "herokuapp.com": "Heroku",
    "myshopify.com": "Shopify",
    "domains.tumblr.com": "Tumblr",
    "fastly.net": "Fastly CDN",
    "azurewebsites.net": "Microsoft Azure",
    "ghost.io": "Ghost Blog",
    "readme.io": "Readme.io",
    "surge.sh": "Surge.sh",
    "pantheonsite.io": "Pantheon",
    "zendesk.com": "Zendesk",
    "helpjuice.com": "Helpjuice",
    "freshdesk.com": "Freshdesk",
    "unbouncepages.com": "Unbounce"
}

class DNSEnumerationScanner(BaseScanner):
    phase_number = 11  # Optional advanced module
    name = "Deep DNS & Dangling CNAME Takeover"
    description = "Queries A, AAAA, MX, NS, TXT records and detects potential unclaimed dangling CNAME targets."

    async def run(self, ctx: ScanContext) -> ScanResult:
        # Only run if explicitly requested via --deep-dns or full profile
        if not (ctx.enable_deep_dns or ctx.profile == "full"):
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        resolver = dns.asyncresolver.Resolver()
        resolver.timeout = config.dns_timeout
        resolver.lifetime = config.dns_timeout

        record_types = ["A", "AAAA", "CNAME", "MX", "NS", "TXT"]
        live_subs = [s for s, d in ctx.subdomains.items() if d.get("is_live")]

        takeover_count = 0
        for sub in live_subs:
            dns_data = {}
            for rtype in record_types:
                try:
                    ans = await resolver.resolve(sub, rtype)
                    dns_data[rtype] = [r.to_text() for r in ans]
                except Exception:
                    pass

            ctx.subdomains[sub]["dns_records"] = dns_data

            # Check CNAME for potential dangling takeover
            cnames = dns_data.get("CNAME", [])
            for cname in cnames:
                cname_clean = cname.rstrip(".").lower()
                ctx.subdomains[sub]["cname_target"] = cname_clean

                for sig_pattern, service_name in TAKEOVER_SIGNATURES.items():
                    if sig_pattern in cname_clean:
                        try:
                            await resolver.resolve(cname_clean, "A")
                        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, Exception):
                            ctx.subdomains[sub]["takeover_vulnerable"] = True
                            ctx.subdomains[sub]["takeover_service"] = service_name
                            takeover_count += 1
                            ctx.add_finding(
                                title=f"Potential Dangling CNAME Takeover ({sub})",
                                severity="High",
                                category="DNS Misconfiguration",
                                confidence="tentative",
                                affected_url=f"http://{sub}",
                                evidence=f"CNAME: {cname_clean} (Service: {service_name}) did not resolve to an active address.",
                                rationale=f"Unclaimed cloud service alias records can be claimed by attackers to hijack subdomain traffic.",
                                recommendation=f"Remove the dangling CNAME record from your DNS zone file or claim the name on {service_name}."
                            )

        await ctx.emit_log(f"Deep DNS audit complete. Takeover flags: {takeover_count}", level="INFO", phase=self.name)
        return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True, data={"takeovers": takeover_count})
