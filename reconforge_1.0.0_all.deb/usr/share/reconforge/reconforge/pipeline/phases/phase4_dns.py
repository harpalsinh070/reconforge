import asyncio
import dns.asyncresolver
from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config

TAKEOVER_SIGNATURES = {
    "github.io": "GitHub Pages",
    "s3.amazonaws.com": "AWS S3 Bucket",
    "s3-website": "AWS S3 Website",
    "herokuapp.com": "Heroku",
    "myshopify.com": "Shopify",
    "domains.tumblr.com": "Tumblr",
    "fastly.net": "Fastly CDN",
    "azurewebsites.net": "Microsoft Azure",
    "ghost.io": "Ghost Blog",
    "readme.io": "Readme.io",
    "surge.sh": "Surge.sh",
    "pantheonsite.io": "Pantheon",
    "zendesk.com": "Zendesk",
    "helpjuice.com": "Helpjuice",
    "freshdesk.com": "Freshdesk",
    "unbouncepages.com": "Unbounce"
}

class DNSEnumerationScanner(BaseScanner):
    phase_number = 4
    name = "DNS Enumeration & Dangling CNAME Takeover Check"
    description = "Queries A, AAAA, MX, NS, TXT records and detects vulnerable dangling CNAME targets."

    async def run(self, ctx: ScanContext) -> ScanResult:
        resolver = dns.asyncresolver.Resolver()
        resolver.timeout = config.dns_timeout
        resolver.lifetime = config.dns_timeout

        record_types = ["A", "AAAA", "CNAME", "MX", "NS", "TXT"]
        live_subs = [s for s, d in ctx.subdomains.items() if d.get("is_live")]

        await ctx.emit_log(f"Enumerating DNS records across {len(live_subs)} live hosts...", level="INFO", phase=self.name)

        takeover_count = 0
        for sub in live_subs:
            dns_data = {}
            for rtype in record_types:
                try:
                    ans = await resolver.resolve(sub, rtype)
                    dns_data[rtype] = [r.to_text() for r in ans]
                except Exception:
                    pass

            ctx.subdomains[sub]["dns_records"] = dns_data

            # Check CNAME for takeover
            cnames = dns_data.get("CNAME", [])
            for cname in cnames:
                cname_clean = cname.rstrip(".").lower()
                ctx.subdomains[sub]["cname_target"] = cname_clean

                for sig_pattern, service_name in TAKEOVER_SIGNATURES.items():
                    if sig_pattern in cname_clean:
                        # Check if target CNAME resolves
                        try:
                            await resolver.resolve(cname_clean, "A")
                        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, Exception):
                            # Dangling CNAME!
                            ctx.subdomains[sub]["takeover_vulnerable"] = True
                            ctx.subdomains[sub]["takeover_service"] = service_name
                            takeover_count += 1
                            ctx.findings.append({
                                "title": f"Dangling CNAME Subdomain Takeover: {sub}",
                                "severity": "High",
                                "category": "DNS Misconfiguration",
                                "affected_url": f"http://{sub}",
                                "description": f"Subdomain '{sub}' points to '{cname_clean}' ({service_name}) which does not resolve or appears unclaimed.",
                                "evidence": f"CNAME target: {cname_clean} (Provider: {service_name})",
                                "recommendation": f"Remove the dangling CNAME record from DNS zone file or reclaim the resource on {service_name}."
                            })
                            await ctx.emit_log(f"[bold red][!] Dangling CNAME Detected:[/bold red] {sub} -> {cname_clean} ({service_name})", level="WARN", phase=self.name)

        await ctx.emit_log(f"DNS audit complete. Findings: {takeover_count} potential takeover vectors flagged.", level="SUCCESS", phase=self.name)
        return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True, data={"takeovers": takeover_count})
