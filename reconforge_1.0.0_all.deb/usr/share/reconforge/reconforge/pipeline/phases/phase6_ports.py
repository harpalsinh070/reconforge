import asyncio
import socket
import shutil
import xml.etree.ElementTree as ET
from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config

SERVICE_MAP = {
    21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "dns", 80: "http",
    110: "pop3", 143: "imap", 443: "https", 445: "smb", 1433: "mssql",
    1521: "oracle", 3000: "http-node", 3306: "mysql", 3389: "rdp",
    5000: "http-flask", 5432: "postgresql", 6379: "redis", 8000: "http-alt",
    8080: "http-proxy", 8443: "https-alt", 8888: "http-alt", 9000: "http-alt",
    9200: "elasticsearch", 27017: "mongodb"
}

class PortDiscoveryScanner(BaseScanner):
    phase_number = 6
    name = "Port & Service Discovery"
    description = "Discovers open network ports using high-speed async TCP sockets or optional native Nmap."

    async def run(self, ctx: ScanContext) -> ScanResult:
        if ctx.profile == "passive":
            await ctx.emit_log("Passive scan profile active. Port scanning omitted.", level="INFO", phase=self.name)
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        if ctx.custom_ports:
            ports = ctx.custom_ports
        elif ctx.profile == "quick":
            ports = config.quick_ports
        else:
            ports = config.standard_ports

        # Gather target IP addresses or fallback to normalized domain
        target_ips = [ip for ip in ctx.ip_records.keys() if not ctx.is_excluded(ip)]
        if not target_ips:
            if not ctx.is_excluded(ctx.normalized_domain):
                target_ips = [ctx.normalized_domain]

        if not target_ips:
            await ctx.emit_log("All target hosts are excluded or resolved no IPs. Skipping port scan.", level="INFO", phase=self.name)
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        found_ports = 0
        nmap_bin = shutil.which(config.nmap_path) if ctx.enable_nmap else None

        # 1. If Nmap is explicitly requested and installed
        if ctx.enable_nmap and nmap_bin:
            await ctx.emit_log(f"Nmap explicitly enabled. Executing safe discovery via {nmap_bin}...", level="INFO", phase=self.name)
            port_arg = ",".join(str(p) for p in ports[:100])
            for ip in target_ips[:10]:
                try:
                    proc = await asyncio.create_subprocess_exec(
                        nmap_bin, "-sT", "-Pn", "-T4", "-p", port_arg, "-oX", "-", ip,
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=45.0)
                    if proc.returncode == 0:
                        root = ET.fromstring(stdout.decode(errors="ignore"))
                        for p_elem in root.findall(".//port"):
                            state_elem = p_elem.find("state")
                            if state_elem is not None and state_elem.get("state") == "open":
                                p_num = int(p_elem.get("portid"))
                                proto = p_elem.get("protocol", "tcp")
                                svc_elem = p_elem.find("service")
                                svc_name = svc_elem.get("name", "unknown") if svc_elem is not None else SERVICE_MAP.get(p_num, "unknown")
                                banner_info = svc_elem.get("product", "") if svc_elem is not None else ""
                                
                                port_data = {
                                    "ip": ip,
                                    "port": p_num,
                                    "protocol": proto,
                                    "state": "open",
                                    "service": svc_name,
                                    "banner": banner_info
                                }
                                ctx.open_ports.append(port_data)
                                found_ports += 1
                                await ctx.emit_log(f"[bold green][+] Open Port (Nmap):[/bold green] {ip}:{p_num} ({svc_name})", level="SUCCESS", phase=self.name)
                except Exception as e:
                    await ctx.emit_log(f"Nmap query failed on {ip}: {e}. Falling back to socket engine.", level="WARN", phase=self.name)
                    # Will fall back below if 0 found
            if found_ports > 0:
                await ctx.emit_log(f"Nmap completed. Discovered [bold green]{found_ports}[/bold green] open ports.", level="SUCCESS", phase=self.name)
                return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True, data={"open_ports": found_ports})

        if ctx.enable_nmap and not nmap_bin:
            await ctx.emit_log("Nmap was requested but is not installed in system PATH. Using high-speed async TCP engine.", level="WARN", phase=self.name)

        # 2. High-speed native async TCP socket engine
        await ctx.emit_log(f"Scanning {len(ports)} ports across {len(target_ips[:15])} hosts via async socket engine...", level="INFO", phase=self.name)
        semaphore = asyncio.Semaphore(config.max_concurrency)

        async def check_port(ip: str, port: int):
            nonlocal found_ports
            async with semaphore:
                try:
                    conn = asyncio.open_connection(ip, port)
                    reader, writer = await asyncio.wait_for(conn, timeout=1.5)
                    banner = ""
                    try:
                        if port in [21, 22, 25, 110]:
                            raw_banner = await asyncio.wait_for(reader.read(128), timeout=1.0)
                            banner = raw_banner.decode(errors="ignore").strip()
                        elif port in [80, 443, 8080, 8443]:
                            banner = "HTTP/HTTPS Web Service"
                    except Exception:
                        pass
                    finally:
                        writer.close()
                        await writer.wait_closed()

                    svc_name = SERVICE_MAP.get(port, "unknown")
                    port_data = {
                        "ip": ip,
                        "port": port,
                        "protocol": "tcp",
                        "state": "open",
                        "service": svc_name,
                        "banner": banner
                    }
                    ctx.open_ports.append(port_data)
                    found_ports += 1
                    await ctx.emit_log(f"[bold green][+] Open Port Discovered:[/bold green] {ip}:{port} ({svc_name}) {banner[:30]}", level="SUCCESS", phase=self.name)
                except Exception:
                    pass

        tasks = []
        for ip in target_ips[:15]:
            for p in ports:
                tasks.append(check_port(ip, p))

        await asyncio.gather(*tasks)
        await ctx.emit_log(f"Port scan completed. Discovered [bold green]{found_ports}[/bold green] open network ports.", level="SUCCESS", phase=self.name)
        return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True, data={"open_ports": found_ports})
