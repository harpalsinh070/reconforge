import asyncio
import socket
import shutil
import xml.etree.ElementTree as ET
from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config

SERVICE_MAP = {
    21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "dns", 80: "http",
    110: "pop3", 143: "imap", 443: "https", 445: "smb", 993: "imaps", 995: "pop3s",
    1433: "mssql", 1521: "oracle", 3000: "http-node", 3306: "mysql", 3389: "rdp",
    5000: "http-flask", 5432: "postgresql", 6379: "redis", 8000: "http-alt",
    8080: "http-proxy", 8443: "https-alt", 8888: "http-alt", 9000: "http-alt",
    9200: "elasticsearch", 27017: "mongodb"
}

class PortDiscoveryScanner(BaseScanner):
    phase_number = 4
    name = "Common TCP Port Discovery"
    description = "Discovers active network services on live hosts using documented default ports or optional Nmap."

    async def run(self, ctx: ScanContext) -> ScanResult:
        if ctx.profile in ["passive", "quick"]:
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        # Select documented port list
        if ctx.custom_ports:
            ports = ctx.custom_ports
        elif ctx.enable_full_ports:
            ports = config.full_ports
        else:
            ports = config.standard_ports

        # Target IPs from live resolved hosts only (reusing Stage 3 results)
        target_ips = [ip for ip in ctx.ip_records.keys() if not ctx.is_excluded(ip)]
        if not target_ips and not ctx.is_excluded(ctx.normalized_domain):
            target_ips = [ctx.normalized_domain]

        if not target_ips:
            await ctx.emit_log("No live hosts available for port scan.", level="INFO", phase=self.name)
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        found_ports = 0
        nmap_bin = shutil.which(config.nmap_path) if ctx.enable_nmap else None

        # 1. Native Nmap execution if explicitly enabled
        if ctx.enable_nmap:
            if nmap_bin:
                port_arg = ",".join(str(p) for p in ports[:100])
                for ip in target_ips[:10]:
                    try:
                        proc = await asyncio.create_subprocess_exec(
                            nmap_bin, "-sT", "-Pn", "-T4", "-p", port_arg, "-oX", "-", ip,
                            stdout=asyncio.subprocess.PIPE,
                            stderr=asyncio.subprocess.PIPE
                        )
                        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=45.0)
                        if proc.returncode == 0:
                            root = ET.fromstring(stdout.decode(errors="ignore"))
                            for p_elem in root.findall(".//port"):
                                state_elem = p_elem.find("state")
                                if state_elem is not None and state_elem.get("state") == "open":
                                    p_num = int(p_elem.get("portid"))
                                    proto = p_elem.get("protocol", "tcp")
                                    svc_elem = p_elem.find("service")
                                    svc_name = svc_elem.get("name", "unknown") if svc_elem is not None else SERVICE_MAP.get(p_num, "unknown")
                                    banner_info = svc_elem.get("product", "") if svc_elem is not None else ""
                                    
                                    port_data = {
                                        "ip": ip,
                                        "port": p_num,
                                        "protocol": proto,
                                        "state": "open",
                                        "service": svc_name,
                                        "banner": banner_info
                                    }
                                    ctx.open_ports.append(port_data)
                                    found_ports += 1
                    except Exception:
                        pass
                ctx.record_tool("nmap", "executed", found_ports)
                await ctx.emit_log(f"Nmap discovered {found_ports} open ports.", level="SUCCESS", phase=self.name)
                return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True, data={"open_ports": found_ports})
            else:
                ctx.record_tool("nmap", "not_installed", message="Nmap requested but not found in PATH")
                await ctx.emit_log("Nmap not in PATH. Falling back to native async TCP socket engine.", level="WARN", phase=self.name)

        # 2. High-speed native async TCP socket engine
        semaphore = asyncio.Semaphore(config.max_concurrency)

        async def check_port(ip: str, port: int):
            nonlocal found_ports
            async with semaphore:
                try:
                    conn = asyncio.open_connection(ip, port)
                    reader, writer = await asyncio.wait_for(conn, timeout=1.5)
                    banner = ""
                    try:
                        if port in [21, 22, 25, 110]:
                            raw_banner = await asyncio.wait_for(reader.read(128), timeout=1.0)
                            banner = raw_banner.decode(errors="ignore").strip()
                        elif port in [80, 443, 8080, 8443]:
                            banner = "HTTP/HTTPS Service"
                    except Exception:
                        pass
                    finally:
                        writer.close()
                        await writer.wait_closed()

                    svc_name = SERVICE_MAP.get(port, "unknown")
                    port_data = {
                        "ip": ip,
                        "port": port,
                        "protocol": "tcp",
                        "state": "open",
                        "service": svc_name,
                        "banner": banner
                    }
                    ctx.open_ports.append(port_data)
                    found_ports += 1
                except Exception:
                    pass

        tasks = []
        for ip in target_ips[:15]:
            for p in ports:
                tasks.append(check_port(ip, p))

        await asyncio.gather(*tasks)
        await ctx.emit_log(f"Port scan completed: {found_ports} open ports confirmed.", level="SUCCESS", phase=self.name)
        return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True, data={"open_ports": found_ports})
