import asyncio
import uuid
import dns.asyncresolver
import dns.resolver
from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config

class SubdomainResolutionScanner(BaseScanner):
    phase_number = 3
    name = "Subdomain Resolution & Wildcard Filtering"
    description = "Concurrent asynchronous DNS resolution with wildcard DNS detection and scope filtering."

    async def run(self, ctx: ScanContext) -> ScanResult:
        domain = ctx.normalized_domain
        resolver = dns.asyncresolver.Resolver()
        resolver.timeout = config.dns_timeout
        resolver.lifetime = config.dns_timeout

        # 1. Wildcard DNS Detection
        wildcard_ips = set()
        test_sub = f"rf-wildcard-{uuid.uuid4().hex[:8]}.{domain}"
        try:
            answers = await resolver.resolve(test_sub, "A")
            for rdata in answers:
                wildcard_ips.add(rdata.to_text())
            await ctx.emit_log(f"Wildcard DNS active on {domain} resolving to: {', '.join(wildcard_ips)}", level="WARN", phase=self.name)
        except Exception:
            await ctx.emit_log("Wildcard DNS not active. Discrete host resolution verified.", level="INFO", phase=self.name)

        # 2. Concurrently resolve all candidate subdomains
        semaphore = asyncio.Semaphore(config.max_concurrency)
        live_count = 0

        async def resolve_host(sub_name: str):
            nonlocal live_count
            if ctx.is_excluded(sub_name):
                ctx.subdomains[sub_name]["is_live"] = False
                ctx.subdomains[sub_name]["excluded"] = True
                return

            async with semaphore:
                try:
                    ans = await resolver.resolve(sub_name, "A")
                    ips = [r.to_text() for r in ans]
                    # Check wildcard match
                    if wildcard_ips and all(ip in wildcard_ips for ip in ips):
                        ctx.subdomains[sub_name]["is_wildcard"] = True
                        ctx.subdomains[sub_name]["is_live"] = False
                    else:
                        ctx.subdomains[sub_name]["is_live"] = True
                        ctx.subdomains[sub_name]["ips"] = ips
                        live_count += 1
                        for ip in ips:
                            if not ctx.is_excluded(ip):
                                if ip not in ctx.ip_records:
                                    ctx.ip_records[ip] = {"ip": ip, "hosts": [sub_name], "ports": []}
                                elif sub_name not in ctx.ip_records[ip]["hosts"]:
                                    ctx.ip_records[ip]["hosts"].append(sub_name)
                except Exception:
                    ctx.subdomains[sub_name]["is_live"] = False

        candidates = [s for s in list(ctx.subdomains.keys()) if not ctx.is_excluded(s)]
        await asyncio.gather(*[resolve_host(s) for s in candidates])

        await ctx.emit_log(f"Resolution complete: [bold green]{live_count}[/bold green] live subdomains confirmed active.", level="SUCCESS", phase=self.name)
        return ScanResult(
            phase_number=self.phase_number,
            phase_name=self.name,
            success=True,
            data={"live_hosts": live_count}
        )
