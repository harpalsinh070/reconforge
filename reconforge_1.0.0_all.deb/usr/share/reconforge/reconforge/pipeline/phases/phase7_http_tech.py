import asyncio
import re
from urllib.parse import urlparse, urljoin
from typing import Dict, Any, Optional
import httpx
from bs4 import BeautifulSoup

from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config

WAF_SIGNATURES = {
    "Cloudflare": ["cf-ray", "__cfduid", "cloudflare"],
    "AWS WAF": ["x-amzn-requestid", "awselb", "awsalb"],
    "Akamai": ["akamai", "x-akamai"],
    "Imperva / Incapsula": ["x-iinfo", "incap_ses", "_incap_"],
    "F5 BIG-IP": ["bigipserver", "ts01"],
    "Sucuri": ["x-sucuri-id", "sucuri"]
}

TECH_SIGNATURES = {
    "WordPress": [r"/wp-content/", r"/wp-includes/", "wp-json"],
    "Drupal": [r"drupal\.js", r"/sites/default/files"],
    "Joomla": [r"/media/system/js/", "joomla!"],
    "Laravel": ["laravel_session", "x-xsrf-token"],
    "Django": ["csrftoken", "django"],
    "React": [r"react\.production\.min\.js", r"_next/static", "react-root"],
    "Vue.js": [r"vue\.min\.js", r"vuex"],
    "Next.js": [r"_next/static", r"__next"],
    "Bootstrap": [r"bootstrap(?:\.min)?\.css", r"bootstrap(?:\.min)?\.js"],
    "PHP": [r"\.php", "phpsessid", "x-powered-by: php"],
    "ASP.NET": ["asp.net", "viewstate", "x-aspnet-version"],
    "Nginx": ["nginx"],
    "Apache": ["apache"]
}

SECURITY_HEADERS_DEF = [
    {
        "key": "strict-transport-security",
        "name": "Strict-Transport-Security (HSTS)",
        "severity": "Low",
        "rationale": "Enforces HTTPS connections and protects clients against SSL stripping and downgrade attacks.",
        "recommendation": "Configure 'Strict-Transport-Security: max-age=31536000; includeSubDomains' on all HTTPS endpoints."
    },
    {
        "key": "content-security-policy",
        "name": "Content Security Policy (CSP)",
        "severity": "Low",
        "rationale": "Mitigates cross-site scripting (XSS), clickjacking, and code injection by restricting executable sources.",
        "recommendation": "Define a Content-Security-Policy header restricting script and object sources."
    },
    {
        "key": "x-frame-options",
        "name": "X-Frame-Options",
        "severity": "Low",
        "rationale": "Instructs browsers whether framing is permitted, protecting against UI redressing / clickjacking.",
        "recommendation": "Configure 'X-Frame-Options: SAMEORIGIN' or 'DENY'."
    },
    {
        "key": "x-content-type-options",
        "name": "X-Content-Type-Options",
        "severity": "Info",
        "rationale": "Prevents MIME-type confusion attacks by telling browsers not to sniff the response payload.",
        "recommendation": "Configure 'X-Content-Type-Options: nosniff'."
    },
    {
        "key": "referrer-policy",
        "name": "Referrer-Policy",
        "severity": "Info",
        "rationale": "Governs how much referrer information is sent along with requests to external origins.",
        "recommendation": "Configure 'Referrer-Policy: strict-origin-when-cross-origin' or 'no-referrer'."
    },
    {
        "key": "permissions-policy",
        "name": "Permissions-Policy",
        "severity": "Info",
        "rationale": "Restricts browser feature delegation (such as camera, microphone, geolocation) across origins.",
        "recommendation": "Implement a Permissions-Policy header disabling unused browser capabilities."
    }
]

class SecurityHeadersScanner(BaseScanner):
    phase_number = 5
    name = "HTTP Security Headers & Metadata Inspection"
    description = "Inspects OWASP security headers (HSTS, CSP, X-Frame-Options, etc.) and gathers metadata using a single deduplicated HTTP request."

    async def fetch_endpoint(self, client: httpx.AsyncClient, url: str, ctx: ScanContext) -> Optional[Dict[str, Any]]:
        """Fetch endpoint with in-scope redirect handling and cross-stage deduplication cache."""
        if url in ctx.http_cache:
            return ctx.http_cache[url]

        current_url = url
        redirect_hops = 0
        max_redirects = 3
        resp = None

        while redirect_hops <= max_redirects:
            try:
                parsed_cur = urlparse(current_url)
                if not ctx.is_in_scope(parsed_cur.hostname or ""):
                    # Do not follow redirects out of authorized target scope
                    break

                resp = await client.get(current_url)
                if resp.is_redirect and "location" in resp.headers:
                    next_url = urljoin(current_url, resp.headers["location"])
                    parsed_next = urlparse(next_url)
                    if ctx.is_in_scope(parsed_next.hostname or ""):
                        current_url = next_url
                        redirect_hops += 1
                        continue
                break
            except Exception:
                break

        if resp is None:
            return None

        # Build extracted metadata
        headers = {k.lower(): v for k, v in resp.headers.items()}
        text = resp.text[:10000] if hasattr(resp, "text") else ""

        title = ""
        try:
            soup = BeautifulSoup(text, "html.parser")
            title_tag = soup.find("title")
            if title_tag and title_tag.string:
                title = title_tag.string.strip()[:80]
        except Exception:
            m = re.search(r"<title>(.*?)</title>", text, re.IGNORECASE | re.DOTALL)
            if m:
                title = m.group(1).strip()[:80]

        headers_str = " ".join([f"{k}: {v}" for k, v in headers.items()]).lower()
        detected_waf = None
        for waf_name, indicators in WAF_SIGNATURES.items():
            for ind in indicators:
                if ind in headers_str:
                    detected_waf = waf_name
                    break
            if detected_waf:
                break

        detected_tech = []
        combined_content = f"{headers_str} {text.lower()}"
        for tech_name, patterns in TECH_SIGNATURES.items():
            for pat in patterns:
                if re.search(pat, combined_content, re.IGNORECASE):
                    if tech_name not in detected_tech:
                        detected_tech.append(tech_name)
                    break

        cached_data = {
            "requested_url": url,
            "final_url": str(resp.url),
            "status_code": resp.status_code,
            "headers": headers,
            "title": title or "No Title",
            "server": headers.get("server", ""),
            "waf": detected_waf,
            "tech_stack": detected_tech,
            "content_length": len(resp.content) if hasattr(resp, "content") else 0
        }

        ctx.http_cache[url] = cached_data
        ctx.http_cache[str(resp.url)] = cached_data
        return cached_data

    async def run(self, ctx: ScanContext) -> ScanResult:
        # Only run if explicitly enabled via --headers, --all, or full profile
        should_run = ctx.enable_headers or ctx.enable_all or (ctx.profile == "full")
        if not should_run:
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        if ctx.profile == "passive":
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        target_urls = set()
        if ctx.target_url:
            target_urls.add(ctx.target_url)
        else:
            # Check primary target and live hosts
            scheme = "https"
            target_urls.add(f"{scheme}://{ctx.normalized_domain}")
            # Also add port-specific web services if discovered
            web_ports = [p["port"] for p in ctx.open_ports if p.get("service") in ["http", "https", "http-alt", "https-alt"]]
            for wp in web_ports:
                s = "https" if wp in [443, 8443] else "http"
                target_urls.add(f"{s}://{ctx.normalized_domain}:{wp}")

        if not target_urls:
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        async with httpx.AsyncClient(
            verify=False,
            timeout=config.request_timeout,
            follow_redirects=False,
            headers={"User-Agent": config.user_agent}
        ) as client:
            for url in sorted(list(target_urls)):
                data = await self.fetch_endpoint(client, url, ctx)
                if not data:
                    continue

                headers = data["headers"]
                final_url = data["final_url"]

                # Evaluate security headers
                missing_headers = []
                present_headers = {}

                for h_def in SECURITY_HEADERS_DEF:
                    h_key = h_def["key"]
                    # If checking HSTS on pure HTTP, skip HSTS finding
                    if h_key == "strict-transport-security" and not final_url.startswith("https://"):
                        continue

                    # If CSP contains frame-ancestors, X-Frame-Options is satisfied
                    if h_key == "x-frame-options" and "content-security-policy" in headers:
                        if "frame-ancestors" in headers["content-security-policy"].lower():
                            present_headers[h_def["name"]] = "Satisfied via CSP frame-ancestors"
                            continue

                    val = headers.get(h_key)
                    if not val:
                        missing_headers.append(h_def["name"])
                        ctx.add_finding(
                            title=f"Observation: Missing {h_def['name']}",
                            severity="Info",
                            category="Security Headers",
                            confidence="confirmed",
                            affected_url=final_url,
                            evidence=f"Endpoint {final_url} returned HTTP {data['status_code']}. Header '{h_key}' was not present in response headers.",
                            rationale=f"{h_def['rationale']} Classified as an informational posture observation, not an actively exploitable vulnerability.",
                            recommendation=h_def["recommendation"],
                            is_observation=True
                        )
                    else:
                        present_headers[h_def["name"]] = val
                        if h_key == "x-content-type-options" and "nosniff" not in val.lower():
                            missing_headers.append(f"{h_def['name']} (misconfigured)")
                            ctx.add_finding(
                                title=f"Observation: Misconfigured {h_def['name']}",
                                severity="Low",
                                category="Security Headers",
                                confidence="confirmed",
                                affected_url=final_url,
                                evidence=f"Endpoint {final_url} returned HTTP {data['status_code']} with header '{h_key}: {val}' instead of 'nosniff'.",
                                rationale=f"{h_def['rationale']} Misconfiguration noted in received response header.",
                                recommendation=h_def["recommendation"],
                                is_observation=True
                            )

                # Add to ctx.http_assets if not already present
                if not any(a.get("url") == data["final_url"] for a in ctx.http_assets):
                    ctx.http_assets.append({
                        "url": data["final_url"],
                        "status_code": data["status_code"],
                        "title": data["title"],
                        "web_server": data["server"],
                        "tech_stack": data["tech_stack"],
                        "waf": data["waf"],
                        "content_length": data["content_length"],
                        "headers": data["headers"],
                        "missing_headers": missing_headers,
                        "present_headers": present_headers
                    })

        await ctx.emit_log(f"HTTP security-header evaluation complete for target endpoints.", level="SUCCESS", phase=self.name)
        return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)
