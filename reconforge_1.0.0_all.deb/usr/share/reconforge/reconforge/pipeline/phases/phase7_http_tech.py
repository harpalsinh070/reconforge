import asyncio
import re
import httpx
from bs4 import BeautifulSoup
from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config

WAF_SIGNATURES = {
    "Cloudflare": ["cf-ray", "__cfduid", "cloudflare"],
    "AWS WAF": ["x-amzn-requestid", "awselb", "awsalb"],
    "Akamai": ["akamai", "x-akamai"],
    "Imperva / Incapsula": ["x-iinfo", "incap_ses", "_incap_"],
    "F5 BIG-IP": ["bigipserver", "ts01"],
    "Sucuri": ["x-sucuri-id", "sucuri"]
}

TECH_SIGNATURES = {
    "WordPress": [r"/wp-content/", r"/wp-includes/", "wp-json"],
    "Drupal": [r"drupal\.js", r"/sites/default/files"],
    "Joomla": [r"/media/system/js/", "joomla!"],
    "Laravel": ["laravel_session", "x-xsrf-token"],
    "Django": ["csrftoken", "django"],
    "React": [r"react\.production\.min\.js", r"_next/static", "react-root"],
    "Vue.js": [r"vue\.min\.js", r"vuex"],
    "Next.js": [r"_next/static", r"__next"],
    "Bootstrap": [r"bootstrap(?:\.min)?\.css", r"bootstrap(?:\.min)?\.js"],
    "PHP": [r"\.php", "phpsessid", "x-powered-by: php"],
    "ASP.NET": ["asp.net", "viewstate", "x-aspnet-version"],
    "Nginx": ["nginx"],
    "Apache": ["apache"]
}

class HTTPTechProberScanner(BaseScanner):
    phase_number = 7
    name = "HTTP Probing & Technology Fingerprinting"
    description = "Probes in-scope web endpoints, extracts status, titles, headers, WAF indicators, and technology stacks."

    async def run(self, ctx: ScanContext) -> ScanResult:
        live_subs = [s for s, d in ctx.subdomains.items() if d.get("is_live") and not ctx.is_excluded(s)]
        if not live_subs and not ctx.is_excluded(ctx.normalized_domain):
            live_subs = [ctx.normalized_domain]

        if not live_subs:
            await ctx.emit_log("No in-scope live hosts available for HTTP probing. Skipping.", level="INFO", phase=self.name)
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        await ctx.emit_log(f"Probing HTTP/HTTPS services across {len(live_subs)} active endpoints...", level="INFO", phase=self.name)

        semaphore = asyncio.Semaphore(config.max_concurrency)

        async with httpx.AsyncClient(
            verify=False,
            timeout=config.request_timeout,
            follow_redirects=True,
            headers={"User-Agent": config.user_agent}
        ) as client:

            async def probe_url(url: str):
                async with semaphore:
                    try:
                        resp = await client.get(url)
                        text = resp.text[:10000]
                        headers = {k.lower(): v for k, v in resp.headers.items()}
                        headers_str = " ".join([f"{k}: {v}" for k, v in headers.items()]).lower()

                        # Extract Page Title
                        title = ""
                        try:
                            soup = BeautifulSoup(text, "html.parser")
                            title_tag = soup.find("title")
                            if title_tag and title_tag.string:
                                title = title_tag.string.strip()[:80]
                        except Exception:
                            m = re.search(r"<title>(.*?)</title>", text, re.IGNORECASE | re.DOTALL)
                            if m:
                                title = m.group(1).strip()[:80]

                        server = headers.get("server", "")

                        # Detect WAF
                        detected_waf = None
                        for waf_name, indicators in WAF_SIGNATURES.items():
                            for ind in indicators:
                                if ind in headers_str:
                                    detected_waf = waf_name
                                    break
                            if detected_waf:
                                break

                        # Detect Tech Stack
                        detected_tech = []
                        combined_content = f"{headers_str} {text.lower()}"
                        for tech_name, patterns in TECH_SIGNATURES.items():
                            for pat in patterns:
                                if re.search(pat, combined_content, re.IGNORECASE):
                                    if tech_name not in detected_tech:
                                        detected_tech.append(tech_name)
                                    break

                        asset = {
                            "url": str(resp.url),
                            "status_code": resp.status_code,
                            "title": title or "No Title",
                            "web_server": server,
                            "tech_stack": detected_tech,
                            "waf": detected_waf,
                            "content_length": len(resp.content),
                            "headers": headers
                        }
                        ctx.http_assets.append(asset)
                        tech_label = f"[{', '.join(detected_tech)}]" if detected_tech else ""
                        waf_label = f" | WAF: {detected_waf}" if detected_waf else ""
                        await ctx.emit_log(
                            f"[cyan]{resp.status_code}[/cyan] [bold white]{resp.url}[/bold white] - '{title}' {tech_label}{waf_label}",
                            level="SUCCESS",
                            phase=self.name
                        )
                    except Exception:
                        pass

            tasks = []
            for sub in live_subs[:20]:
                tasks.append(probe_url(f"https://{sub}"))
                tasks.append(probe_url(f"http://{sub}"))

            await asyncio.gather(*tasks)

        await ctx.emit_log(f"HTTP probing complete: [bold green]{len(ctx.http_assets)}[/bold green] active web services analyzed.", level="SUCCESS", phase=self.name)
        return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True, data={"http_services": len(ctx.http_assets)})
