import asyncio
import shutil
import json
from urllib.parse import urljoin
import httpx
from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config

SAFE_EXPOSURE_CHECKS = [
    {
        "path": "/.git/HEAD",
        "match": "ref: refs/",
        "title": "Exposed Git Repository (.git/HEAD)",
        "severity": "High",
        "category": "Source Code Exposure",
        "recommendation": "Restrict web server access to .git directories immediately in reverse proxy configuration."
    },
    {
        "path": "/.env",
        "match": "DB_|APP_|SECRET|API_KEY|DATABASE_URL",
        "title": "Exposed Environment File (.env)",
        "severity": "Critical",
        "category": "Secret Leak",
        "recommendation": "Block access to dotfiles (.env) immediately and rotate all exposed secrets."
    },
    {
        "path": "/robots.txt",
        "match": "User-agent:",
        "title": "Disclosed Robots.txt File",
        "severity": "Low",
        "category": "Information Disclosure",
        "recommendation": "Review robots.txt disallow rules to verify that sensitive internal admin endpoints are not publicly indexed."
    },
    {
        "path": "/actuator/health",
        "match": "\"status\":\"UP\"",
        "title": "Exposed Spring Boot Actuator Endpoint",
        "severity": "Medium",
        "category": "Information Disclosure",
        "recommendation": "Secure actuator endpoints using Spring Security and restrict external access."
    },
    {
        "path": "/phpinfo.php",
        "match": "PHP Version",
        "title": "Exposed PHPInfo Diagnostic Page",
        "severity": "Medium",
        "category": "Information Disclosure",
        "recommendation": "Remove phpinfo diagnostic script from production web directory."
    },
    {
        "path": "/server-status",
        "match": "Apache Server Status",
        "title": "Exposed Apache Server Status",
        "severity": "Low",
        "category": "Information Disclosure",
        "recommendation": "Restrict mod_status /server-status access to 127.0.0.1 only."
    },
    {
        "path": "/swagger.json",
        "match": "\"swagger\":",
        "title": "Public OpenAPI / Swagger Specification",
        "severity": "Low",
        "category": "API Exposure",
        "recommendation": "Ensure public API endpoints exposed in Swagger require proper authorization."
    }
]

class SafeAuditScanner(BaseScanner):
    phase_number = 9
    name = "Safe Exposure & Vulnerability Audit"
    description = "Checks for exposed secrets, .git repositories, diagnostic pages, and invokes Nuclei if installed."

    async def run(self, ctx: ScanContext) -> ScanResult:
        if ctx.profile == "passive":
            await ctx.emit_log("Passive scan profile selected. Skipping exposure probes.", level="INFO", phase=self.name)
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        target_urls = [a["url"] for a in ctx.http_assets if not ctx.is_excluded(a["url"])]
        if not target_urls and not ctx.is_excluded(ctx.normalized_domain):
            target_urls = [f"https://{ctx.normalized_domain}", f"http://{ctx.normalized_domain}"]

        if not target_urls:
            await ctx.emit_log("No targets available for safe exposure audit.", level="INFO", phase=self.name)
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        await ctx.emit_log(f"Auditing safe exposure vectors across {len(target_urls[:8])} web endpoints...", level="INFO", phase=self.name)

        findings_count = 0
        async with httpx.AsyncClient(
            verify=False,
            timeout=5.0,
            follow_redirects=False,
            headers={"User-Agent": config.user_agent}
        ) as client:
            for base_url in target_urls[:8]:
                for check in SAFE_EXPOSURE_CHECKS:
                    target_endpoint = urljoin(base_url, check["path"])
                    try:
                        resp = await client.get(target_endpoint)
                        if resp.status_code == 200 and check["match"] in resp.text:
                            findings_count += 1
                            finding_data = {
                                "title": f"{check['title']}: {target_endpoint}",
                                "severity": check["severity"],
                                "category": check["category"],
                                "affected_url": target_endpoint,
                                "description": f"Target endpoint {target_endpoint} returned HTTP 200 containing signature '{check['match']}'.",
                                "evidence": f"Response snippet: {resp.text[:120].strip()}",
                                "recommendation": check["recommendation"]
                            }
                            ctx.findings.append(finding_data)
                            color = "red" if check["severity"] in ["Critical", "High"] else "yellow"
                            await ctx.emit_log(f"[bold {color}][!] Finding Discovered ({check['severity']}):[/bold {color}] {target_endpoint}", level="WARN", phase=self.name)
                    except Exception:
                        pass

        # Optional Nuclei integration if installed in PATH
        nuclei_bin = shutil.which(config.nuclei_path)
        if nuclei_bin and target_urls and ctx.profile == "full":
            await ctx.emit_log(f"Nuclei detected at {nuclei_bin}. Executing safe non-intrusive templates...", level="INFO", phase=self.name)
            try:
                first_url = target_urls[0]
                proc = await asyncio.create_subprocess_exec(
                    nuclei_bin, "-u", first_url, "-tags", "exposure,misconfig", "-severity", "info,low,medium", "-silent", "-jsonl",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=30.0)
                if proc.returncode == 0:
                    for line in stdout.decode(errors="ignore").splitlines():
                        try:
                            n_item = json.loads(line)
                            n_info = n_item.get("info", {})
                            ctx.findings.append({
                                "title": f"Nuclei: {n_info.get('name', 'Template Match')}",
                                "severity": n_info.get("severity", "Info").capitalize(),
                                "category": "Nuclei Detection",
                                "affected_url": n_item.get("matched-at", first_url),
                                "description": n_info.get("description", ""),
                                "evidence": f"Template ID: {n_item.get('template-id')}",
                                "recommendation": "Review and remediate according to template reference."
                            })
                            findings_count += 1
                        except Exception:
                            pass
            except Exception as e:
                await ctx.emit_log(f"Nuclei execution error: {e}", level="DEBUG", phase=self.name)

        await ctx.emit_log(f"Exposure audit complete: [bold yellow]{findings_count}[/bold yellow] findings discovered.", level="SUCCESS", phase=self.name)
        return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True, data={"findings": findings_count})
