import asyncio
import shutil
import json
from urllib.parse import urljoin
import httpx
from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config

SAFE_DIRECTORY_CHECKS = [
    {
        "path": "/.git/HEAD",
        "match": "ref: refs/",
        "title": "Exposed Git Repository (.git/HEAD)",
        "severity": "High",
        "category": "Source Code Exposure",
        "confidence": "confirmed",
        "rationale": "Direct access to .git metadata enables attackers to reconstruct full source code and commit history.",
        "recommendation": "Restrict web server access to dotfiles and .git directories immediately."
    },
    {
        "path": "/.env",
        "match": "DB_|APP_|SECRET|API_KEY|DATABASE_URL",
        "title": "Exposed Environment File (.env)",
        "severity": "Critical",
        "category": "Secret Leak",
        "confidence": "confirmed",
        "rationale": "Direct leak of server environment variables containing database and API credentials.",
        "recommendation": "Block access to .env files and rotate all exposed credentials immediately."
    },
    {
        "path": "/robots.txt",
        "match": "User-agent:",
        "title": "Disclosed Robots.txt File",
        "severity": "Low",
        "category": "Information Disclosure",
        "confidence": "confirmed",
        "rationale": "Disallowed paths in robots.txt may reveal sensitive administrative directories.",
        "recommendation": "Ensure disallowed paths in robots.txt require strong authentication."
    },
    {
        "path": "/actuator/health",
        "match": "\"status\":\"UP\"",
        "title": "Exposed Spring Boot Actuator Endpoint",
        "severity": "Medium",
        "category": "Information Disclosure",
        "confidence": "confirmed",
        "rationale": "Spring Boot Actuators disclose runtime application health and operational details.",
        "recommendation": "Restrict actuator access to internal networks or authenticate via Spring Security."
    },
    {
        "path": "/server-status",
        "match": "Apache Server Status",
        "title": "Exposed Apache Server Status",
        "severity": "Low",
        "category": "Information Disclosure",
        "confidence": "confirmed",
        "rationale": "Mod_status reveals real-time client IP addresses, requested URIs, and vhost statistics.",
        "recommendation": "Restrict mod_status (/server-status) access to 127.0.0.1."
    }
]

class SafeAuditScanner(BaseScanner):
    phase_number = 13  # Optional advanced module
    name = "Directory Discovery & Vulnerability Scan"
    description = "Checks safe exposure directories (--directories) and executes Nuclei templates (--vuln-scan)."

    async def run(self, ctx: ScanContext) -> ScanResult:
        run_dirs = ctx.enable_directories or (ctx.profile == "full")
        run_nuclei = ctx.enable_vuln_scan or (ctx.profile == "full")

        # Skip if neither optional module is enabled
        if not (run_dirs or run_nuclei) or ctx.profile in ["passive", "quick"]:
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        target_urls = [a["url"] for a in ctx.http_assets if not ctx.is_excluded(a["url"])]
        if not target_urls and not ctx.is_excluded(ctx.normalized_domain):
            target_urls = [f"https://{ctx.normalized_domain}", f"http://{ctx.normalized_domain}"]

        findings_count = 0

        # 1. Directory / file exposure discovery (--directories)
        if run_dirs and target_urls:
            async with httpx.AsyncClient(
                verify=False,
                timeout=4.0,
                follow_redirects=False,
                headers={"User-Agent": config.user_agent}
            ) as client:
                for base_url in target_urls[:6]:
                    for check in SAFE_DIRECTORY_CHECKS:
                        target_endpoint = urljoin(base_url, check["path"])
                        try:
                            resp = await client.get(target_endpoint)
                            if resp.status_code == 200 and check["match"] in resp.text:
                                findings_count += 1
                                ctx.add_finding(
                                    title=check["title"],
                                    severity=check["severity"],
                                    category=check["category"],
                                    confidence=check["confidence"],
                                    affected_url=target_endpoint,
                                    evidence=f"HTTP 200 returned signature '{check['match']}'. Response: {resp.text[:80].strip()}",
                                    rationale=check["rationale"],
                                    recommendation=check["recommendation"]
                                )
                        except Exception:
                            pass

        # 2. Nuclei vulnerability scan (--vuln-scan)
        if run_nuclei:
            nuclei_bin = shutil.which(config.nuclei_path)
            if nuclei_bin and target_urls:
                try:
                    first_url = target_urls[0]
                    proc = await asyncio.create_subprocess_exec(
                        nuclei_bin, "-u", first_url, "-tags", "exposure,misconfig", "-severity", "info,low,medium", "-silent", "-jsonl",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=35.0)
                    nuclei_found = 0
                    if proc.returncode == 0:
                        for line in stdout.decode(errors="ignore").splitlines():
                            try:
                                n_item = json.loads(line)
                                n_info = n_item.get("info", {})
                                ctx.add_finding(
                                    title=f"Nuclei: {n_info.get('name', 'Exposure Template')}",
                                    severity=n_info.get("severity", "Low").capitalize(),
                                    category="Vulnerability Audit",
                                    confidence="confirmed",
                                    affected_url=n_item.get("matched-at", first_url),
                                    evidence=f"Template: {n_item.get('template-id')}",
                                    rationale=n_info.get("description", "Nuclei security template match."),
                                    recommendation="Review endpoint and apply template remediation reference."
                                )
                                nuclei_found += 1
                                findings_count += 1
                            except Exception:
                                pass
                        ctx.record_tool("nuclei", "executed", nuclei_found)
                except Exception as e:
                    ctx.record_tool("nuclei", "error", 0, str(e))
            else:
                ctx.record_tool("nuclei", "not_installed" if not nuclei_bin else "skipped")

        return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True, data={"findings": findings_count})
