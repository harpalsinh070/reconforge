import ssl
import socket
from datetime import datetime, timezone
from urllib.parse import urlparse
from typing import Dict, Any, List

from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config

class TLSInspectionScanner(BaseScanner):
    phase_number = 6
    name = "TLS Certificate & Configuration Inspection"
    description = "Inspects TLS certificate validity, expiration, and negotiated cryptographic parameters independently via SSL sockets."

    async def run(self, ctx: ScanContext) -> ScanResult:
        # Only run if explicitly enabled via --tls, --all, or full profile
        should_run = ctx.enable_tls or ctx.enable_all or (ctx.profile == "full")
        if not should_run:
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        if ctx.profile == "passive":
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        # Build list of HTTPS endpoints/hosts to inspect
        targets_to_inspect = []  # tuples of (host, port, url_str)
        if ctx.target_url:
            parsed = urlparse(ctx.target_url)
            if parsed.scheme.lower() == "https":
                host = parsed.hostname or ctx.normalized_domain
                port = parsed.port or 443
                targets_to_inspect.append((host, port, ctx.target_url))
        else:
            host = ctx.normalized_domain
            targets_to_inspect.append((host, 443, f"https://{host}"))
            # Check other HTTPS ports discovered
            for p in ctx.open_ports:
                if p["port"] in [8443, 4433, 9443] or p.get("service") in ["https", "ssl", "https-alt"]:
                    if p["port"] != 443:
                        targets_to_inspect.append((host, p["port"], f"https://{host}:{p['port']}"))

        if not targets_to_inspect:
            await ctx.emit_log("Target does not utilize HTTPS. Skipping TLS certificate inspection.", level="INFO", phase=self.name)
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        inspected_hosts = set()
        for host, port, url_ref in targets_to_inspect:
            target_key = f"{host}:{port}"
            if target_key in inspected_hosts:
                continue
            inspected_hosts.add(target_key)

            try:
                ssl_context = ssl.create_default_context()
                # Connect directly using raw TLS socket (independent of HTTP)
                with socket.create_connection((host, port), timeout=config.request_timeout) as sock:
                    with ssl_context.wrap_socket(sock, server_hostname=host) as ssock:
                        cert = ssock.getpeercert()
                        tls_version = ssock.version()
                        cipher_info = ssock.cipher()  # (cipher_name, protocol, secret_bits)

                        not_after_str = cert.get("notAfter", "")
                        not_before_str = cert.get("notBefore", "")

                        # Parse expiration date
                        # Standard format: "May 25 12:00:00 2026 GMT"
                        exp_date = datetime.strptime(not_after_str, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
                        days_left = (exp_date - datetime.now(timezone.utc)).days

                        # Extract Subject, Issuer, SANs
                        subject = dict(x[0] for x in cert.get("subject", ()))
                        issuer = dict(x[0] for x in cert.get("issuer", ()))
                        sans = [v for k, v in cert.get("subjectAltName", ()) if k == "DNS"]

                        cipher_name = cipher_info[0] if cipher_info else "Unknown"
                        cipher_bits = cipher_info[2] if cipher_info and len(cipher_info) > 2 else 0

                        ctx.tls_data[target_key] = {
                            "host": host,
                            "port": port,
                            "url": url_ref,
                            "protocol": tls_version,
                            "cipher": cipher_name,
                            "cipher_bits": cipher_bits,
                            "days_left": days_left,
                            "expires_on": exp_date.strftime("%Y-%m-%d"),
                            "subject_cn": subject.get("commonName", host),
                            "issuer_cn": issuer.get("commonName", "Unknown"),
                            "sans": sans
                        }

                        await ctx.emit_log(
                            f"TLS handshake on {target_key}: Protocol={tls_version}, Negotiated Cipher={cipher_name} ({cipher_bits} bits), Days Left={days_left}",
                            level="INFO",
                            phase=self.name
                        )

                        # Evaluate Certificate Expiration
                        if days_left <= 0:
                            ctx.add_finding(
                                title=f"TLS Certificate Expired ({target_key})",
                                severity="High",
                                category="TLS / Cryptography",
                                confidence="confirmed",
                                affected_url=url_ref,
                                evidence=f"Certificate expired on {exp_date.strftime('%Y-%m-%d')} ({abs(days_left)} days ago).",
                                rationale="An expired TLS certificate causes web browsers to display severe security warnings and break client trust.",
                                recommendation="Renew and replace the expired TLS certificate immediately."
                            )
                        elif days_left <= 15:
                            ctx.add_finding(
                                title=f"Observation: TLS Certificate Expiring Soon ({days_left} Days Remaining)",
                                severity="Medium",
                                category="TLS / Cryptography",
                                confidence="confirmed",
                                affected_url=url_ref,
                                evidence=f"Certificate expires on {exp_date.strftime('%Y-%m-%d')} ({days_left} days remaining).",
                                rationale="Certificates expiring within 15 days risk service outage if automated renewal mechanisms fail.",
                                recommendation="Verify automated ACME/certbot renewal configuration to avoid downtime."
                            )

                        # Self-Signed Evaluation
                        if subject and issuer and subject == issuer:
                            ctx.add_finding(
                                title=f"Observation: Self-Signed TLS Certificate ({target_key})",
                                severity="Low",
                                category="TLS / Cryptography",
                                confidence="confirmed",
                                affected_url=url_ref,
                                evidence=f"Issuer '{issuer.get('commonName', 'Unknown')}' matches Subject.",
                                rationale="Self-signed certificates are not signed by a trusted Public Certificate Authority and will trigger untrusted warning dialogs.",
                                recommendation="Install a certificate issued by a trusted Certificate Authority (e.g. Let's Encrypt)."
                            )

                        # Check deprecated TLS protocols
                        if tls_version in ["TLSv1", "TLSv1.1", "SSLv2", "SSLv3"]:
                            ctx.add_finding(
                                title=f"Insecure Legacy TLS Protocol Negotiated ({tls_version})",
                                severity="High",
                                category="TLS / Cryptography",
                                confidence="confirmed",
                                affected_url=url_ref,
                                evidence=f"Server accepted connection using deprecated protocol: {tls_version}.",
                                rationale="TLS 1.0 and 1.1 have known cryptographic weaknesses and are deprecated by RFC 8996.",
                                recommendation="Disable TLS 1.0 and TLS 1.1 in the server configuration. Enforce TLS 1.2 and TLS 1.3 only."
                            )

            except ssl.SSLCertVerificationError as e:
                ctx.add_finding(
                    title=f"TLS Certificate Verification Failed ({target_key})",
                    severity="Medium",
                    category="TLS / Cryptography",
                    confidence="confirmed",
                    affected_url=url_ref,
                    evidence=f"SSL verification error: {str(e)}",
                    rationale="The certificate chain cannot be verified against the default root trust store.",
                    recommendation="Ensure the full certificate chain (including intermediate CA certificates) is properly configured."
                )
            except Exception as e:
                await ctx.emit_log(f"TLS inspection on {target_key} encountered connection error: {e}", level="WARN", phase=self.name)

        return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)
