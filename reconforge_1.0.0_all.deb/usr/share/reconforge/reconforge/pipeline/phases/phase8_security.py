import ssl
import socket
from datetime import datetime
from urllib.parse import urlparse
from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config

IMPORTANT_HEADERS = [
    ("strict-transport-security", "HSTS Missing", "Medium", "Web traffic may be susceptible to SSL stripping attacks."),
    ("content-security-policy", "Content Security Policy (CSP) Missing", "Low", "Absence of CSP reduces defense against Cross-Site Scripting (XSS)."),
    ("x-frame-options", "X-Frame-Options Header Missing", "Low", "Application may be vulnerable to UI clickjacking."),
    ("x-content-type-options", "X-Content-Type-Options Header Missing", "Low", "Browsers may perform MIME-type sniffing, increasing script injection risk.")
]

class SecurityAuditScanner(BaseScanner):
    phase_number = 8
    name = "TLS Certificate & Security Headers Audit"
    description = "Inspects SSL/TLS expiration, SAN coverage, OWASP security headers, and cookie protection flags."

    async def run(self, ctx: ScanContext) -> ScanResult:
        if not ctx.http_assets:
            await ctx.emit_log("No HTTP assets available for security header audit. Skipping.", level="INFO", phase=self.name)
            return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)

        await ctx.emit_log(f"Auditing SSL certificates and HTTP security headers across {len(ctx.http_assets)} assets...", level="INFO", phase=self.name)

        inspected_hosts = set()
        for asset in ctx.http_assets:
            url = asset["url"]
            parsed = urlparse(url)
            host = parsed.hostname
            port = parsed.port or (443 if parsed.scheme == "https" else 80)
            headers = asset.get("headers", {})

            # 1. Audit Headers
            missing = []
            for h_key, title, sev, impact in IMPORTANT_HEADERS:
                if h_key not in headers:
                    missing.append(h_key)
            asset["missing_headers"] = missing

            if len(missing) >= 3 and asset.get("status_code", 0) in [200, 301, 302]:
                ctx.findings.append({
                    "title": f"Multiple Missing Security Headers on {url}",
                    "severity": "Low",
                    "category": "Security Headers",
                    "affected_url": url,
                    "description": f"Target is missing recommended OWASP headers: {', '.join(missing)}.",
                    "evidence": f"Headers missing: {missing}",
                    "recommendation": "Configure reverse proxy or web application to enforce HSTS, CSP, and X-Frame-Options."
                })

            # 2. Inspect TLS Certificate
            if parsed.scheme == "https" and host not in inspected_hosts:
                inspected_hosts.add(host)
                try:
                    ssl_context = ssl.create_default_context()
                    with socket.create_connection((host, port), timeout=3.0) as sock:
                        with ssl_context.wrap_socket(sock, server_hostname=host) as ssock:
                            cert = ssock.getpeercert()
                            not_after_str = cert.get("notAfter", "")
                            # Parse date: "May 25 12:00:00 2026 GMT"
                            exp_date = datetime.strptime(not_after_str, "%b %d %H:%M:%S %Y %Z")
                            days_left = (exp_date - datetime.utcnow()).days
                            asset["tls_expiry_days"] = days_left

                            if days_left < 15:
                                ctx.findings.append({
                                    "title": f"SSL/TLS Certificate Expiring Soon on {host} ({days_left} days left)",
                                    "severity": "Medium" if days_left > 0 else "High",
                                    "category": "TLS / Cryptography",
                                    "affected_url": url,
                                    "description": f"The SSL certificate for {host} will expire on {exp_date}.",
                                    "evidence": f"Expiration: {not_after_str} (Days remaining: {days_left})",
                                    "recommendation": "Renew SSL certificate immediately to prevent service disruption."
                                })
                                await ctx.emit_log(f"[bold yellow][!] Certificate Expiring:[/bold yellow] {host} has {days_left} days remaining.", level="WARN", phase=self.name)
                except Exception:
                    pass

        await ctx.emit_log("TLS and HTTP security header evaluation complete.", level="SUCCESS", phase=self.name)
        return ScanResult(phase_number=self.phase_number, phase_name=self.name, success=True)
