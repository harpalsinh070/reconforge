import asyncio
import shutil
import json
import httpx
from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config

class PassiveOSINTScanner(BaseScanner):
    phase_number = 2
    name = "Passive OSINT Subdomain Enumeration"
    description = "Queries Certificate Transparency (crt.sh), AlienVault OTX, and native Subfinder without direct target probing."

    async def run(self, ctx: ScanContext) -> ScanResult:
        domain = ctx.normalized_domain
        discovered = set()
        await ctx.emit_log(f"Starting passive OSINT enumeration for [bold cyan]{domain}[/bold cyan]...", level="INFO", phase=self.name)

        # 1. Native Subfinder if installed in PATH
        subfinder_bin = shutil.which(config.subfinder_path)
        if subfinder_bin:
            await ctx.emit_log(f"Native subfinder detected ({subfinder_bin}). Running passive query...", level="INFO", phase=self.name)
            try:
                proc = await asyncio.create_subprocess_exec(
                    subfinder_bin, "-d", domain, "-silent",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=30.0)
                if proc.returncode == 0:
                    sf_count = 0
                    for line in stdout.decode(errors="ignore").splitlines():
                        sub = line.strip().lower().rstrip(".")
                        if sub and ctx.is_in_scope(sub):
                            discovered.add(sub)
                            sf_count += 1
                    await ctx.emit_log(f"Subfinder discovered {sf_count} passive records.", level="INFO", phase=self.name)
            except Exception as e:
                await ctx.emit_log(f"Subfinder skipped: {e}", level="WARN", phase=self.name)

        # 2. Certificate Transparency via crt.sh
        client_headers = {
            "User-Agent": config.user_agent,
            "Accept": "application/json"
        }
        async with httpx.AsyncClient(timeout=15.0, verify=False, headers=client_headers) as client:
            try:
                crt_url = f"https://crt.sh/?q=%.{domain}&output=json"
                resp = await client.get(crt_url)
                if resp.status_code == 200:
                    try:
                        entries = resp.json()
                        crt_count = 0
                        for item in entries:
                            name_val = item.get("name_value", "")
                            for raw_n in name_val.split("\n"):
                                n = raw_n.strip().lower().rstrip(".")
                                if n.startswith("*."):
                                    n = n[2:]
                                if n and " " not in n and ctx.is_in_scope(n):
                                    if n not in discovered:
                                        discovered.add(n)
                                        crt_count += 1
                        await ctx.emit_log(f"crt.sh CT logs yielded {crt_count} unique host candidates.", level="INFO", phase=self.name)
                    except Exception as json_err:
                        await ctx.emit_log(f"crt.sh response could not be parsed: {json_err}", level="DEBUG", phase=self.name)
                elif resp.status_code == 429:
                    await ctx.emit_log("crt.sh rate limit reached (HTTP 429). Continuing with existing intelligence.", level="WARN", phase=self.name)
                else:
                    await ctx.emit_log(f"crt.sh returned HTTP status {resp.status_code}. Continuing...", level="DEBUG", phase=self.name)
            except httpx.TimeoutException:
                await ctx.emit_log("crt.sh query timed out after 15s. Continuing with available intelligence.", level="WARN", phase=self.name)
            except Exception as e:
                await ctx.emit_log(f"crt.sh lookup skipped: {e}", level="DEBUG", phase=self.name)

            # 3. AlienVault OTX (integrated when configured or publicly accessible)
            otx_headers = client_headers.copy()
            if config.otx_api_key:
                otx_headers["X-OTX-API-KEY"] = config.otx_api_key
                await ctx.emit_log("AlienVault OTX authenticated query active.", level="INFO", phase=self.name)
            else:
                await ctx.emit_log("AlienVault OTX key not configured (set OTX_API_KEY). Querying public feed...", level="DEBUG", phase=self.name)

            try:
                otx_url = f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}/passive_dns"
                resp = await client.get(otx_url, headers=otx_headers)
                if resp.status_code == 200:
                    data = resp.json()
                    records = data.get("passive_dns", [])
                    otx_count = 0
                    for r in records:
                        hostname = r.get("hostname", "").strip().lower().rstrip(".")
                        if hostname and ctx.is_in_scope(hostname):
                            if hostname not in discovered:
                                discovered.add(hostname)
                                otx_count += 1
                    if otx_count > 0:
                        await ctx.emit_log(f"AlienVault OTX provided {otx_count} passive DNS records.", level="INFO", phase=self.name)
                elif resp.status_code == 429:
                    await ctx.emit_log("AlienVault OTX rate limited. Continuing...", level="DEBUG", phase=self.name)
                elif resp.status_code == 403:
                    await ctx.emit_log("AlienVault OTX requires API key configuration. Skipped.", level="DEBUG", phase=self.name)
            except httpx.TimeoutException:
                await ctx.emit_log("AlienVault OTX query timed out.", level="DEBUG", phase=self.name)
            except Exception as e:
                await ctx.emit_log(f"AlienVault OTX query skipped: {e}", level="DEBUG", phase=self.name)

        # Populate context subdomains with deduplicated in-scope candidates
        for sub in discovered:
            if not ctx.is_excluded(sub) and sub not in ctx.subdomains:
                ctx.subdomains[sub] = {
                    "name": sub,
                    "is_live": False,  # Will be verified in Phase 3
                    "is_apex": (sub == domain),
                    "dns_records": {}
                }

        await ctx.emit_log(f"Passive OSINT completed: [bold green]{len(ctx.subdomains)}[/bold green] deduplicated in-scope host candidates.", level="SUCCESS", phase=self.name)
        return ScanResult(
            phase_number=self.phase_number,
            phase_name=self.name,
            success=True,
            data={"discovered_count": len(discovered), "total_candidates": len(ctx.subdomains)}
        )
