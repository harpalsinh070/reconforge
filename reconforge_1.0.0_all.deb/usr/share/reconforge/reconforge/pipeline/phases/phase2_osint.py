import asyncio
import shutil
import json
import httpx
from ..base import BaseScanner, ScanContext, ScanResult
from ...config import config

class PassiveOSINTScanner(BaseScanner):
    phase_number = 2
    name = "Passive Subdomain Enumeration"
    description = "Queries Certificate Transparency (crt.sh), AlienVault OTX, and installed Subfinder."

    async def run(self, ctx: ScanContext) -> ScanResult:
        domain = ctx.normalized_domain
        discovered = set()
        subdomain_sources = {}

        # 1. Native Subfinder integration if installed
        subfinder_bin = shutil.which(config.subfinder_path)
        if subfinder_bin:
            try:
                proc = await asyncio.create_subprocess_exec(
                    subfinder_bin, "-d", domain, "-silent",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30.0)
                if proc.returncode == 0:
                    sf_count = 0
                    for line in stdout.decode(errors="ignore").splitlines():
                        sub = line.strip().lower().rstrip(".")
                        if sub and ctx.is_in_scope(sub):
                            discovered.add(sub)
                            subdomain_sources.setdefault(sub, set()).add("Subfinder")
                            sf_count += 1
                    ctx.record_tool("subfinder", "executed", sf_count, f"Processed {sf_count} subdomains")
                    if sf_count > 0:
                        await ctx.emit_log(f"Subfinder executed: discovered {sf_count} passive records.", level="INFO", phase=self.name)
                else:
                    err_msg = stderr.decode(errors="ignore").strip()[:100]
                    ctx.record_tool("subfinder", "failed", 0, err_msg)
            except Exception as e:
                ctx.record_tool("subfinder", "error", 0, str(e))
        else:
            ctx.record_tool("subfinder", "not_installed")

        # 2. Certificate Transparency via crt.sh
        client_headers = {
            "User-Agent": config.user_agent,
            "Accept": "application/json"
        }
        async with httpx.AsyncClient(timeout=12.0, verify=False, headers=client_headers) as client:
            try:
                crt_url = f"https://crt.sh/?q=%.{domain}&output=json"
                resp = await client.get(crt_url)
                if resp.status_code == 200:
                    try:
                        entries = resp.json()
                        crt_count = 0
                        for item in entries:
                            name_val = item.get("name_value", "")
                            for raw_n in name_val.split("\n"):
                                n = raw_n.strip().lower().rstrip(".")
                                if n.startswith("*."):
                                    n = n[2:]
                                if n and " " not in n and ctx.is_in_scope(n):
                                    discovered.add(n)
                                    subdomain_sources.setdefault(n, set()).add("crt.sh")
                                    crt_count += 1
                        if crt_count > 0:
                            await ctx.emit_log(f"crt.sh CT logs provided {crt_count} unique host records.", level="INFO", phase=self.name)
                    except Exception:
                        pass
                elif resp.status_code == 429:
                    await ctx.emit_log("crt.sh rate limited (HTTP 429).", level="DEBUG", phase=self.name)
            except Exception as e:
                await ctx.emit_log(f"crt.sh lookup skipped: {e}", level="DEBUG", phase=self.name)

            # 3. AlienVault OTX (only when configured or accessible)
            if config.otx_api_key or ctx.profile == "full":
                otx_headers = client_headers.copy()
                if config.otx_api_key:
                    otx_headers["X-OTX-API-KEY"] = config.otx_api_key

                try:
                    otx_url = f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}/passive_dns"
                    resp = await client.get(otx_url, headers=otx_headers)
                    if resp.status_code == 200:
                        data = resp.json()
                        records = data.get("passive_dns", [])
                        otx_count = 0
                        for r in records:
                            hostname = r.get("hostname", "").strip().lower().rstrip(".")
                            if hostname and ctx.is_in_scope(hostname):
                                discovered.add(hostname)
                                subdomain_sources.setdefault(hostname, set()).add("AlienVault OTX")
                                otx_count += 1
                        if otx_count > 0:
                            await ctx.emit_log(f"AlienVault OTX provided {otx_count} passive DNS records.", level="INFO", phase=self.name)
                except Exception:
                    pass

        # Populate context subdomains with deduplicated candidates and sources
        for sub in discovered:
            if ctx.is_excluded(sub):
                continue
            src_str = ", ".join(sorted(subdomain_sources.get(sub, ["Passive OSINT"])))
            if sub not in ctx.subdomains:
                ctx.subdomains[sub] = {
                    "name": sub,
                    "is_live": False,  # Verified in next DNS stage
                    "status": "UNRESOLVED",
                    "source": src_str,
                    "is_apex": (sub == domain),
                    "ips": [],
                    "dns_records": {}
                }
            else:
                existing_src = ctx.subdomains[sub].get("source", "")
                all_srcs = set(existing_src.split(", ")) if existing_src else set()
                all_srcs.update(subdomain_sources.get(sub, set()))
                ctx.subdomains[sub]["source"] = ", ".join(sorted(s for s in all_srcs if s))

        # Ensure seed apex has a source
        if domain in ctx.subdomains and not ctx.subdomains[domain].get("source"):
            ctx.subdomains[domain]["source"] = "Target Seed"

        await ctx.emit_log(f"Passive discovery identified {len(ctx.subdomains)} candidate domains.", level="SUCCESS", phase=self.name)
        return ScanResult(
            phase_number=self.phase_number,
            phase_name=self.name,
            success=True,
            data={"discovered_count": len(discovered), "total_candidates": len(ctx.subdomains)}
        )
