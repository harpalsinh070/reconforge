from .phase1_target import TargetNormalizationScanner
from .phase2_osint import PassiveOSINTScanner
from .phase3_subdomains import SubdomainResolutionScanner
from .phase4_dns import DNSEnumerationScanner
from .phase5_ip_asn import IPNetworkScanner
from .phase6_ports import PortDiscoveryScanner
from .phase7_http_tech import SecurityHeadersScanner
from .phase8_security import TLSInspectionScanner
from .phase9_safe_audit import SafeAuditScanner
from .phase10_report import RiskReportScanner

CORE_SCANNERS = [
    TargetNormalizationScanner,   # Phase 1: Target Normalization & Scope
    PassiveOSINTScanner,          # Phase 2: Passive OSINT Subdomains
    SubdomainResolutionScanner,   # Phase 3: DNS Resolution & Deduplication
    PortDiscoveryScanner,         # Phase 4: Common TCP Port Discovery
    SecurityHeadersScanner,       # Phase 5: Gated on --headers / --all / full
    TLSInspectionScanner,         # Phase 6: Gated on --tls / --all / full
    DNSEnumerationScanner,        # Phase 11: Gated on --deep-dns / --all / full
    IPNetworkScanner,             # Phase 12: Gated on --ip-intel / --all / full
    SafeAuditScanner,             # Phase 13: Gated on --directories / --vuln-scan / --all / full
    RiskReportScanner             # Phase 7: Consolidated Reporting & Deliverables
]
