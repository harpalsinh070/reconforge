from .phase1_target import TargetNormalizationScanner
from .phase2_osint import PassiveOSINTScanner
from .phase3_subdomains import SubdomainResolutionScanner
from .phase4_dns import DNSEnumerationScanner
from .phase5_ip_asn import IPNetworkScanner
from .phase6_ports import PortDiscoveryScanner
from .phase7_http_tech import HTTPTechProberScanner
from .phase8_security import SecurityAuditScanner
from .phase9_safe_audit import SafeAuditScanner
from .phase10_report import RiskReportScanner

CORE_SCANNERS = [
    TargetNormalizationScanner,
    PassiveOSINTScanner,
    SubdomainResolutionScanner,
    DNSEnumerationScanner,
    IPNetworkScanner,
    PortDiscoveryScanner,
    HTTPTechProberScanner,
    SecurityAuditScanner,
    SafeAuditScanner,
    RiskReportScanner
]
