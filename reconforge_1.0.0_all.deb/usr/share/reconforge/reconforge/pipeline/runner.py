import sys
import os
import asyncio
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.table import Table
from rich.text import Text

from .base import ScanContext, BaseScanner
from .phases import CORE_SCANNERS
from ..db import init_db, get_or_create_target, AsyncSessionLocal
from ..config import config
from ..banner import print_compact_header

class PipelineRunner:
    def __init__(
        self,
        target_domain: Optional[str] = None,
        target_url: Optional[str] = None,
        profile: str = "standard",
        custom_ports: Optional[List[int]] = None,
        exclude_hosts: Optional[List[str]] = None,
        scope: Optional[List[str]] = None,
        enable_vuln_scan: bool = False,
        enable_full_ports: bool = False,
        enable_directories: bool = False,
        enable_deep_dns: bool = False,
        enable_ip_intel: bool = False,
        enable_nmap: bool = False,
        enable_headers: bool = False,
        enable_tls: bool = False,
        enable_all: bool = False,
        quiet: bool = False,
        verbose: bool = False,
        no_color: bool = False,
        json_mode: bool = False
    ):
        self.target_url = target_url
        self.target_domain = target_domain or ""
        self.profile = profile
        self.custom_ports = custom_ports
        self.exclude_hosts = exclude_hosts or []
        self.scope = scope or []
        self.enable_all = enable_all
        # If --all is enabled, turn on all modules
        self.enable_vuln_scan = enable_vuln_scan or enable_all
        self.enable_full_ports = enable_full_ports or enable_all
        self.enable_directories = enable_directories or enable_all
        self.enable_deep_dns = enable_deep_dns or enable_all
        self.enable_ip_intel = enable_ip_intel or enable_all
        self.enable_nmap = enable_nmap
        self.enable_headers = enable_headers or enable_all
        self.enable_tls = enable_tls or enable_all
        self.quiet = quiet
        self.verbose = verbose
        self.json_mode = json_mode
        self.no_color = no_color or bool(os.environ.get("NO_COLOR"))

        # In JSON mode, all console diagnostics must be routed strictly to stderr
        if self.json_mode:
            self.console = Console(file=sys.stderr, no_color=self.no_color)
        else:
            self.console = Console(no_color=self.no_color)

    async def run(self) -> ScanContext:
        await init_db()
        target_ident = self.target_url or self.target_domain
        target_obj = await get_or_create_target(target_ident)

        async with AsyncSessionLocal() as session:
            async def log_callback(level: str, message: str, phase: str):
                if not self.quiet and not self.json_mode:
                    if level == "DEBUG" and not self.verbose:
                        return
                    tag = f"[bold cyan][{phase}][/bold cyan]"
                    if level == "SUCCESS":
                        self.console.print(f" {tag} [green]{message}[/green]")
                    elif level == "WARN":
                        self.console.print(f" {tag} [yellow]{message}[/yellow]")
                    elif level == "ERROR":
                        self.console.print(f" {tag} [bold red]{message}[/bold red]")
                    elif level == "INFO":
                        self.console.print(f" {tag} {message}")
                    elif level == "DEBUG":
                        self.console.print(f" {tag} [dim]{message}[/dim]")
                elif self.json_mode and self.verbose:
                    self.console.print(f"[{phase}] {level}: {message}")

            ctx = ScanContext(
                target_id=target_obj.id,
                target=self.target_domain or self.target_url or "",
                normalized_domain=self.target_domain or "",
                target_url=self.target_url,
                profile=self.profile,
                custom_ports=self.custom_ports,
                exclude_hosts=self.exclude_hosts,
                scope=self.scope,
                enable_vuln_scan=self.enable_vuln_scan,
                enable_full_ports=self.enable_full_ports,
                enable_directories=self.enable_directories,
                enable_deep_dns=self.enable_deep_dns,
                enable_ip_intel=self.enable_ip_intel,
                enable_nmap=self.enable_nmap,
                enable_headers=self.enable_headers,
                enable_tls=self.enable_tls,
                enable_all=self.enable_all,
                start_time=datetime.now(timezone.utc),
                session=session,
                log_callback=log_callback
            )

            # Determine stages to execute based on profile and opt-in flags
            scanners = self._resolve_stages(ctx)

            if not self.quiet and not self.json_mode:
                display_target = self.target_url if self.target_url else self.target_domain
                print_compact_header(
                    target=display_target,
                    profile=self.profile if not self.enable_all else "ALL (Comprehensive)",
                    start_time=ctx.start_time,
                    console=self.console
                )
                if self.enable_all:
                    self.console.print("[dim cyan][*] Explicit module selection (--all): Passive OSINT, DNS, Ports, Headers, TLS, Deep DNS, IP Intel, Safe Audit.[/dim cyan]\n")

            # Execution with clean progress display
            if not self.quiet and not self.json_mode:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    BarColumn(),
                    TimeElapsedColumn(),
                    console=self.console,
                    transient=True
                ) as progress:
                    task = progress.add_task("[cyan]Reconnaissance in progress...", total=len(scanners))

                    for sc in scanners:
                        progress.update(task, description=f"[cyan]Executing:[/cyan] {sc.name}")
                        try:
                            res = await sc.run(ctx)
                            if not res.success and sc.phase_number == 1:
                                self.console.print(f"[bold red][!] Aborted:[/bold red] {res.error}")
                                ctx.end_time = datetime.now(timezone.utc)
                                return ctx
                        except Exception as e:
                            await ctx.emit_log(f"Stage '{sc.name}' encountered error: {e}", level="ERROR", phase=sc.name)
                        progress.advance(task)
            else:
                for sc in scanners:
                    try:
                        res = await sc.run(ctx)
                        if not res.success and sc.phase_number == 1:
                            ctx.end_time = datetime.now(timezone.utc)
                            return ctx
                    except Exception as e:
                        await ctx.emit_log(f"Stage '{sc.name}' encountered error: {e}", level="ERROR", phase=sc.name)

            ctx.end_time = datetime.now(timezone.utc)

            # Final summary display for terminal users
            if not self.quiet and not self.json_mode:
                self._print_summary(ctx)

            return ctx

    def _resolve_stages(self, ctx: ScanContext) -> List[BaseScanner]:
        """Resolve ordered list of pipeline stages based on active profile and flags."""
        scanners = []
        for cls in CORE_SCANNERS:
            instance = cls()
            num = instance.phase_number

            # Passive profile: only Stage 1 (Target), Stage 2 (Passive OSINT), and Stage 7 (Report)
            if ctx.profile == "passive" and num not in [1, 2, 7]:
                continue

            # Quick profile: skip Port Discovery (4), Security Headers (5), TLS (6), and all optional modules
            if ctx.profile == "quick" and num in [4, 5, 6, 11, 12, 13]:
                continue

            # Standard profile: Skip optional/opt-in modules unless explicitly enabled
            if ctx.profile == "standard":
                # Phase 5: Security Headers
                if num == 5 and not (ctx.enable_headers or ctx.enable_all):
                    continue
                # Phase 6: TLS Inspection
                if num == 6 and not (ctx.enable_tls or ctx.enable_all):
                    continue
                # Phase 11: Deep DNS
                if num == 11 and not (ctx.enable_deep_dns or ctx.enable_all):
                    continue
                # Phase 12: IP Intel
                if num == 12 and not (ctx.enable_ip_intel or ctx.enable_all):
                    continue
                # Phase 13: Directory & Nuclei
                if num == 13 and not (ctx.enable_directories or ctx.enable_vuln_scan or ctx.enable_all):
                    continue

            scanners.append(instance)
        return scanners

    def _print_summary(self, ctx: ScanContext):
        duration = 0.0
        if ctx.end_time and ctx.start_time:
            duration = round((ctx.end_time - ctx.start_time).total_seconds(), 2)

        self.console.print("-" * 70)
        self.console.print(f"[bold green]Reconnaissance Complete:[/bold green] [bold white]{ctx.normalized_domain}[/bold white] (Duration: [cyan]{duration}s[/cyan])")
        self.console.print("-" * 70)

        summary_table = Table(box=None, padding=(0, 2))
        summary_table.add_column("Category", style="cyan", no_wrap=True)
        summary_table.add_column("Count", style="bold green", justify="right")
        summary_table.add_column("Key Highlights", style="white")

        live_subs = [s for s, d in ctx.subdomains.items() if d.get("is_live")]
        summary_table.add_row(
            "Subdomains",
            str(len(ctx.subdomains)),
            f"{len(live_subs)} live resolved hosts"
        )

        open_p = [f"{p['port']}/{p['service']}" for p in ctx.open_ports]
        summary_table.add_row(
            "Open Ports",
            str(len(ctx.open_ports)),
            ", ".join(open_p[:6]) + ("..." if len(open_p) > 6 else "") if open_p else "None discovered"
        )

        summary_table.add_row(
            "HTTP Services",
            str(len(ctx.http_assets)),
            f"{len([h for h in ctx.http_assets if h.get('status_code') == 200])} active web endpoints"
        )

        findings_count = len(ctx.findings)
        sev_counts = {}
        for f in ctx.findings:
            s = f.get("severity", "Low")
            sev_counts[s] = sev_counts.get(s, 0) + 1
        sev_summary = ", ".join(f"{k}: {v}" for k, v in sev_counts.items()) or "None"

        summary_table.add_row(
            "Security Findings",
            str(findings_count),
            sev_summary
        )

        score_color = "green" if ctx.risk_score < 30 else ("yellow" if ctx.risk_score < 70 else "red")
        summary_table.add_row(
            "Exposure Score",
            f"[{score_color}]{ctx.risk_score}/100[/{score_color}]",
            "Correlated attack surface rating"
        )

        self.console.print(summary_table)

        # Highlight most relevant validated findings
        if ctx.findings:
            self.console.print("\n[bold yellow]Relevant Findings:[/bold yellow]")
            for f in ctx.findings[:5]:
                sev = f.get("severity", "Low")
                s_color = "red" if sev in ["Critical", "High"] else ("yellow" if sev == "Medium" else "cyan")
                self.console.print(f" * [[bold {s_color}]{sev}[/bold {s_color}]] {f.get('title')} ({f.get('affected_url')})")
                if f.get("evidence"):
                    self.console.print(f"   [dim]Evidence: {f.get('evidence')[:100]} (Confidence: {f.get('confidence', 'confirmed')})[/dim]")

        report_file = config.reports_dir / f"recon_{ctx.normalized_domain}.json"
        self.console.print(f"\n[dim]Report saved to local database (~/.reconforge/reconforge.db)[/dim]\n")
