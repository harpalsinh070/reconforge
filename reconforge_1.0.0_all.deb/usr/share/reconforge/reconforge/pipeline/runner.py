import asyncio
import os
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.table import Table

from .base import ScanContext, BaseScanner
from .phases import CORE_SCANNERS
from ..db import init_db, get_or_create_target, AsyncSessionLocal
from ..config import config

class PipelineRunner:
    def __init__(
        self,
        target_domain: str,
        profile: str = "standard",
        custom_ports: Optional[List[int]] = None,
        exclude_hosts: Optional[List[str]] = None,
        scope: Optional[List[str]] = None,
        enable_nmap: bool = False,
        quiet: bool = False,
        verbose: bool = False,
        no_color: bool = False,
        json_mode: bool = False
    ):
        self.target_domain = target_domain
        self.profile = profile
        self.custom_ports = custom_ports
        self.exclude_hosts = exclude_hosts or []
        self.scope = scope or []
        self.enable_nmap = enable_nmap
        self.quiet = quiet or json_mode
        self.verbose = verbose
        self.json_mode = json_mode
        self.no_color = no_color or bool(os.environ.get("NO_COLOR"))
        self.console = Console(no_color=self.no_color)

    async def run(self) -> ScanContext:
        await init_db()
        target_obj = await get_or_create_target(self.target_domain)

        async with AsyncSessionLocal() as session:
            async def log_callback(level: str, message: str, phase: str):
                if not self.quiet:
                    if level == "DEBUG" and not self.verbose:
                        return
                    tag = f"[bold cyan][{phase}][/bold cyan]"
                    if level == "SUCCESS":
                        self.console.print(f" {tag} [green]{message}[/green]")
                    elif level == "WARN":
                        self.console.print(f" {tag} [yellow]{message}[/yellow]")
                    elif level == "ERROR":
                        self.console.print(f" {tag} [bold red]{message}[/bold red]")
                    elif level == "INFO":
                        self.console.print(f" {tag} {message}")
                    elif level == "DEBUG":
                        self.console.print(f" {tag} [dim]{message}[/dim]")

            ctx = ScanContext(
                target_id=target_obj.id,
                target=self.target_domain,
                normalized_domain=self.target_domain,
                profile=self.profile,
                custom_ports=self.custom_ports,
                exclude_hosts=self.exclude_hosts,
                scope=self.scope,
                enable_nmap=self.enable_nmap,
                start_time=datetime.now(timezone.utc),
                session=session,
                log_callback=log_callback
            )

            scanners = [cls() for cls in CORE_SCANNERS]
            
            if not self.quiet:
                self.console.print(f"\n[bold green][*] Initiating ReconForge Scan Engine[/bold green] on [bold white]{self.target_domain}[/bold white] (Profile: [cyan]{self.profile.upper()}[/cyan])\n")

            if not self.quiet:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    BarColumn(),
                    TimeElapsedColumn(),
                    console=self.console,
                    transient=True
                ) as progress:
                    overall_task = progress.add_task("[bold cyan]Scanning target...[/bold cyan]", total=len(scanners))

                    for sc in scanners:
                        # Skip port/exposure in passive profile
                        if self.profile == "passive" and sc.phase_number in [6, 9]:
                            progress.advance(overall_task)
                            continue

                        progress.update(overall_task, description=f"[cyan]Phase {sc.phase_number}:[/cyan] {sc.name}")
                        try:
                            res = await sc.run(ctx)
                            if not res.success and sc.phase_number == 1:
                                self.console.print(f"[bold red][!] Aborting:[/bold red] {res.error}")
                                ctx.end_time = datetime.now(timezone.utc)
                                return ctx
                        except Exception as e:
                            await ctx.emit_log(f"Phase {sc.phase_number} encountered error: {e}", level="ERROR", phase=sc.name)

                        progress.advance(overall_task)
            else:
                for sc in scanners:
                    if self.profile == "passive" and sc.phase_number in [6, 9]:
                        continue
                    try:
                        res = await sc.run(ctx)
                        if not res.success and sc.phase_number == 1:
                            ctx.end_time = datetime.now(timezone.utc)
                            return ctx
                    except Exception as e:
                        await ctx.emit_log(f"Phase {sc.phase_number} encountered error: {e}", level="ERROR", phase=sc.name)

            ctx.end_time = datetime.now(timezone.utc)

            # Print Final Terminal Summary Table if not in quiet / json mode
            if not self.quiet:
                self._print_summary(ctx)

            return ctx

    def _print_summary(self, ctx: ScanContext):
        duration = 0.0
        if ctx.end_time and ctx.start_time:
            duration = round((ctx.end_time - ctx.start_time).total_seconds(), 2)

        self.console.print("\n" + "="*70)
        self.console.print(f"[bold green][+] Assessment Completed for {ctx.normalized_domain}[/bold green] (Duration: [cyan]{duration}s[/cyan])")
        self.console.print("="*70 + "\n")

        summary_table = Table(title=f"Attack Surface Summary: {ctx.normalized_domain}", title_style="bold cyan")
        summary_table.add_column("Category", style="cyan", no_wrap=True)
        summary_table.add_column("Count", style="bold green", justify="right")
        summary_table.add_column("Key Highlights", style="white")

        live_subs = [s for s, d in ctx.subdomains.items() if d.get("is_live")]
        summary_table.add_row(
            "Subdomains",
            str(len(ctx.subdomains)),
            f"{len(live_subs)} live resolved hosts"
        )

        ip_list = list(ctx.ip_records.keys())
        providers = set(d.get("cloud_provider") for d in ctx.ip_records.values() if d.get("cloud_provider"))
        summary_table.add_row(
            "IP Addresses",
            str(len(ip_list)),
            f"Providers: {', '.join(providers) if providers else 'Direct / Self-hosted'}"
        )

        open_p = [f"{p['port']}/{p['service']}" for p in ctx.open_ports]
        summary_table.add_row(
            "Open Ports",
            str(len(ctx.open_ports)),
            ", ".join(open_p[:8]) + ("..." if len(open_p) > 8 else "") if open_p else "None discovered"
        )

        summary_table.add_row(
            "HTTP Applications",
            str(len(ctx.http_assets)),
            f"{len([h for h in ctx.http_assets if h.get('status_code') == 200])} HTTP 200 responses"
        )

        findings_count = len(ctx.findings)
        sev_counts = {}
        for f in ctx.findings:
            s = f.get("severity", "Low")
            sev_counts[s] = sev_counts.get(s, 0) + 1
        sev_summary = ", ".join(f"{k}: {v}" for k, v in sev_counts.items()) or "No exposure vectors"

        summary_table.add_row(
            "Security Findings",
            str(findings_count),
            sev_summary
        )

        score_color = "green" if ctx.risk_score < 30 else ("yellow" if ctx.risk_score < 70 else "red")
        summary_table.add_row(
            "Exposure Score",
            f"[{score_color}]{ctx.risk_score}/100[/{score_color}]",
            "Calculated based on exposed attack surface and identified vectors"
        )

        self.console.print(summary_table)
        self.console.print("")
