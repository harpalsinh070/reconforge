import sys
import os
import asyncio
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.table import Table
from rich.panel import Panel
from rich.text import Text

from .base import ScanContext, BaseScanner
from .phases import CORE_SCANNERS
from ..db import init_db, get_or_create_target, AsyncSessionLocal
from ..config import config
from ..banner import print_compact_header

class PipelineRunner:
    def __init__(
        self,
        target_domain: Optional[str] = None,
        target_url: Optional[str] = None,
        profile: str = "standard",
        custom_ports: Optional[List[int]] = None,
        exclude_hosts: Optional[List[str]] = None,
        scope: Optional[List[str]] = None,
        enable_vuln_scan: bool = False,
        enable_full_ports: bool = False,
        enable_directories: bool = False,
        enable_nmap: bool = False,
        enable_headers: bool = False,
        enable_tls: bool = False,
        enable_all: bool = False,
        output_path: Optional[str] = None,
        quiet: bool = False,
        verbose: bool = False,
        no_color: bool = False,
        json_mode: bool = False
    ):
        self.target_url = target_url
        self.target_domain = target_domain or ""
        self.profile = profile
        self.custom_ports = custom_ports
        self.exclude_hosts = exclude_hosts or []
        self.scope = scope or []
        self.enable_all = enable_all
        # If --all is enabled, turn on all modules
        self.enable_vuln_scan = enable_vuln_scan or enable_all
        self.enable_full_ports = enable_full_ports or enable_all
        self.enable_directories = enable_directories or enable_all
        self.enable_nmap = enable_nmap
        self.enable_headers = enable_headers or enable_all
        self.enable_tls = enable_tls or enable_all
        self.output_path = output_path
        self.quiet = quiet
        self.verbose = verbose
        self.json_mode = json_mode
        self.no_color = no_color or bool(os.environ.get("NO_COLOR"))

        # In JSON mode, all console diagnostics must be routed strictly to stderr
        if self.json_mode:
            self.console = Console(file=sys.stderr, no_color=self.no_color)
        else:
            self.console = Console(no_color=self.no_color)

    async def run(self) -> ScanContext:
        await init_db()
        target_ident = self.target_url or self.target_domain
        target_obj = await get_or_create_target(target_ident)

        async with AsyncSessionLocal() as session:
            async def log_callback(level: str, message: str, phase: str):
                if not self.quiet and not self.json_mode:
                    if level == "DEBUG" and not self.verbose:
                        return
                    tag = f"[bold cyan][{phase}][/bold cyan]"
                    if level == "SUCCESS":
                        self.console.print(f" {tag} [green]{message}[/green]")
                    elif level == "WARN":
                        self.console.print(f" {tag} [yellow]{message}[/yellow]")
                    elif level == "ERROR":
                        self.console.print(f" {tag} [bold red]{message}[/bold red]")
                    elif level == "INFO":
                        self.console.print(f" {tag} {message}")
                    elif level == "DEBUG":
                        self.console.print(f" {tag} [dim]{message}[/dim]")
                elif self.json_mode and self.verbose:
                    self.console.print(f"[{phase}] {level}: {message}")

            ctx = ScanContext(
                target_id=target_obj.id,
                target=self.target_domain or self.target_url or "",
                normalized_domain=self.target_domain or "",
                target_url=self.target_url,
                profile=self.profile,
                custom_ports=self.custom_ports,
                exclude_hosts=self.exclude_hosts,
                scope=self.scope,
                enable_vuln_scan=self.enable_vuln_scan,
                enable_full_ports=self.enable_full_ports,
                enable_directories=self.enable_directories,
                enable_nmap=self.enable_nmap,
                enable_headers=self.enable_headers,
                enable_tls=self.enable_tls,
                enable_all=self.enable_all,
                output_path=self.output_path,
                start_time=datetime.now(timezone.utc),
                session=session,
                log_callback=log_callback
            )

            # Determine stages to execute based on profile and opt-in flags
            scanners = self._resolve_stages(ctx)

            if not self.quiet and not self.json_mode:
                display_target = self.target_url if self.target_url else self.target_domain
                print_compact_header(
                    target=display_target,
                    profile=self.profile if not self.enable_all else "ALL (Comprehensive)",
                    start_time=ctx.start_time,
                    console=self.console
                )
                if self.enable_all:
                    self.console.print("[dim cyan][*] Explicit module selection (--all): Passive OSINT, DNS Resolution, Ports, Headers, TLS, Directories, Nuclei.[/dim cyan]\n")

            # Execution with clean progress display
            if not self.quiet and not self.json_mode:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    BarColumn(),
                    TimeElapsedColumn(),
                    console=self.console,
                    transient=True
                ) as progress:
                    task = progress.add_task("[cyan]Reconnaissance in progress...", total=len(scanners))

                    for sc in scanners:
                        progress.update(task, description=f"[cyan]Executing:[/cyan] {sc.name}")
                        try:
                            res = await sc.run(ctx)
                            if not res.success:
                                if res.error:
                                    ctx.errors.append(f"{sc.name}: {res.error}")
                                if sc.phase_number == 1:
                                    self.console.print(f"[bold red][!] Aborted:[/bold red] {res.error}")
                                    ctx.end_time = datetime.now(timezone.utc)
                                    return ctx
                            # After Phase 3 (DNS Resolution), display complete subdomain discovery table
                            if sc.phase_number == 3:
                                self._print_subdomain_discovery(ctx)
                        except Exception as e:
                            ctx.errors.append(f"{sc.name}: {e}")
                            await ctx.emit_log(f"Stage '{sc.name}' encountered error: {e}", level="ERROR", phase=sc.name)
                        progress.advance(task)
            else:
                for sc in scanners:
                    try:
                        res = await sc.run(ctx)
                        if not res.success:
                            if res.error:
                                ctx.errors.append(f"{sc.name}: {res.error}")
                            if sc.phase_number == 1:
                                ctx.end_time = datetime.now(timezone.utc)
                                return ctx
                    except Exception as e:
                        ctx.errors.append(f"{sc.name}: {e}")
                        await ctx.emit_log(f"Stage '{sc.name}' encountered error: {e}", level="ERROR", phase=sc.name)

            ctx.end_time = datetime.now(timezone.utc)

            # Final summary display for terminal users
            if not self.quiet and not self.json_mode:
                self._print_summary(ctx)

            return ctx

    def _resolve_stages(self, ctx: ScanContext) -> List[BaseScanner]:
        """Resolve ordered list of pipeline stages based on active profile and flags."""
        scanners = []
        for cls in CORE_SCANNERS:
            instance = cls()
            num = instance.phase_number

            # Passive profile: only Stage 1 (Target), Stage 2 (Passive OSINT), and Stage 7 (Report)
            if ctx.profile == "passive":
                if num not in [1, 2, 7]:
                    ctx.skipped_modules.append(instance.name)
                    continue

            # Quick profile: skip Port Discovery (4), Security Headers (5), TLS (6), and Safe Audit (13)
            elif ctx.profile == "quick":
                if num in [4, 5, 6, 13]:
                    ctx.skipped_modules.append(instance.name)
                    continue

            # Standard profile: Skip optional/opt-in modules unless explicitly enabled
            elif ctx.profile == "standard":
                # Phase 5: Security Headers
                if num == 5 and not (ctx.enable_headers or ctx.enable_all):
                    ctx.skipped_modules.append(instance.name)
                    continue
                # Phase 6: TLS Inspection
                if num == 6 and not (ctx.enable_tls or ctx.enable_all):
                    ctx.skipped_modules.append(instance.name)
                    continue
                # Phase 13: Directory & Nuclei
                if num == 13 and not (ctx.enable_directories or ctx.enable_vuln_scan or ctx.enable_all):
                    ctx.skipped_modules.append(instance.name)
                    continue

            scanners.append(instance)
        return scanners

    def _print_subdomain_discovery(self, ctx: ScanContext):
        """Display complete discovered subdomains list immediately following resolution."""
        live_subs = [s for s, d in ctx.subdomains.items() if d.get("is_live")]
        unresolved_subs = [s for s, d in ctx.subdomains.items() if not d.get("is_live")]

        self.console.print("\n[bold cyan][SUBDOMAIN DISCOVERY][/bold cyan]")
        self.console.print(f"Total discovered: [bold white]{len(ctx.subdomains)}[/bold white]")
        self.console.print(f"Live/resolved:    [bold green]{len(live_subs)}[/bold green]")
        self.console.print(f"Unresolved:       [bold dim]{len(unresolved_subs)}[/bold dim]\n")

        table = Table(box=None, padding=(0, 2))
        table.add_column("HOSTNAME", style="bold cyan")
        table.add_column("IP ADDRESS", style="white")
        table.add_column("STATUS", style="bold")
        table.add_column("SOURCE", style="dim")

        if ctx.subdomains:
            for sub_name in sorted(ctx.subdomains.keys()):
                s_data = ctx.subdomains[sub_name]
                ips = ", ".join(s_data.get("ips", [])) if s_data.get("ips") else "-"
                status = s_data.get("status", "RESOLVED" if s_data.get("is_live") else "UNRESOLVED")
                s_color = "green" if status == "RESOLVED" else ("yellow" if status == "WILDCARD" else "dim")
                source = s_data.get("source", "Passive OSINT")
                table.add_row(sub_name, ips, f"[{s_color}]{status}[/{s_color}]", source)
        else:
            table.add_row(ctx.normalized_domain, "-", "[dim]PRIMARY[/dim]", "Target Input")

        self.console.print(table)
        self.console.print()

    def _print_summary(self, ctx: ScanContext):
        """Display the complete, comprehensive 10-section scan results in the terminal."""
        duration = 0.0
        if ctx.end_time and ctx.start_time:
            duration = round((ctx.end_time - ctx.start_time).total_seconds(), 2)

        self.console.print("=" * 80)
        self.console.print(f"[bold green]ReconForge Assessment Complete:[/bold green] [bold white]{ctx.normalized_domain}[/bold white] (Duration: [cyan]{duration}s[/cyan])")
        self.console.print("=" * 80)

        # -------------------------------------------------------------
        # Section 1: Target validation and scope status
        # -------------------------------------------------------------
        self.console.print("\n[bold cyan]1. TARGET VALIDATION & SCOPE STATUS[/bold cyan]")
        scope_tbl = Table(box=None, padding=(0, 2))
        scope_tbl.add_column("Property", style="bold white", no_wrap=True)
        scope_tbl.add_column("Value", style="cyan")
        scope_tbl.add_row("Primary Target", ctx.target or ctx.normalized_domain)
        scope_tbl.add_row("Target Format", "URL" if ctx.target_url else "Domain / Host")
        if ctx.target_url:
            scope_tbl.add_row("Target URL", ctx.target_url)
        scope_tbl.add_row("Scope Boundaries", ", ".join(ctx.scope) if ctx.scope else "Autonomous root domain scope")
        scope_tbl.add_row("Excluded Hosts", ", ".join(ctx.exclude_hosts) if ctx.exclude_hosts else "None")
        self.console.print(scope_tbl)

        # -------------------------------------------------------------
        # Section 2: Complete Discovered Subdomains Inventory
        # -------------------------------------------------------------
        live_subs = [s for s, d in ctx.subdomains.items() if d.get("is_live")]
        unres_subs = [s for s, d in ctx.subdomains.items() if not d.get("is_live")]
        self.console.print(f"\n[bold cyan]2. DISCOVERED SUBDOMAINS INVENTORY[/bold cyan] (Total: {len(ctx.subdomains)} | Live: {len(live_subs)} | Unresolved: {len(unres_subs)})")

        sub_tbl = Table(box=None, padding=(0, 2))
        sub_tbl.add_column("HOSTNAME", style="bold cyan")
        sub_tbl.add_column("IP ADDRESS", style="white")
        sub_tbl.add_column("STATUS", style="bold")
        sub_tbl.add_column("SOURCE", style="dim")

        if ctx.subdomains:
            for sub_name in sorted(ctx.subdomains.keys()):
                s_data = ctx.subdomains[sub_name]
                ips = ", ".join(s_data.get("ips", [])) if s_data.get("ips") else "-"
                status = s_data.get("status", "RESOLVED" if s_data.get("is_live") else "UNRESOLVED")
                s_color = "green" if status == "RESOLVED" else ("yellow" if status == "WILDCARD" else "dim")
                source = s_data.get("source", "Passive OSINT")
                sub_tbl.add_row(sub_name, ips, f"[{s_color}]{status}[/{s_color}]", source)
        else:
            sub_tbl.add_row(ctx.normalized_domain, "-", "[dim]PRIMARY[/dim]", "Target Input")
        self.console.print(sub_tbl)

        # -------------------------------------------------------------
        # Section 3: DNS records and resolved IP addresses
        # -------------------------------------------------------------
        self.console.print("\n[bold cyan]3. DNS RECORDS & RESOLVED IP ADDRESSES[/bold cyan]")
        if ctx.ip_records:
            dns_tbl = Table(box=None, padding=(0, 2))
            dns_tbl.add_column("IP Address", style="bold white")
            dns_tbl.add_column("Associated Hosts", style="cyan")
            for ip, rec in sorted(ctx.ip_records.items()):
                dns_tbl.add_row(ip, ", ".join(rec.get("hosts", [])))
            self.console.print(dns_tbl)
        else:
            self.console.print("  [dim]No discrete DNS IP records resolved.[/dim]")

        # -------------------------------------------------------------
        # Section 4 & 5: Unique Open TCP Ports & Verified Services (Grouped by Host)
        # -------------------------------------------------------------
        self.console.print("\n[bold cyan]4 & 5. OPEN TCP PORTS & VERIFIED SERVICES (GROUPED BY HOST)[/bold cyan]")
        if ctx.open_ports:
            ports_by_host = {}
            for p in ctx.open_ports:
                h_key = p.get("host") or p.get("ip") or ctx.normalized_domain
                ports_by_host.setdefault(h_key, []).append(p)

            for host_key, p_list in sorted(ports_by_host.items()):
                port_tbl = Table(title=f"Host: {host_key} (IP: {p_list[0].get('ip', 'Unknown')})", box=None, padding=(0, 2))
                port_tbl.add_column("Port", style="bold green", justify="right")
                port_tbl.add_column("Protocol", style="magenta")
                port_tbl.add_column("Service", style="white")
                port_tbl.add_column("Verified Banner / Version", style="dim")

                for p in sorted(p_list, key=lambda x: x.get("port", 0)):
                    port_tbl.add_row(
                        f"{p.get('port')}/tcp",
                        p.get("protocol", "tcp"),
                        p.get("service", "unknown"),
                        p.get("banner") or "-"
                    )
                self.console.print(port_tbl)
        else:
            self.console.print("  [dim]No open TCP ports discovered.[/dim]")

        # -------------------------------------------------------------
        # Section 6: Probed HTTP/HTTPS Web Endpoints
        # -------------------------------------------------------------
        self.console.print("\n[bold cyan]6. CHECKED HTTP/HTTPS WEB ENDPOINTS[/bold cyan]")
        if ctx.http_assets:
            http_tbl = Table(box=None, padding=(0, 2))
            http_tbl.add_column("Endpoint URL", style="bold cyan")
            http_tbl.add_column("Status", style="bold green")
            http_tbl.add_column("Web Server", style="white")
            http_tbl.add_column("Page Title", style="dim")

            for h in ctx.http_assets:
                code_color = "green" if h.get("status_code", 0) < 400 else "yellow"
                http_tbl.add_row(
                    h.get("url", ""),
                    f"[{code_color}]{h.get('status_code', '-')}[/{code_color}]",
                    h.get("web_server") or "-",
                    h.get("title") or "-"
                )
            self.console.print(http_tbl)
        else:
            self.console.print("  [dim]No HTTP/HTTPS endpoints checked during this scan profile.[/dim]")

        # -------------------------------------------------------------
        # Section 7: HTTP Security-Header Results (Present & Missing)
        # -------------------------------------------------------------
        self.console.print("\n[bold cyan]7. HTTP SECURITY-HEADER EVALUATION[/bold cyan]")
        if ctx.http_assets:
            for h in ctx.http_assets:
                self.console.print(f"  [bold white]Endpoint:[/bold white] [cyan]{h.get('url')}[/cyan]")
                present = h.get("present_headers", {})
                missing = h.get("missing_headers", [])

                hdr_tbl = Table(box=None, padding=(0, 2))
                hdr_tbl.add_column("Header Name", style="white")
                hdr_tbl.add_column("Status / Value", style="bold")

                if present:
                    for hk, hv in present.items():
                        hdr_tbl.add_row(hk, f"[green]+ Present:[/green] {str(hv)[:40]}")
                if missing:
                    for m in missing:
                        hdr_tbl.add_row(m, "[yellow]- Missing / Inadequate[/yellow]")

                self.console.print(hdr_tbl)
        else:
            self.console.print("  [dim]Security headers not inspected (Enable via --headers or --all).[/dim]")

        # -------------------------------------------------------------
        # Section 8: TLS Certificate & Configuration Results
        # -------------------------------------------------------------
        self.console.print("\n[bold cyan]8. TLS CERTIFICATE & CRYPTOGRAPHIC CONFIGURATION[/bold cyan]")
        if ctx.tls_data:
            tls_tbl = Table(box=None, padding=(0, 2))
            tls_tbl.add_column("Host:Port", style="bold cyan")
            tls_tbl.add_column("Protocol", style="magenta")
            tls_tbl.add_column("Cipher", style="white")
            tls_tbl.add_column("Issuer", style="dim")
            tls_tbl.add_column("Days Left", style="bold")

            for t_key, t_info in sorted(ctx.tls_data.items()):
                d_left = t_info.get("days_left", 0)
                d_color = "red" if d_left <= 0 else ("yellow" if d_left < 15 else "green")
                tls_tbl.add_row(
                    t_key,
                    t_info.get("protocol", "Unknown"),
                    f"{t_info.get('cipher', 'Unknown')} ({t_info.get('cipher_bits', 0)}b)",
                    t_info.get("issuer_cn", "Unknown")[:30],
                    f"[{d_color}]{d_left} days[/{d_color}]"
                )
            self.console.print(tls_tbl)
        else:
            self.console.print("  [dim]TLS inspection not performed (Enable via --tls or --all).[/dim]")

        # -------------------------------------------------------------
        # Section 9: Security Findings with Evidence and Remediation
        # -------------------------------------------------------------
        self.console.print(f"\n[bold cyan]9. SECURITY FINDINGS & EXPOSURES[/bold cyan] (Total: {len(ctx.findings)})")
        if ctx.findings:
            # Separate confirmed vulnerabilities, potential findings, and informational observations
            for idx, f in enumerate(ctx.findings, 1):
                sev = f.get("severity", "Low")
                conf = f.get("confidence", "confirmed")
                sev_color = "bold red" if sev in ["Critical", "High"] else ("yellow" if sev == "Medium" else ("blue" if sev == "Low" else "dim"))

                self.console.print(f"\n  [bold white][{idx}][/bold white] [{sev_color}]{sev.upper()}[/{sev_color}] - [bold white]{f.get('title')}[/bold white] (Confidence: [magenta]{conf}[/magenta])")
                self.console.print(f"      [dim]Affected Asset:[/dim]  [cyan]{f.get('affected_url', ctx.normalized_domain)}[/cyan]")
                if f.get("evidence"):
                    self.console.print(f"      [dim]Evidence:[/dim]        {f.get('evidence')}")
                if f.get("rationale"):
                    self.console.print(f"      [dim]Impact:[/dim]          {f.get('rationale')}")
                if f.get("recommendation"):
                    self.console.print(f"      [dim]Remediation:[/dim]     [green]{f.get('recommendation')}[/green]")
        else:
            self.console.print("  [green][OK] No vulnerabilities or exposures detected.[/green]")

        # -------------------------------------------------------------
        # Section 10: Scan Duration, Skipped Modules, Errors, Completion Status
        # -------------------------------------------------------------
        self.console.print("\n[bold cyan]10. EXECUTION METRICS & COMPLETION STATUS[/bold cyan]")
        metric_tbl = Table(box=None, padding=(0, 2))
        metric_tbl.add_column("Metric", style="bold white", no_wrap=True)
        metric_tbl.add_column("Value", style="cyan")

        metric_tbl.add_row("Execution Duration", f"{duration}s")
        metric_tbl.add_row("Exposure Risk Score", f"{ctx.risk_score}/100")
        metric_tbl.add_row("Skipped Modules", ", ".join(ctx.skipped_modules) if ctx.skipped_modules else "None (all selected modules ran)")
        metric_tbl.add_row("Execution Errors", ", ".join(ctx.errors) if ctx.errors else "None")
        status_text = "[bold green]COMPLETED SUCCESSFULLY[/bold green]" if not ctx.errors else "[bold yellow]COMPLETED WITH WARNINGS[/bold yellow]"
        metric_tbl.add_row("Final Status", status_text)
        self.console.print(metric_tbl)

        self.console.print("\n" + "=" * 80 + "\n")
