import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, Text, Integer, Float, Boolean, DateTime, ForeignKey, JSON
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

class Target(Base):
    __tablename__ = "targets"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    domain = Column(String(255), unique=True, index=True, nullable=False)
    description = Column(String(255), default="")
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    last_scanned = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    risk_score = Column(Float, default=0.0)

    subdomains = relationship("Subdomain", back_populates="target", cascade="all, delete-orphan")
    ip_addresses = relationship("IPAddress", back_populates="target", cascade="all, delete-orphan")
    http_assets = relationship("HTTPAsset", back_populates="target", cascade="all, delete-orphan")
    findings = relationship("Finding", back_populates="target", cascade="all, delete-orphan")
    scans = relationship("ScanRecord", back_populates="target", cascade="all, delete-orphan")


class Subdomain(Base):
    __tablename__ = "subdomains"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    target_id = Column(String(36), ForeignKey("targets.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(255), index=True, nullable=False)
    is_live = Column(Boolean, default=True)
    is_wildcard = Column(Boolean, default=False)
    dns_records = Column(JSON, nullable=True)  # A, AAAA, CNAME, MX, TXT
    cname_target = Column(String(255), nullable=True)
    takeover_vulnerable = Column(Boolean, default=False)
    takeover_service = Column(String(100), nullable=True)
    source = Column(String(100), default="Passive OSINT")
    discovered_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    target = relationship("Target", back_populates="subdomains")


class IPAddress(Base):
    __tablename__ = "ip_addresses"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    target_id = Column(String(36), ForeignKey("targets.id", ondelete="CASCADE"), nullable=False)
    ip = Column(String(45), index=True, nullable=False)
    ip_version = Column(Integer, default=4)
    asn = Column(String(50), nullable=True)
    asn_org = Column(String(255), nullable=True)
    cloud_provider = Column(String(100), nullable=True)  # Cloudflare, AWS, GCP, etc.
    reverse_ptr = Column(String(255), nullable=True)
    discovered_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    target = relationship("Target", back_populates="ip_addresses")
    ports = relationship("Port", back_populates="ip_address", cascade="all, delete-orphan")


class Port(Base):
    __tablename__ = "ports"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    ip_id = Column(String(36), ForeignKey("ip_addresses.id", ondelete="CASCADE"), nullable=False)
    port_number = Column(Integer, nullable=False)
    protocol = Column(String(10), default="tcp")
    state = Column(String(20), default="open")
    service_name = Column(String(50), nullable=True)
    service_banner = Column(String(255), nullable=True)

    ip_address = relationship("IPAddress", back_populates="ports")


class HTTPAsset(Base):
    __tablename__ = "http_assets"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    target_id = Column(String(36), ForeignKey("targets.id", ondelete="CASCADE"), nullable=False)
    url = Column(String(512), index=True, nullable=False)
    status_code = Column(Integer, default=200)
    title = Column(String(255), nullable=True)
    web_server = Column(String(100), nullable=True)
    tech_stack = Column(JSON, nullable=True)  # List of technologies detected
    waf = Column(String(100), nullable=True)
    content_length = Column(Integer, default=0)
    tls_version = Column(String(50), nullable=True)
    tls_expiry_days = Column(Integer, nullable=True)
    missing_headers = Column(JSON, nullable=True)

    target = relationship("Target", back_populates="http_assets")


class Finding(Base):
    __tablename__ = "findings"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    target_id = Column(String(36), ForeignKey("targets.id", ondelete="CASCADE"), nullable=False)
    title = Column(String(255), nullable=False)
    severity = Column(String(20), default="Low")  # Info, Low, Medium, High, Critical
    category = Column(String(100), default="Exposure")
    affected_url = Column(String(512), nullable=True)
    description = Column(Text, default="")
    evidence = Column(Text, default="")
    confidence = Column(String(50), default="confirmed")  # confirmed, tentative
    rationale = Column(Text, default="")
    recommendation = Column(Text, default="")
    reference = Column(String(255), default="")
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    target = relationship("Target", back_populates="findings")


class ScanRecord(Base):
    __tablename__ = "scan_records"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    target_id = Column(String(36), ForeignKey("targets.id", ondelete="CASCADE"), nullable=False)
    profile = Column(String(50), default="standard")
    status = Column(String(20), default="completed")
    started_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    subdomains_count = Column(Integer, default=0)
    ports_count = Column(Integer, default=0)
    findings_count = Column(Integer, default=0)
    risk_score = Column(Float, default=0.0)

    target = relationship("Target", back_populates="scans")
