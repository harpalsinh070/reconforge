"""ReconForge - Linux Terminal Reconnaissance & Attack Surface Management Platform"""

__version__ = "1.0.0"
__author__ = "ReconForge Security Team"
__license__ = "GPL-3.0"
