from typing import Optional
from datetime import datetime, timezone
from rich.console import Console
from rich.text import Text
from .config import config

def print_compact_header(
    target: Optional[str] = None,
    profile: Optional[str] = None,
    start_time: Optional[datetime] = None,
    console: Optional[Console] = None
):
    """Print a clean, modern, professional CLI header without huge ASCII art."""
    con = console or Console()
    time_str = (start_time or datetime.now(timezone.utc)).strftime("%Y-%m-%d %H:%M:%S UTC")
    
    header = Text()
    header.append("ReconForge ", style="bold cyan")
    header.append(f"v{config.version} ", style="bold green")
    header.append("- Linux Attack Surface Reconnaissance Engine", style="dim white")
    con.print(header)

    if target:
        sub_info = Text()
        sub_info.append("Target: ", style="dim")
        sub_info.append(f"{target} ", style="bold white")
        sub_info.append("| Profile: ", style="dim")
        sub_info.append(f"{profile.upper() if profile else 'STANDARD'} ", style="bold cyan")
        sub_info.append("| Started: ", style="dim")
        sub_info.append(f"{time_str}", style="dim")
        con.print(sub_info)
    con.print("")

def print_banner(show_tip: bool = False, console: Optional[Console] = None):
    """Print standard header for interactive shell or diagnostics."""
    print_compact_header(console=console)
