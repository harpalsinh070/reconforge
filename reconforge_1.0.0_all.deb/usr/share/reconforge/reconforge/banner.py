import random
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

console = Console()

BANNER_ART = r"""
  ____                      _____                     
 |  _ \ ___  ___ ___  _ __ |  ___|__  _ __ __ _  ___  
 | |_) / _ \/ __/ _ \| '_ \| |_ / _ \| '__/ _` |/ _ \ 
 |  _ <  __/ (_| (_) | | | |  _| (_) | | | (_| |  __/ 
 |_| \_\___|\___\___/|_| |_|_|  \___/|_|  \__, |\___| 
                                          |___/       
"""

TIPS = [
    "Tip: Use 'reconforge console' for an interactive Metasploit-like assessment console.",
    "Tip: Combine with subfinder & nmap in your Linux PATH for automatic native hardware acceleration.",
    "Tip: Run 'reconforge scan -d target.com --quick' for high-speed triage on top 20 ports.",
    "Tip: Database records are preserved in ~/.reconforge/reconforge.db for offline querying.",
    "Tip: Run 'reconforge vulns' to see sensitive file leaks (.git, .env, actuator).",
    "Tip: Export results to JSON or Markdown using 'reconforge report -d target.com -f json'."
]

def print_banner(show_tip: bool = True):
    console.print(f"[bold cyan]{BANNER_ART}[/bold cyan]")
    subtitle = "  Linux Reconnaissance & Attack Surface Management Tool  |  v1.0.0"
    console.print(f"[bold white]{subtitle}[/bold white]")
    console.print("[dim]  Authorized Security Assessments, Penetration Testing & VAPT Only[/dim]\n")
    if show_tip:
        tip = random.choice(TIPS)
        console.print(f"[dim yellow][*] {tip}[/dim yellow]\n")

def get_banner_text() -> str:
    return BANNER_ART + "\n  Linux Reconnaissance & Attack Surface Management Tool (v1.0.0)\n"
