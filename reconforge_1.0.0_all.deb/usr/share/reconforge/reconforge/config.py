import os
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional

# Linux user home configuration path
HOME_DIR = Path.home()
RECON_HOME = HOME_DIR / ".reconforge"
DATA_DIR = RECON_HOME / "data"
REPORTS_DIR = RECON_HOME / "reports"
DB_PATH = RECON_HOME / "reconforge.db"

def ensure_recon_dirs():
    """Ensure runtime working directories exist."""
    try:
        for p in [RECON_HOME, DATA_DIR, REPORTS_DIR]:
            p.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

# Ensure directories exist safely
ensure_recon_dirs()

@dataclass
class Config:
    app_name: str = "ReconForge"
    version: str = "1.0.0"
    recon_home: Path = RECON_HOME
    data_dir: Path = DATA_DIR
    reports_dir: Path = REPORTS_DIR
    db_path: Path = DB_PATH
    database_url: str = f"sqlite+aiosqlite:///{DB_PATH.as_posix()}"
    
    # Networking & Concurrency
    request_timeout: float = 8.0
    dns_timeout: float = 3.0
    max_concurrency: int = 50
    user_agent: str = "Mozilla/5.0 (X11; Linux x86_64) ReconForge/1.0.0 (Authorized Security Assessment)"
    
    # Passive OSINT & Threat Intel
    otx_api_key: Optional[str] = field(
        default_factory=lambda: os.environ.get("RECONFORGE_OTX_KEY") or os.environ.get("OTX_API_KEY")
    )
    
    # Tool discovery
    nmap_path: str = "nmap"
    subfinder_path: str = "subfinder"
    nuclei_path: str = "nuclei"
    
    # Common ports
    quick_ports: List[int] = field(default_factory=lambda: [
        80, 443, 8080, 8443, 21, 22, 25, 53, 110, 143, 445, 3306, 3389, 5432, 6379, 8000, 8888, 9000, 9200, 27017
    ])
    standard_ports: List[int] = field(default_factory=lambda: [
        21, 22, 23, 25, 53, 69, 80, 88, 110, 135, 139, 143, 161, 389, 443, 445, 465, 587, 636, 993, 995,
        1433, 1521, 1883, 2049, 2082, 2083, 2086, 2087, 3000, 3128, 3306, 3389, 4000, 4040, 4200, 4848,
        5000, 5001, 5432, 5672, 5900, 5985, 5986, 6000, 6379, 6443, 7001, 7077, 8000, 8008, 8080, 8081,
        8088, 8090, 8181, 8200, 8443, 8500, 8880, 8888, 8983, 9000, 9090, 9091, 9092, 9200, 9418, 9443,
        9999, 10000, 11211, 15672, 27017, 28017
    ])

config = Config()
